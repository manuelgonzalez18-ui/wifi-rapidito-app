<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$api_url_base = 'https://api.wisphub.app/api/clientes/';
$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';
$testUser = $_GET['u'] ?? 'yairumilano@wifi-rapidito';
$results = [];

// Test 1: Exact usuario match
$url1 = $api_url_base . '?usuario=' . urlencode($testUser) . '&limit=10';
$ch = curl_init($url1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
$response = curl_exec($ch);
$err = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$data = json_decode($response, true);
$results['strategy1_usuario'] = [
    'url' => $url1,
    'http_code' => $httpCode,
    'curl_error' => $err,
    'count' => $data['count'] ?? 'N/A',
    'results_count' => isset($data['results']) ? count($data['results']) : 0,
    'first_name' => $data['results'][0]['nombre'] ?? 'N/A',
    'first_usuario' => $data['results'][0]['usuario'] ?? 'N/A'
];

// Test 2: Servicio match
$seed = str_replace('@wifi-rapidito', '', strtolower($testUser));
$url2 = $api_url_base . '?servicio=' . urlencode(strtoupper($seed)) . '&limit=10';
$ch = curl_init($url2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
$response2 = curl_exec($ch);
$err2 = curl_error($ch);
$httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$data2 = json_decode($response2, true);
$results['strategy3_servicio'] = [
    'url' => $url2,
    'http_code' => $httpCode2,
    'curl_error' => $err2,
    'count' => $data2['count'] ?? 'N/A',
    'results_count' => isset($data2['results']) ? count($data2['results']) : 0,
    'first_name' => $data2['results'][0]['nombre'] ?? 'N/A'
];

// Test 3: Check if login_wisphub.php has the new code
$loginFile = file_get_contents(__DIR__ . '/login_wisphub.php');
$results['login_version'] = [
    'has_strategy1' => strpos($loginFile, 'Strategy 1') !== false,
    'has_strategy3' => strpos($loginFile, 'Strategy 3') !== false,
    'has_old_buscar_loop' => strpos($loginFile, 'maxPages = 15') !== false,
    'file_size' => strlen($loginFile),
    'last_modified' => date('Y-m-d H:i:s', filemtime(__DIR__ . '/login_wisphub.php'))
];

echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
