<?php
// Obtener opciones válidas de asuntos para tickets en WispHub
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';

echo "=== OPCIONES DE TICKETS WISPHUB ===\n\n";

// OPTIONS para ver los campos disponibles
$ch = curl_init('https://api.wisphub.app/api/tickets/');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'OPTIONS');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

// Mostrar las opciones de asuntos_default
if (isset($data['actions']['POST']['asuntos_default']['choices'])) {
    echo "ASUNTOS VÁLIDOS:\n";
    foreach ($data['actions']['POST']['asuntos_default']['choices'] as $choice) {
        echo "  - '{$choice['display_name']}' (value: {$choice['value']})\n";
    }
} else {
    echo "No se encontraron choices en asuntos_default.\n";
    echo "Buscando en toda la respuesta...\n\n";
}

// Buscar en toda la respuesta 
if (isset($data['actions']['POST'])) {
    foreach ($data['actions']['POST'] as $field => $info) {
        if (isset($info['choices']) && !empty($info['choices'])) {
            echo "\n=== CAMPO: $field ===\n";
            foreach ($info['choices'] as $choice) {
                $val = $choice['value'] ?? '?';
                $name = $choice['display_name'] ?? '?';
                echo "  '$name' (value: $val)\n";
            }
        }
    }
}

echo "\n\n=== RAW RESPONSE (truncated) ===\n";
echo substr($response, 0, 5000);
echo "\n\nDONE.\n";
?>
