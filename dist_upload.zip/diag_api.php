<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';
$testUser = 'yairumilano@wifi-rapidito';
$results = [];

// Get server's outgoing IP
$ch = curl_init('https://api.ipify.org?format=json');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$ipRes = curl_exec($ch);
curl_close($ch);
$results['server_ip'] = json_decode($ipRes, true) ?? $ipRes;

// Test 1: api.wisphub.app (HTTPS)
$urls = [
    'wisphub_app_https' => 'https://api.wisphub.app/api/clientes/?usuario=' . urlencode($testUser) . '&limit=5',
    'wisphub_net_https' => 'https://api.wisphub.net/api/clientes/?usuario=' . urlencode($testUser) . '&limit=5',
    'wisphub_app_http'  => 'http://api.wisphub.app/api/clientes/?usuario=' . urlencode($testUser) . '&limit=5',
];

foreach ($urls as $label => $url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Api-Key ' . $api_key,
        'Content-Type: application/json',
        'User-Agent: WifiRapidito/1.0'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $effectiveUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    $data = json_decode($response, true);
    $results[$label] = [
        'url' => $url,
        'effective_url' => $effectiveUrl,
        'http_code' => $httpCode,
        'curl_error' => $err,
        'count' => $data['count'] ?? 'N/A',
        'results_count' => isset($data['results']) ? count($data['results']) : 0,
        'raw_snippet' => substr($response, 0, 300)
    ];
}

echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
