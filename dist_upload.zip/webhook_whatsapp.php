<?php
/**
 * webhook_whatsapp.php - Endpoint receptor de Webhooks de Meta (WhatsApp Cloud API)
 * Este archivo recibe todos los mensajes entrantes de WhatsApp y los enruta al bot.
 * 
 * URL a registrar en Meta: https://tu-dominio.com/webhook_whatsapp.php
 */
require_once __DIR__ . '/bot_config.php';
require_once __DIR__ . '/bot_session.php';
require_once __DIR__ . '/bot_sender.php';
require_once __DIR__ . '/bot_router.php';

// =============================================
// 1. WEBHOOK VERIFICATION (GET) — Registro inicial
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $mode      = $_GET['hub_mode'] ?? '';
    $token     = $_GET['hub_verify_token'] ?? '';
    $challenge = $_GET['hub_challenge'] ?? '';

    if ($mode === 'subscribe' && $token === META_VERIFY_TOKEN) {
        botLog("Webhook verified successfully!");
        http_response_code(200);
        echo $challenge;
    } else {
        botLog("Webhook verification FAILED. Token: $token", 'ERROR');
        http_response_code(403);
        echo 'Forbidden';
    }
    exit;
}

// =============================================
// 2. MESSAGE RECEPTION (POST) — Mensajes entrantes
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Responder 200 inmediatamente (Meta requiere respuesta rápida)
    http_response_code(200);
    
    // Verificar firma del webhook (seguridad)
    $signature = $_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '';
    $rawBody   = file_get_contents('php://input');
    
    if (!empty(META_APP_SECRET) && META_APP_SECRET !== 'TU_APP_SECRET_AQUI') {
        $expectedSig = 'sha256=' . hash_hmac('sha256', $rawBody, META_APP_SECRET);
        if (!hash_equals($expectedSig, $signature)) {
            botLog("Invalid webhook signature! Rejecting.", 'ERROR');
            exit;
        }
    }
    
    // Parsear el payload de Meta
    $payload = json_decode($rawBody, true);
    
    if (!$payload) {
        botLog("Empty or invalid JSON payload received", 'ERROR');
        exit;
    }
    
    // Extraer mensajes del payload
    $entries = $payload['entry'] ?? [];
    
    foreach ($entries as $entry) {
        $changes = $entry['changes'] ?? [];
        
        foreach ($changes as $change) {
            $value = $change['value'] ?? [];
            
            // Verificar que es un mensaje (no una notificación de estado)
            if (!isset($value['messages'])) {
                continue;
            }
            
            $messages = $value['messages'];
            $contacts = $value['contacts'] ?? [];
            
            foreach ($messages as $message) {
                $from      = $message['from'] ?? '';          // Número del remitente
                $msgId     = $message['id'] ?? '';            // ID del mensaje
                $msgType   = $message['type'] ?? 'text';      // text, interactive, image, etc.
                $timestamp = $message['timestamp'] ?? time();
                
                // Extraer texto del mensaje según su tipo
                $text = '';
                $mediaId = null;
                if ($msgType === 'text') {
                    $text = $message['text']['body'] ?? '';
                } elseif ($msgType === 'interactive') {
                    // Botones o listas
                    if (isset($message['interactive']['button_reply'])) {
                        $text = $message['interactive']['button_reply']['id'] ?? '';
                    } elseif (isset($message['interactive']['list_reply'])) {
                        $text = $message['interactive']['list_reply']['id'] ?? '';
                    }
                } elseif ($msgType === 'image') {
                    // Imagen recibida — guardar media ID para descarga posterior
                    $mediaId = $message['image']['id'] ?? '';
                    $text = $message['image']['caption'] ?? '[IMAGEN]';
                    botLog("Image received from $from | MediaID: $mediaId");
                }
                
                // Obtener nombre del contacto
                $contactName = '';
                foreach ($contacts as $c) {
                    if (($c['wa_id'] ?? '') === $from) {
                        $contactName = $c['profile']['name'] ?? '';
                        break;
                    }
                }
                
                if (empty($from) || (empty($text) && empty($mediaId))) {
                    continue;
                }
                
                botLog("MSG FROM $from ($contactName): $text");
                
                // Marcar como leído
                BotSender::markAsRead($msgId);
                
                // Iniciar sesión y enrutar
                $session = new BotSession($from);
                
                // Si hay imagen, guardarla en flowData para que el módulo activo la use
                if (!empty($mediaId)) {
                    $session->setFlowData('pending_media_id', $mediaId);
                }
                
                // Rate limiting
                if (!$session->checkRateLimit()) {
                    BotSender::sendText($from, "⚠️ Estás enviando mensajes muy rápido. Espera un momento e intenta de nuevo.");
                    continue;
                }
                
                // Enrutar al motor de conversación
                try {
                    BotRouter::handle($session, $text, $from);
                } catch (Exception $e) {
                    botLog("Router Error: " . $e->getMessage(), 'ERROR');
                    BotSender::sendText($from, "❌ Ocurrió un error inesperado. Intenta de nuevo o escribe *menu* para volver al inicio.");
                }
            }
        }
    }
    
    exit;
}

// Método no soportado
http_response_code(405);
echo 'Method Not Allowed';
?>
