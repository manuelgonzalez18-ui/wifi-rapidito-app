<?php
/**
 * mod_payment.php - Módulo: Reportar un Pago
 * Réplica del flujo del portal web (PaymentReport.jsx):
 * 1. Tipo de pago (PM Banesco, PM Otros, TF Banesco, TF Otros)
 * 2. Banco origen (solo si es interbancario)
 * 3. Teléfono emisor (solo si es pago móvil)
 * 4. Referencia (6 o 12 dígitos según tipo)
 * 5. Monto en Bs (pre-calculado $25 × BCV)
 * 6. Fecha del pago
 * 7. Confirmación → validación Banesco → reporte WispHub
 */
require_once __DIR__ . '/../banesco_api.php';

class ModPayment {

    // Tipos de pago (igual que PAYMENT_TYPES del portal)
    private static $paymentTypes = [
        '1' => [
            'id'    => 'pm_banesco',
            'label' => 'Pago Móvil Banesco → Banesco',
            'emoji' => '📱',
            'needsBank'  => false,
            'needsPhone' => true,
            'refDigits'  => 6,
        ],
        '2' => [
            'id'    => 'pm_interbancario',
            'label' => 'Pago Móvil Otros Bancos → Banesco',
            'emoji' => '🔄',
            'needsBank'  => true,
            'needsPhone' => true,
            'refDigits'  => 6,
        ],
        '3' => [
            'id'    => 'tf_banesco',
            'label' => 'Transferencia Banesco → Banesco',
            'emoji' => '🏦',
            'needsBank'  => false,
            'needsPhone' => false,
            'refDigits'  => 12,
        ],
        '4' => [
            'id'    => 'tf_interbancario',
            'label' => 'Transferencia Otros Bancos → Banesco',
            'emoji' => '🏛️',
            'needsBank'  => true,
            'needsPhone' => false,
            'refDigits'  => 6,
        ],
    ];

    /**
     * Inicia el flujo: muestra datos de pago y opciones de tipo.
     */
    public static function start($session, $from) {
        if (!$session->checkPaymentLimit()) {
            BotSender::sendText($from, "⚠️ Has alcanzado el límite de intentos de pago por hora. Intenta más tarde o contacta al admin:\n📞 wa.me/" . BOT_ADMIN_WA);
            $session->setState('main_menu');
            return;
        }

        $client = $session->getClient();

        // Deuda fija: $25 × tasa BCV (misma lógica del portal)
        $tasaBCV = ModDebt::getTasaBCV();
        $totalUSD = 25;
        $totalBs = $totalUSD * $tasaBCV;

        // Buscar última factura pendiente - usando proxy_invoices.php (ya tiene la lógica Dragnet)
        // El proxy trae TODAS las facturas y filtra por username/id_servicio localmente
        $invoiceId = '';
        $clientUsuario = trim($client['usuario'] ?? '');
        $clientIdServicio = $client['id_servicio'] ?? '';
        
        botLog("Invoice search: usuario=$clientUsuario | id_servicio=$clientIdServicio");

        // Llamar al proxy que ya existe y funciona
        $proxyUrl = 'https://wifirapidito.com/proxy_invoices.php?cliente=' . urlencode($clientUsuario);
        $ch = curl_init($proxyUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 60, // El Dragnet puede tardar
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        $facturas = $data['results'] ?? [];

        botLog("Proxy invoices: HTTP $httpCode | Matched: " . count($facturas));

        // El proxy ya filtró por el cliente, solo buscar la primera pendiente
        foreach ($facturas as $f) {
            $estado = strtolower(trim($f['estado'] ?? ''));
            $total = (float)($f['total'] ?? 0);
            $isPending = ($total > 0 && (
                strpos($estado, 'pendiente') !== false ||
                strpos($estado, 'por_pagar') !== false ||
                strpos($estado, 'sin pagar') !== false ||
                strpos($estado, 'vencida') !== false ||
                strpos($estado, 'unpaid') !== false ||
                $estado == '2'
            ));
            
            if ($isPending) {
                $invoiceId = $f['id_factura'] ?? $f['folio'] ?? $f['id'] ?? '';
                $fUsuario = $f['cliente']['usuario'] ?? '';
                botLog("Found pending invoice: #$invoiceId | Usuario: $fUsuario | Estado: $estado | Total: $total");
                break;
            }
        }

        if (empty($invoiceId)) {
            botLog("WARNING: No pending invoice found for client {$client['nombre']} (ID: {$client['id_servicio']})");
            BotSender::sendText($from, "✅ No tienes facturas pendientes de pago.\n\nEscribe *menu* para volver al menú.");
            $session->setState('main_menu');
            return;
        }

        botLog("Payment flow started for {$client['nombre']} | Invoice: $invoiceId | Bs: $totalBs");

        // Guardar en sesión
        $session->setFlowData('invoice_id', $invoiceId);
        $session->setFlowData('total_usd', $totalUSD);
        $session->setFlowData('total_bs', $totalBs);
        $session->setFlowData('tasa_bcv', $tasaBCV);

        // Mensaje con datos de recepción + tipos de pago
        $msg  = "💳 *Reportar Pago — {$client['nombre']}*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "📄 Factura: *#$invoiceId*\n\n";
        $msg .= "📋 *Datos para realizar el pago:*\n";
        $msg .= "🏦 Banco: *BANESCO*\n";
        $msg .= "🔢 RIF: *J-402638850*\n";
        $msg .= "💳 Cuenta: *01340332563321061868*\n";
        $msg .= "📱 Tlf Pago Móvil: *04120330315*\n";
        $msg .= "💰 Monto: *Bs. " . number_format($totalBs, 2, ',', '.') . "*\n";
        $msg .= "📊 Tasa BCV: Bs. " . number_format($tasaBCV, 2, ',', '.') . " / USD\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "💰 *¿Cómo realizó su pago?*\n\n";

        foreach (self::$paymentTypes as $num => $pt) {
            $msg .= "*$num.* {$pt['emoji']} {$pt['label']}\n";
        }
        $msg .= "\nEscribe el *número* 👇";

        BotSender::sendText($from, $msg);
        $session->setState('payment_type');
    }

    /**
     * Maneja los pasos del flujo.
     */
    public static function handle($session, $text, $from) {
        $state = $session->getState();
        $text = trim($text);

        switch ($state) {
            case 'payment_type':
                self::handlePaymentType($session, $text, $from);
                break;
            case 'payment_bank':
                self::handleBank($session, $text, $from);
                break;
            case 'payment_phone_emisor':
                self::handlePhoneEmisor($session, $text, $from);
                break;
            case 'payment_reference':
                self::handleReference($session, $text, $from);
                break;
            case 'payment_amount':
                self::handleAmount($session, $text, $from);
                break;
            case 'payment_date':
                self::handleDate($session, $text, $from);
                break;
            case 'payment_confirm':
                self::handleConfirm($session, $text, $from);
                break;
        }
    }

    /**
     * Paso 1: Tipo de pago
     */
    private static function handlePaymentType($session, $text, $from) {
        $key = trim($text);
        if (!isset(self::$paymentTypes[$key])) {
            BotSender::sendText($from, "❌ Selecciona *1*, *2*, *3* o *4*.");
            return;
        }

        $pt = self::$paymentTypes[$key];
        $session->setFlowData('payment_type_id', $pt['id']);
        $session->setFlowData('payment_type_label', $pt['label']);
        $session->setFlowData('needs_bank', $pt['needsBank']);
        $session->setFlowData('needs_phone', $pt['needsPhone']);
        $session->setFlowData('ref_digits', $pt['refDigits']);

        BotSender::sendText($from, "✅ *{$pt['emoji']} {$pt['label']}*");

        // Siguiente paso según el tipo
        if ($pt['needsBank']) {
            self::askBank($session, $from);
        } elseif ($pt['needsPhone']) {
            self::askPhoneEmisor($session, $from);
        } else {
            self::askReference($session, $from);
        }
    }

    /**
     * Pedir banco origen (solo interbancarios)
     */
    private static function askBank($session, $from) {
        $bankMap = json_decode(BANK_MAP, true);
        $msg  = "🏦 *Banco desde donde realizó el pago:*\n\n";
        foreach ($bankMap as $num => $bank) {
            $msg .= "*$num.* {$bank['name']}\n";
        }
        $msg .= "\nEscribe el *número*, *código* (ej: 0134) o *nombre* del banco 👇";
        BotSender::sendText($from, $msg);
        $session->setState('payment_bank');
    }

    private static function handleBank($session, $text, $from) {
        $bankMap = json_decode(BANK_MAP, true);
        $input = trim($text);
        $matched = null;

        // 1. Por número de listado
        if (isset($bankMap[$input])) {
            $matched = $bankMap[$input];
        }

        // 2. Por código bancario (4 dígitos)
        if (!$matched) {
            $cleanCode = preg_replace('/\D/', '', $input);
            if (strlen($cleanCode) === 4) {
                foreach ($bankMap as $bank) {
                    if ($bank['code'] === $cleanCode) {
                        $matched = $bank;
                        break;
                    }
                }
            }
        }

        // 3. Por nombre parcial
        if (!$matched) {
            foreach ($bankMap as $bank) {
                if (stripos($bank['name'], $input) !== false) {
                    $matched = $bank;
                    break;
                }
            }
        }

        if (!$matched) {
            BotSender::sendText($from, "❌ Banco no encontrado.\n\nEscribe el *número*, *código* (ej: 0134) o *nombre* del banco.");
            return;
        }

        $session->setFlowData('bank_name', $matched['name']);
        $session->setFlowData('bank_code', $matched['code']);
        BotSender::sendText($from, "✅ Banco: *{$matched['name']}*");

        $fd = $session->getFlowData();
        if ($fd['needs_phone']) {
            self::askPhoneEmisor($session, $from);
        } else {
            self::askReference($session, $from);
        }
    }

    /**
     * Pedir teléfono emisor (solo pago móvil)
     */
    private static function askPhoneEmisor($session, $from) {
        BotSender::sendText($from, "📱 *Número de teléfono emisor:*\n\nEl teléfono desde donde realizó el pago móvil.\n\n_Ejemplo: 04121234567_");
        $session->setState('payment_phone_emisor');
    }

    private static function handlePhoneEmisor($session, $text, $from) {
        $phone = preg_replace('/\D/', '', $text);

        if (strlen($phone) < 10 || strlen($phone) > 12) {
            BotSender::sendText($from, "❌ Número inválido. Debe tener *11 dígitos*.\n\n_Ejemplo: 04121234567_");
            return;
        }

        $session->setFlowData('phone_emisor', $phone);
        BotSender::sendText($from, "✅ Teléfono: *$phone*");
        self::askReference($session, $from);
    }

    /**
     * Pedir referencia
     */
    private static function askReference($session, $from) {
        $fd = $session->getFlowData();
        $digits = $fd['ref_digits'];

        if ($digits == 12) {
            $msg = "🔢 *Referencia del pago:*\n\nIngresa los *$digits dígitos* de la referencia.";
        } else {
            $msg = "🔢 *Referencia del pago:*\n\nIngresa los *últimos $digits dígitos* de la referencia.";
        }
        BotSender::sendText($from, $msg);
        $session->setState('payment_reference');
    }

    private static function handleReference($session, $text, $from) {
        $ref = preg_replace('/\D/', '', $text);
        $fd = $session->getFlowData();
        $expectedDigits = $fd['ref_digits'] ?? 6;

        if (strlen($ref) < 4 || strlen($ref) > 20) {
            BotSender::sendText($from, "❌ La referencia debe tener entre 4 y 20 dígitos. Intenta de nuevo:");
            return;
        }

        // === VERIFICAR REFERENCIA DUPLICADA (igual que proxy_payments.php) ===
        $refsFile = __DIR__ . '/../validated_references.json';
        if (file_exists($refsFile)) {
            $refsData = json_decode(file_get_contents($refsFile), true);
            if (is_array($refsData) && isset($refsData[trim($ref)])) {
                $prev = $refsData[trim($ref)];
                $msg  = "⚠️ *Referencia ya utilizada*\n\n";
                $msg .= "La referencia *$ref* ya fue reportada anteriormente";
                if (!empty($prev['validated_at'])) {
                    $msg .= " el {$prev['validated_at']}";
                }
                $msg .= ".\n\nSi crees que es un error, contacta al admin:\n";
                $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
                BotSender::sendText($from, $msg);
                botLog("Duplicate reference blocked: $ref (previously used for factura #{$prev['factura_id']})");
                $session->clearFlowData();
                $session->setState('main_menu');
                return;
            }
        }

        $session->setFlowData('reference', $ref);
        BotSender::sendText($from, "✅ Referencia: *$ref*");

        // Pedir monto — debe ser el monto EXACTO mostrado
        $totalBs = $fd['total_bs'] ?? 0;
        $msg  = "💰 *Monto pagado en Bs:*\n\n";
        $msg .= "Debes pagar exactamente *Bs. " . number_format($totalBs, 2, ',', '.') . "*\n";
        $msg .= "Coloca el monto exacto de tu pago.\n\n";
        $msg .= "_Ejemplo: " . number_format($totalBs, 2, '.', '') . "_";
        BotSender::sendText($from, $msg);
        $session->setState('payment_amount');
    }

    private static function handleAmount($session, $text, $from) {
        $text = str_replace(',', '.', $text);
        $text = preg_replace('/[^0-9.]/', '', $text);
        $amount = (float)$text;

        if ($amount <= 0) {
            BotSender::sendText($from, "❌ El monto debe ser mayor a 0. Ingresa el monto en Bs:");
            return;
        }

        // Validación del monto (tolerancia 1% como el portal)
        $expectedBs = $session->getFlowData()['total_bs'] ?? 0;
        if ($expectedBs > 0) {
            $deviation = abs($amount - $expectedBs) / $expectedBs;
            if ($deviation > 0.01) {
                $msg  = "❌ *El monto no coincide.*\n\n";
                $msg .= "Debes pagar: *Bs. " . number_format($expectedBs, 2, ',', '.') . "*\n";
                $msg .= "Monto ingresado: Bs. " . number_format($amount, 2, ',', '.') . "\n\n";
                $msg .= "Si tu pago es por un monto diferente, contacta al admin:\n";
                $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
                BotSender::sendText($from, $msg);
                $session->clearFlowData();
                $session->setState('main_menu');
                return;
            }
        }

        $session->setFlowData('amount', $amount);
        BotSender::sendText($from, "📅 *Fecha del pago* (DD/MM/AAAA):\n\n_Ejemplo: " . date('d/m/Y') . "_");
        $session->setState('payment_date');
    }

    private static function handleDate($session, $text, $from) {
        $text = str_replace(['-', '.'], '/', $text);
        $parts = explode('/', $text);

        if (count($parts) !== 3) {
            BotSender::sendText($from, "❌ Formato incorrecto. Usa DD/MM/AAAA\n_Ejemplo: " . date('d/m/Y') . "_");
            return;
        }

        $date = "{$parts[2]}-{$parts[1]}-{$parts[0]}";
        $timestamp = strtotime($date);

        if (!$timestamp || $timestamp > time() + 86400) {
            BotSender::sendText($from, "❌ Fecha inválida o futura. Ingresa la fecha real del pago:");
            return;
        }

        $session->setFlowData('payment_date', $date);
        $session->setFlowData('payment_date_display', $text);

        // Mostrar resumen completo para confirmar
        $fd = $session->getFlowData();
        $client = $session->getClient();

        $msg  = "📝 *Confirma tus datos:*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "👤 Cliente: {$client['nombre']}\n";
        $msg .= "📄 Factura: #{$fd['invoice_id']}\n";
        $msg .= "💳 Tipo: {$fd['payment_type_label']}\n";

        if (!empty($fd['bank_name'])) {
            $msg .= "🏦 Banco origen: {$fd['bank_name']}\n";
        }
        if (!empty($fd['phone_emisor'])) {
            $msg .= "📱 Tlf emisor: {$fd['phone_emisor']}\n";
        }

        $msg .= "🔢 Referencia: ****" . substr($fd['reference'], -4) . "\n";
        $msg .= "💰 Monto: Bs. " . number_format($fd['amount'], 2, ',', '.') . "\n";
        $msg .= "📅 Fecha: {$fd['payment_date_display']}\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "¿Correcto? Responde *Sí* o *No*";

        BotSender::sendText($from, $msg);
        $session->setState('payment_confirm');
    }

    private static function handleConfirm($session, $text, $from) {
        $textLower = strtolower($text);

        if (in_array($textLower, ['no', 'n', 'cancelar'])) {
            BotSender::sendText($from, "❌ Reporte cancelado.\n\nEscribe *menu* para volver al menú.");
            $session->clearFlowData();
            $session->setState('main_menu');
            return;
        }

        if (!in_array($textLower, ['si', 'sí', 's', 'yes', 'ok', 'confirmar'])) {
            BotSender::sendText($from, "Responde *Sí* para confirmar o *No* para cancelar.");
            return;
        }

        // === VALIDACIÓN BANESCO ===
        BotSender::sendText($from, "⏳ Validando con el banco...");

        $fd = $session->getFlowData();
        $client = $session->getClient();

        try {
            $result = BanescoAPI::checkTransaction($fd['reference'], [
                'amount'       => $fd['amount'],
                'phone_emisor' => $fd['phone_emisor'] ?? $client['telefono'],
                'banco_origen' => $fd['bank_code'] ?? '0134',
                'payment_date' => $fd['payment_date']
            ]);

            if ($result['success']) {
                // === REGISTRAR PAGO EN WISPHUB ===
                // Endpoint y payload idénticos a proxy_payments.php (registrarPagoAutorizado)
                $montoUSD = $fd['total_usd'] ?? 25;
                $facturaId = $fd['invoice_id'] ?? '';

                $wisphubSuccess = false;
                if (!empty($facturaId)) {
                    $fechaFormateada = date('Y-m-d H:i', strtotime($fd['payment_date']));
                    $paymentData = [
                        'referencia'    => $fd['reference'],
                        'fecha_pago'    => $fechaFormateada,
                        'total_cobrado' => (float)$montoUSD,
                        'accion'        => 1, // ACTIVACIÓN AUTOMÁTICA
                        'forma_pago'    => 16749
                    ];

                    // Llamada DIRECTA a WispHub (no relay)
                    $wisphubUrl = "https://api.wisphub.app/api/facturas/{$facturaId}/registrar-pago/";
                    $ch = curl_init($wisphubUrl);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => json_encode($paymentData),
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_TIMEOUT        => 30,
                        CURLOPT_HTTPHEADER     => [
                            'Authorization: Api-Key ' . WISPHUB_TOKEN,
                            'Content-Type: application/json',
                            'Accept: application/json',
                        ],
                    ]);
                    $whResponse = curl_exec($ch);
                    $whHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $whError = curl_error($ch);
                    curl_close($ch);

                    botLog("WispHub registrar-pago DIRECTO: HTTP $whHttpCode | URL: $wisphubUrl | Payload: " . json_encode($paymentData) . " | Response: $whResponse" . ($whError ? " | Error: $whError" : ""));

                    $wisphubSuccess = ($whHttpCode == 200 || $whHttpCode == 201);
                    
                    // Guardar referencia como usada (compartido con proxy_payments.php)
                    if ($wisphubSuccess) {
                        $refsFile = __DIR__ . '/../validated_references.json';
                        $refsData = file_exists($refsFile) ? json_decode(file_get_contents($refsFile), true) : [];
                        if (!is_array($refsData)) $refsData = [];
                        $now = new DateTime('now', new DateTimeZone('America/Caracas'));
                        $refsData[trim($fd['reference'])] = [
                            'referencia'    => trim($fd['reference']),
                            'factura_id'    => $facturaId,
                            'monto'         => $fd['amount'],
                            'nombre_user'   => $client['nombre'],
                            'payment_type'  => $fd['payment_type_label'] ?? '',
                            'validated_at'  => $now->format('Y-m-d H:i:s'),
                            'source'        => 'whatsapp_bot'
                        ];
                        file_put_contents($refsFile, json_encode($refsData, JSON_PRETTY_PRINT));
                    }
                } else {
                    botLog("WispHub registrar-pago SKIPPED: No invoice_id found for client {$client['nombre']}");
                }

                if ($wisphubSuccess) {
                    $msg  = "✅ *¡Pago verificado y registrado!*\n";
                    $msg .= "📄 Factura #$facturaId marcada como pagada\n";
                    $msg .= "Tu servicio será reactivado en minutos ⚡\n\n";
                    $msg .= "Escribe *menu* para volver al menú.";
                } else {
                    $msg  = "✅ *¡Pago verificado!*\n";
                    $msg .= "⚠️ El registro en el sistema tardará unos minutos.\n";
                    $msg .= "Administración fue notificada.\n\n";
                    $msg .= "Escribe *menu* para volver al menú.";
                }

                BotSender::sendText($from, $msg);

                // Notificar admin
                $adminMsg  = "🔔 *Pago Verificado Automáticamente*\n";
                $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
                $adminMsg .= "👤 {$client['nombre']}\n";
                $adminMsg .= "💳 {$fd['payment_type_label']}\n";
                $adminMsg .= "💰 Bs. " . number_format($fd['amount'], 2, ',', '.') . "\n";
                $adminMsg .= "🔢 Ref: {$fd['reference']}\n";
                if (!empty($fd['bank_name'])) $adminMsg .= "🏦 {$fd['bank_name']}\n";
                if (!empty($fd['phone_emisor'])) $adminMsg .= "📱 {$fd['phone_emisor']}\n";
                BotSender::sendText(BOT_ADMIN_WA, $adminMsg);

            } else {
                $reason = $result['message'] ?? 'La referencia no se encontró o el monto no coincide.';
                $msg  = "❌ *No pudimos verificar el pago automáticamente*\n\n";
                $msg .= "Motivo: $reason\n\n";
                $msg .= "⚠️ Tu reporte fue enviado a administración para verificación manual.\n\n";
                $msg .= "Escribe *menu* para volver al menú.";

                BotSender::sendText($from, $msg);

                // Notificar admin por WhatsApp
                $adminMsg  = "⚠️ *Pago NO verificado (revisión manual)*\n";
                $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
                $adminMsg .= "👤 {$client['nombre']}\n";
                $adminMsg .= "💳 {$fd['payment_type_label']}\n";
                $adminMsg .= "💰 Bs. " . number_format($fd['amount'], 2, ',', '.') . "\n";
                $adminMsg .= "🔢 Ref: {$fd['reference']}\n";
                if (!empty($fd['bank_name'])) $adminMsg .= "🏦 {$fd['bank_name']}\n";
                if (!empty($fd['phone_emisor'])) $adminMsg .= "📱 {$fd['phone_emisor']}\n";
                $adminMsg .= "❌ Motivo: $reason\n";
                $adminMsg .= "📱 Vía: WhatsApp Bot";
                BotSender::sendText(BOT_ADMIN_WA, $adminMsg);

                // Enviar email de respaldo para revisión manual
                self::sendEmailBackup($client, $fd, $from);
            }

        } catch (Exception $e) {
            botLog("Banesco validation error: " . $e->getMessage(), 'ERROR');

            // Notificar admin por WhatsApp
            $adminMsg  = "🔔 *Pago Reportado (error banco)*\n";
            $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
            $adminMsg .= "👤 {$client['nombre']}\n";
            $adminMsg .= "💳 {$fd['payment_type_label']}\n";
            $adminMsg .= "💰 Bs. " . number_format($fd['amount'], 2, ',', '.') . "\n";
            $adminMsg .= "🔢 Ref: {$fd['reference']}\n";
            if (!empty($fd['bank_name'])) $adminMsg .= "🏦 {$fd['bank_name']}\n";
            if (!empty($fd['phone_emisor'])) $adminMsg .= "📱 {$fd['phone_emisor']}\n";
            $adminMsg .= "⚠️ Error: " . $e->getMessage() . "\n";
            $adminMsg .= "📱 Vía: WhatsApp Bot";
            BotSender::sendText(BOT_ADMIN_WA, $adminMsg);

            // Si falla la validación automática, enviar por email para revisión manual
            self::sendEmailBackup($client, $fd, $from);

            $msg  = "⚠️ *Error temporal del banco*\n\n";
            $msg .= "Tu reporte fue enviado a administración para verificación manual.\n";
            $msg .= "Te notificaremos cuando se procese.\n\n";
            $msg .= "Escribe *menu* para volver al menú.";

            BotSender::sendText($from, $msg);
        }

        $session->clearFlowData();
        $session->setState('main_menu');
    }

    /**
     * Envía email de respaldo cuando la validación automática falla.
     */
    private static function sendEmailBackup($client, $fd, $from) {
        $to = "admin@wifirapidito.com";
        $subject = "💳 REPORTE DE PAGO (Bot) - {$client['nombre']} - Ref: {$fd['reference']}";

        $headers = "From: noreply@wifirapidito.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        $body  = "<html><body style='font-family: sans-serif; color: #333;'>";
        $body .= "<h2 style='color: #0088cc;'>💳 Reporte de Pago - WhatsApp Bot</h2>";
        $body .= "<hr>";
        $body .= "<p><strong>Cliente:</strong> {$client['nombre']}</p>";
        $body .= "<p><strong>ID Servicio:</strong> {$client['id_servicio']}</p>";
        $body .= "<p><strong>Cédula:</strong> {$client['cedula']}</p>";
        $body .= "<p><strong>WhatsApp:</strong> $from</p>";
        $body .= "<hr>";
        $body .= "<p><strong>Tipo de Pago:</strong> {$fd['payment_type_label']}</p>";
        if (!empty($fd['bank_name'])) {
            $body .= "<p><strong>Banco Origen:</strong> {$fd['bank_name']}</p>";
        }
        if (!empty($fd['phone_emisor'])) {
            $body .= "<p><strong>Teléfono Emisor:</strong> {$fd['phone_emisor']}</p>";
        }
        $body .= "<p><strong>Referencia:</strong> {$fd['reference']}</p>";
        $body .= "<p style='background: #fef3c7; padding: 15px; border-left: 4px solid #f59e0b;'>";
        $body .= "<strong>💰 Monto:</strong> Bs. " . number_format($fd['amount'], 2, ',', '.') . "</p>";
        $body .= "<p><strong>Fecha:</strong> {$fd['payment_date_display']}</p>";
        $body .= "<p><strong>Factura:</strong> #{$fd['invoice_id']}</p>";
        $body .= "<hr>";
        $body .= "<p style='color: #e74c3c;'><strong>⚠️ VERIFICACIÓN AUTOMÁTICA FALLÓ - Requiere revisión manual</strong></p>";
        $body .= "</body></html>";

        $result = mail($to, $subject, $body, $headers);

        botLog("Payment email backup: " . ($result ? "SENT" : "FAILED") . " | Client: {$client['nombre']} | Ref: {$fd['reference']}");
    }
}
?>
