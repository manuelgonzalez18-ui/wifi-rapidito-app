<?php
/**
 * proxy_payments.php - Proxy para Reportar Pagos con Validación Automática Dual Banesco
 * Endpoint Mixto:
 *   - Éxito Banesco -> /api/facturas/{id}/registrar-pago/ (Activación Automática)
 *   - Falla/Otros    -> /api/facturas/reportar-pago/{id}/ (Validación Manual)
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

ob_start();

// Dependencias locales
require_once __DIR__ . '/banesco_api.php';

// ── CONFIGURACIÓN WISPHUB ──────────────────────────────────────────
define('WISPHUB_API_KEY', 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s');
define('VPS_RELAY_URL', 'https://wifirapidito.com/wisphub_relay.php');
define('VPS_RELAY_SECRET', 'wfr-relay-2026-secure');
define('VALIDATED_REFS_FILE', __DIR__ . '/validated_references.json');

const FORMAS_PAGO_MAP = [
    'transferencia' => 16749,
    'efectivo'      => 16748,
    'pm_banesco'    => 16749,
    'pm_interbancario' => 16749,
    'tf_banesco'    => 16749,
    'tf_interbancario' => 16749,
];

const MIME_TYPES = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/heif',
    'image/heic',
];

// ── FUNCIONES DE AYUDA BANESCO (AUTO) ─────────────────────────
function checkDuplicateReference($referencia) {
    if (!file_exists(VALIDATED_REFS_FILE)) return null;
    $data = json_decode(file_get_contents(VALIDATED_REFS_FILE), true);
    if (!is_array($data)) return null;
    $refKey = trim($referencia);
    return isset($data[$refKey]) ? $data[$refKey] : null;
}

function saveValidatedReference($referencia, $facturaId, $monto, $nombreUser, $paymentType = '') {
    $data = file_exists(VALIDATED_REFS_FILE) ? json_decode(file_get_contents(VALIDATED_REFS_FILE), true) : [];
    if (!is_array($data)) $data = [];
    $refKey = trim($referencia);
    $now = new DateTime('now', new DateTimeZone('America/Caracas'));
    $data[$refKey] = [
        'referencia'    => $refKey,
        'factura_id'    => $facturaId,
        'monto'         => $monto,
        'nombre_user'   => $nombreUser,
        'payment_type'  => $paymentType,
        'validated_at'  => $now->format('Y-m-d H:i:s'),
        'validated_date'=> $now->format('d/m/Y'),
        'validated_time'=> $now->format('h:i:s A'),
    ];
    file_put_contents(VALIDATED_REFS_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function registrarPagoAutorizado($facturaId, $referencia, $fechaPago, $formaPago, $totalCobradoUSD) {
    $targetPath = "/api/facturas/{$facturaId}/registrar-pago/";
    $fechaFormateada = date('Y-m-d H:i', strtotime($fechaPago));
    // IMPORTANTE: WispHub trabaja en USD. El total_cobrado SIEMPRE debe ser en USD.
    // Nunca enviar el monto en Bs que devuelve Banesco.
    $payload = [
        'referencia'    => $referencia,
        'fecha_pago'    => $fechaFormateada,
        'total_cobrado' => (float)$totalCobradoUSD,
        'accion'        => 1, // ACTIVACIÓN AUTOMÁTICA
        'forma_pago'    => (int)$formaPago
    ];
    $ch = curl_init(VPS_RELAY_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Api-Key ' . WISPHUB_API_KEY,
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Relay-Secret: ' . VPS_RELAY_SECRET,
            'X-Target-Path: ' . $targetPath,
        ],
    ]);
    $response  = curl_exec($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    if ($curlError) throw new Exception("Error de conexión WispHub: $curlError");
    $data = json_decode($response, true);
    if ($httpCode !== 200 && $httpCode !== 201) {
        $msg = $data['detail'] ?? (isset($data['errors']) ? json_encode($data['errors']) : "HTTP $httpCode");
        throw new Exception($msg);
    }
    return [ 'success' => true, 'data' => $data ];
}

// ── FUNCIÓN DE REPORTE MANUAL (FALLBACK) ──────────────────────
function reportarPagoManual($datos, $archivo = null) {
    // Revertimos al endpoint comprobado que no da 404
    $targetPath = '/api/facturas/reportar-pago/' . $datos['factura_id'] . '/';
    
    $postFields = [
        'forma_pago'       => (string)$datos['forma_pago'],
        'monto'            => (float)$datos['monto'],
        'fecha_pago'       => $datos['fecha_pago'],
        'referencia'       => $datos['referencia'],
        'comprobante_pago' => $datos['comprobante_texto'],
        'nombre_user'      => $datos['nombre_usuario']
    ];

    if (!empty($datos['id_servicio'])) {
        $postFields['id_servicio'] = (int)$datos['id_servicio'];
    }

    if ($archivo && file_exists($archivo['tmp_name'])) {
        $postFields['comprobante_pago_archivo'] = new CURLFile(
            $archivo['tmp_name'],
            $archivo['type'],
            $archivo['name']
        );
    }

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => VPS_RELAY_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $postFields,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Api-Key ' . WISPHUB_API_KEY,
            'Accept: application/json',
            'X-Relay-Secret: ' . VPS_RELAY_SECRET,
            'X-Target-Path: ' . $targetPath,
        ],
    ]);
    
    $response  = curl_exec($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        error_log("Relay Error: $curlError");
        throw new Exception("Error conexión manual: $curlError");
    }
    
    // LOG RAW RESPONSE FOR DEBUGGING
    error_log("Relay Response Manual ($httpCode): " . substr($response, 0, 500));
    
    $data = json_decode($response, true);
    if ($httpCode >= 400 || $httpCode === 0) {
        $msg = $data['detail'] ?? (is_array($data['errors'] ?? null) ? json_encode($data['errors']) : "HTTP $httpCode: $response");
        throw new Exception($msg);
    }
    return [ 'success' => true, 'data' => $data ];
}

// ── PROCESAMIENTO PRINCIPAL ───────────────────────────────────
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }

    $requeridos = ['invoice_id', 'reference', 'user_name'];
    foreach ($requeridos as $campo) {
        if (empty($_POST[$campo])) throw new Exception("Campo requerido: $campo");
    }

    $monto = $_POST['amount'] ?? 0;
    $fechaPago = $_POST['payment_date'] ?? date('Y-m-d');
    $referencia = trim($_POST['reference'] ?? '');
    $facturaId = preg_replace('/[^0-9]/', '', $_POST['invoice_id']);
    $nombreUser = trim($_POST['user_name'] ?? '');

    $paymentType = $_POST['payment_type'] ?? '';
    $paymentTypeLabel = $_POST['payment_type_label'] ?? 'Comprobante Subido';
    $rawFormaPago = $_POST['forma_pago'] ?? 16749;
    $formaPagoId = is_numeric($rawFormaPago) ? (int)$rawFormaPago : (FORMAS_PAGO_MAP[$rawFormaPago] ?? 16749);

    $isBanescoType = in_array($paymentType, ['pm_banesco', 'pm_interbancario', 'tf_banesco', 'tf_interbancario']) 
                    && (($_POST['ignore_banesco_auto'] ?? '') !== '1');

    $archivo = null;
    if (isset($_FILES['comprobante_pago_archivo']) && $_FILES['comprobante_pago_archivo']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['comprobante_pago_archivo'];
        if ($f['size'] > 10 * 1024 * 1024) throw new Exception('Archivo demasiado grande');
        if (!in_array($f['type'], MIME_TYPES)) throw new Exception('Tipo de archivo no permitido');
        $archivo = $f;
    } elseif (!empty($_POST['base64_image'])) {
        // FALLBACK: Si no viene como archivo, intentar como base64 (útil para el bot si falla multipart)
        $imgData = $_POST['base64_image'];
        if (strpos($imgData, 'data:image') !== false) {
            $parts = explode(',', $imgData, 2);
            $imgRaw = base64_decode($parts[1] ?? $parts[0]);
            $tmpPath = __DIR__ . '/comprobante_fallback_' . uniqid() . '.jpg';
            file_put_contents($tmpPath, $imgRaw);
            $archivo = [
                'tmp_name' => $tmpPath,
                'type' => 'image/jpeg',
                'name' => 'comprobante_bot.jpg',
                'is_fallback' => true
            ];
        }
    }

    // Bandera para indicar si fue validación auto vs reporte manual
    $autoValidated = false;
    $banescoData = null;
    $wispData = null;

    // 1. INTENTO DE FLUJO AUTOMÁTICO (SOLO BANESCO)
    if ($isBanescoType) {
        // Prevenir duplicados en auto-validación
        $prevValidation = checkDuplicateReference($referencia);
        if ($prevValidation) {
            ob_end_clean();
            http_response_code(409);
            echo json_encode([
                'status'  => 'duplicate',
                'message' => "Esta referencia ya fue validada el {$prevValidation['validated_date']}. Factura: {$prevValidation['factura_id']}"
            ]);
            exit;
        }

        try {
            // Determinar banco emisor: Default 0134 (Banesco) si es tipo Banesco y no viene banco_origen
            $bancoEmisor = $_POST['banco_origen'] ?? null;
            if (empty($bancoEmisor) && (strpos($paymentType, 'banesco') !== false)) {
                $bancoEmisor = '0134';
            }

            $banescoResponse = BanescoAPI::checkTransaction($referencia, [
                'amount'       => $monto,
                'payment_date' => $fechaPago,
                'banco_origen' => $bancoEmisor,
                'phone_emisor' => $_POST['phone_emisor'] ?? null
            ]);
            
            if ($banescoResponse['success']) {
                // FIX: Siempre enviar el monto original en USD a WispHub (NO el monto Bs de Banesco)
                // Banesco devuelve amount en Bs, pero WispHub espera USD ($25).
                // $monto viene del frontend como '25' (USD) que es lo correcto.
                $montoUSD = (float)$monto; // El monto original del frontend (en USD)
                $wyn = registrarPagoAutorizado($facturaId, $referencia, $fechaPago, $formaPagoId, $montoUSD);
                saveValidatedReference($referencia, $facturaId, $montoUSD, $nombreUser, $paymentTypeLabel);
                
                $autoValidated = true;
                $banescoData = $banescoResponse['data'] ?? null;
                $wispData = $wyn['data'];
            }
        } catch (Exception $ex) {
            // Silenciamos la excepción de Banesco para activar el Fallback Manual
            error_log("Banesco Auto-Val FAILED, falling back to manual: " . $ex->getMessage());
        }
    }

    // 2. FLUJO FALLBACK / REPORTAR PAGO MANUAL
    if (!$autoValidated) {
        if (!$archivo) {
            throw new Exception("Banesco no validó este pago o el sistema está en mantenimiento. Es obligatorio adjuntar el comprobante de imagen para reporte manual.");
        }

        // FIX: Enviar monto en USD al reporte manual también
        $datosManual = [
            'factura_id'      => $facturaId,
            'forma_pago'      => $formaPagoId,
            'monto'           => (float)$monto, // $monto viene como '25' (USD) del frontend
            'fecha_pago'      => $fechaPago,
            'referencia'      => substr($referencia, 0, 100),
            'comprobante_texto' => "[$paymentTypeLabel] Pago reportado desde portal - Ref: $referencia",
            'nombre_usuario'  => $nombreUser,
            'id_servicio'     => $_POST['id_servicio'] ?? null,
        ];
        
        $rs = reportarPagoManual($datosManual, $archivo);
        $wispData = $rs['data'];

        // Limpiar archivo fallback si se creó
        if (isset($archivo['is_fallback']) && file_exists($archivo['tmp_name'])) {
            unlink($archivo['tmp_name']);
        }
    }

    ob_end_clean();
    echo json_encode([
        'status'       => 'success',
        'wisphub'      => $autoValidated ? true : false,
        'message'      => $autoValidated ? 'Pago verificado por Banesco y activado.' : 'Reporte enviado a revisión manual.',
        'banesco_data' => $banescoData,
        'wisp_data'    => $wispData
    ]);

} catch (Exception $e) {
    if (ob_get_length()) ob_end_clean();
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}
