<?php
require_once __DIR__ . '/config_wisphub.php';

header('Content-Type: text/plain');

$targetPath = '/api/promesa_pago/';
$payload = [
    "id_factura" => 6900, // Replace with valid test invoice if necessary
    "fecha_limite" => "2026/04/04",
    "comentarios" => "test from debug script",
    "accion" => 1
];

echo "Testing JSON POST via Relay...\n";
$resJson = wisphubRelay($targetPath, 'POST', json_encode($payload));
echo "HTTP Code: " . $resJson['http_code'] . "\n";
echo "Response Length: " . strlen($resJson['response']) . "\n";
echo "Response Preview: \n" . substr($resJson['response'], 0, 500) . "\n\n";

echo "Testing URL-Enc formdata via Relay...\n";
// Sometimes WispHub wants application/x-www-form-urlencoded
$ch = curl_init(WISPHUB_RELAY_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
$headers = [
    'Authorization: Api-Key ' . WISPHUB_TOKEN,
    'X-Relay-Secret: ' . WISPHUB_RELAY_SECRET,
    'X-Target-Path: ' . $targetPath
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
$resForm = curl_exec($ch);
$codeForm = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "HTTP Code: " . $codeForm . "\n";
echo "Response Preview: \n" . substr($resForm, 0, 500) . "\n\n";


echo "Testing Multipart via Relay...\n";
$resMulti = wisphubRelayMultipart($targetPath, $payload);
echo "HTTP Code: " . $resMulti['http_code'] . "\n";
echo "Response Preview: \n" . substr($resMulti['response'], 0, 500) . "\n\n";

?>
