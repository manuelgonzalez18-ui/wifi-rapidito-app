/**
 * Rapidito Bot - Floating Widget
 * Inyecta la burbuja de chat y maneja la sesión automáticamente
 * Burbuja arrastrable en móvil para no bloquear botones del menú
 */

(function() {

    // Evitar inicialización doble
    if (window.RapiditoWidgetInitialized) return;
    window.RapiditoWidgetInitialized = true;

    // Use absolute URL specifically so the Android APK (Capacitor) doesn't try to load it from localhost
    const APP_URL = 'https://wifirapidito.com/rapidito/'; // Ruta donde vive el index.html del bot (que usa proxy)
    
    let isBotOpen = false;
    let widgetContainer = null;
    let iframeEl = null;
    let bubbleBtn = null;
    let userData = null;

    // ─── Drag state ───
    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let bubbleX = 0;
    let bubbleY = 0;
    let dragThreshold = 8; // px to distinguish tap from drag
    let wasDragged = false;

    // Detectar si el usuario está logueado leyendo el localStorage del portal
    function checkUserSession() {
        try {
            const token = localStorage.getItem('token');
            const dataStr = localStorage.getItem('user_data');
            
            if (token && dataStr) {
                const data = JSON.parse(dataStr);
                if (data && (data.id_servicio || data.id_cliente || data.nombre || data.role === 'client')) {
                    return data;
                }
            }
        } catch (e) {
            console.error("Rapidito Widget - Error leyendo sesión:", e);
        }
        return null;
    }

    // Ocultar botones de WhatsApp existentes
    function hideWhatsApp() {
        const waSelectors = [
            'a[href*="wa.me"]', 
            'a[href*="whatsapp"]',
            'a[href*="api.whatsapp.com"]',
            '.whatsapp-button', 
            '.whatsapp-float',
            '[class*="whatsapp"]',
            'img[src*="whatsapp"]'
        ];
        
        waSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => {
                if (!el.closest('#rapidito-widget-container')) {
                    el.style.setProperty('display', 'none', 'important');
                    el.classList.add('rapidito-hidden-wa');
                    if (el.parentElement && el.parentElement.tagName === 'DIV' && el.parentElement.children.length === 1) {
                        el.parentElement.style.setProperty('display', 'none', 'important');
                        el.parentElement.classList.add('rapidito-hidden-wa');
                    }
                }
            });
        });
    }

    function showWhatsApp() {
        document.querySelectorAll('.rapidito-hidden-wa').forEach(el => {
            el.style.setProperty('display', '', 'important');
            el.classList.remove('rapidito-hidden-wa');
        });
    }

    // ─── Bubble position helpers ───
    function saveBubblePosition(x, y) {
        try { localStorage.setItem('rapidito_bubble_pos', JSON.stringify({x, y})); } catch(e) {}
    }

    function loadBubblePosition() {
        try {
            const saved = localStorage.getItem('rapidito_bubble_pos');
            if (saved) return JSON.parse(saved);
        } catch(e) {}
        return null;
    }

    function setBubblePosition(x, y) {
        if (!bubbleBtn) return;
        // Clamp values to stay on screen
        const bw = 60;
        const maxX = window.innerWidth - bw;
        const maxY = window.innerHeight - bw;
        x = Math.max(0, Math.min(x, maxX));
        y = Math.max(0, Math.min(y, maxY));
        
        bubbleBtn.style.left = x + 'px';
        bubbleBtn.style.top = y + 'px';
        bubbleX = x;
        bubbleY = y;
    }

    function snapToEdge(x, y) {
        const midX = window.innerWidth / 2;
        const bw = 60;
        // Snap to nearest horizontal edge with 16px padding
        const snappedX = x + bw/2 < midX ? 16 : window.innerWidth - bw - 16;
        setBubblePosition(snappedX, y);
        saveBubblePosition(snappedX, y);
    }

    // ─── Drag handlers ───
    function onDragStart(e) {
        if (isBotOpen) return; // Don't drag when chat is open
        const touch = e.touches ? e.touches[0] : e;
        isDragging = true;
        wasDragged = false;
        dragStartX = touch.clientX - bubbleX;
        dragStartY = touch.clientY - bubbleY;
        bubbleBtn.style.transition = 'none';
        bubbleBtn.style.transform = 'scale(1.1)';
    }

    function onDragMove(e) {
        if (!isDragging) return;
        const touch = e.touches ? e.touches[0] : e;
        const newX = touch.clientX - dragStartX;
        const newY = touch.clientY - dragStartY;
        
        const dx = Math.abs(touch.clientX - (dragStartX + bubbleX));
        const dy = Math.abs(touch.clientY - (dragStartY + bubbleY));
        if (dx > dragThreshold || dy > dragThreshold) {
            wasDragged = true;
        }
        
        if (wasDragged) {
            e.preventDefault(); // Prevent scroll while dragging
            setBubblePosition(newX, newY);
        }
    }

    function onDragEnd(e) {
        if (!isDragging) return;
        isDragging = false;
        bubbleBtn.style.transition = 'left 0.3s ease, top 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease';
        bubbleBtn.style.transform = '';
        
        if (wasDragged) {
            snapToEdge(bubbleX, bubbleY);
        } else {
            toggleBot();
        }
    }

    // Dibujar la interfaz del widget
    function drawWidget() {
        if (widgetContainer) return;

        const style = document.createElement('style');
        style.textContent = `
            #rapidito-widget-container {
                position: fixed;
                inset: 0;
                z-index: 999999;
                font-family: 'Inter', system-ui, sans-serif;
                pointer-events: none;
            }
            #rapidito-widget-frame-wrapper {
                position: fixed;
                bottom: 90px;
                right: 24px;
                width: 380px;
                height: 600px;
                max-height: calc(100vh - 140px);
                max-width: calc(100vw - 48px);
                background: #0f172a;
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.5), 0 0 30px rgba(16,185,129,0.2);
                overflow: hidden;
                opacity: 0;
                transform: translateY(20px) scale(0.95);
                transition: opacity 0.3s ease, transform 0.3s ease;
                pointer-events: auto;
                display: none;
                z-index: 999998;
            }
            #rapidito-widget-frame-wrapper.show {
                display: block;
            }
            #rapidito-widget-frame-wrapper.animate {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
            #rapidito-iframe {
                width: 100%;
                height: 100%;
                border: none;
                background: transparent;
            }
            #rapidito-bubble {
                position: fixed;
                width: 60px;
                height: 60px;
                border-radius: 30px;
                background: linear-gradient(135deg, #10b981, #06b6d4);
                box-shadow: 0 8px 24px rgba(16,185,129,0.4);
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 32px;
                color: white;
                pointer-events: auto;
                transition: left 0.3s ease, top 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
                user-select: none;
                -webkit-user-select: none;
                touch-action: none;
                z-index: 999999;
            }
            #rapidito-avatar-img {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                object-fit: cover;
                border: 2px solid rgba(255,255,255,0.2);
                background: white;
                pointer-events: none;
            }
            #rapidito-badge {
                position: absolute;
                top: -4px;
                right: -4px;
                width: 16px;
                height: 16px;
                background: #ef4444;
                border-radius: 50%;
                border: 2px solid #030712;
                pointer-events: none;
            }
            @media (max-width: 480px) {
                #rapidito-widget-frame-wrapper {
                    position: fixed;
                    bottom: 0;
                    right: 0;
                    width: 100vw;
                    height: 100vh;
                    max-height: 100vh;
                    max-width: 100vw;
                    border-radius: 0;
                    z-index: 9999999;
                }
                #rapidito-mobile-close {
                    position: absolute;
                    top: 16px;
                    right: 16px;
                    width: 32px;
                    height: 32px;
                    background: rgba(0,0,0,0.5);
                    border-radius: 16px;
                    color: white;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 20px;
                    cursor: pointer;
                    z-index: 1000;
                }
            }
            @media (min-width: 481px) {
                #rapidito-mobile-close { display: none !important; }
            }
        `;
        document.head.appendChild(style);

        widgetContainer = document.createElement('div');
        widgetContainer.id = 'rapidito-widget-container';

        // Wrapper for iframe
        const frameWrapper = document.createElement('div');
        frameWrapper.id = 'rapidito-widget-frame-wrapper';
        
        // Iframe
        iframeEl = document.createElement('iframe');
        iframeEl.id = 'rapidito-iframe';
        iframeEl.src = APP_URL;
        iframeEl.allow = "camera; microphone";
        
        // Mobile close button
        const mobileClose = document.createElement('div');
        mobileClose.id = 'rapidito-mobile-close';
        mobileClose.innerHTML = '&times;';
        mobileClose.onclick = toggleBot;
        
        frameWrapper.appendChild(iframeEl);
        frameWrapper.appendChild(mobileClose);

        // Bubble Button (now positioned absolutely via JS)
        bubbleBtn = document.createElement('div');
        bubbleBtn.id = 'rapidito-bubble';
        bubbleBtn.innerHTML = '<img id="rapidito-avatar-img" src="/rapidito-avatar.png" alt="Rapidito" onerror="this.outerHTML=\'🤖\'" /><div id="rapidito-badge"></div>';
        
        // Set initial position: load saved or default to bottom-right above MobileNav
        const savedPos = loadBubblePosition();
        const isMobile = window.innerWidth <= 480;
        const defaultX = window.innerWidth - 76; // 60px bubble + 16px margin
        const defaultY = isMobile ? window.innerHeight - 140 : window.innerHeight - 84; // above MobileNav on mobile
        
        setBubblePosition(
            savedPos ? savedPos.x : defaultX,
            savedPos ? savedPos.y : defaultY
        );

        // Touch drag events
        bubbleBtn.addEventListener('touchstart', onDragStart, { passive: true });
        document.addEventListener('touchmove', onDragMove, { passive: false });
        document.addEventListener('touchend', onDragEnd, { passive: true });

        // Mouse drag (for desktop testing)
        bubbleBtn.addEventListener('mousedown', onDragStart);
        document.addEventListener('mousemove', onDragMove);
        document.addEventListener('mouseup', onDragEnd);
        
        // Tooltip Proactivo
        const tooltip = document.createElement('div');
        tooltip.id = 'rapidito-tooltip';
        tooltip.innerHTML = `¡Hola! 👋 Soy Rapidito.<br><span style="font-size:12px;opacity:0.9">¿En qué puedo ayudarte?</span>`;
        tooltip.onclick = toggleBot;
        
        const tooltipStyle = document.createElement('style');
        tooltipStyle.textContent = `
            #rapidito-tooltip {
                position: fixed;
                background: white;
                color: #0f172a;
                padding: 12px 16px;
                border-radius: 16px;
                border-bottom-right-radius: 4px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                font-size: 14px;
                font-weight: 500;
                line-height: 1.4;
                width: max-content;
                max-width: 220px;
                pointer-events: auto;
                cursor: pointer;
                opacity: 0;
                transform: scale(0.8);
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                z-index: 999997;
                display: none;
            }
            #rapidito-tooltip.show {
                opacity: 1;
                transform: scale(1);
                display: block;
            }
        `;
        document.head.appendChild(tooltipStyle);

        widgetContainer.appendChild(frameWrapper);
        document.body.appendChild(tooltip);
        document.body.appendChild(bubbleBtn);
        document.body.appendChild(widgetContainer);

        // Update tooltip position relative to bubble
        function updateTooltipPosition() {
            if (!bubbleBtn || !tooltip) return;
            const bx = bubbleX;
            const by = bubbleY;
            const midX = window.innerWidth / 2;
            
            if (bx + 30 < midX) {
                // Bubble on left side, show tooltip to the right
                tooltip.style.left = (bx + 70) + 'px';
                tooltip.style.right = 'auto';
                tooltip.style.borderBottomRightRadius = '16px';
                tooltip.style.borderBottomLeftRadius = '4px';
            } else {
                // Bubble on right side, show tooltip to the left
                tooltip.style.right = (window.innerWidth - bx + 10) + 'px';
                tooltip.style.left = 'auto';
                tooltip.style.borderBottomLeftRadius = '16px';
                tooltip.style.borderBottomRightRadius = '4px';
            }
            tooltip.style.top = (by + 5) + 'px';
        }

        // Listen for iframe ready event and send user data
        window.addEventListener('message', (e) => {
            if (e.data && e.data.type === 'rapidito-ready') {
                if (userData) {
                    iframeEl.contentWindow.postMessage({
                        type: 'init-rapidito',
                        userData: userData
                    }, '*');
                    
                    // Only show proactive tooltip on fresh login, not on every page load
                    const alreadyGreeted = sessionStorage.getItem('rapidito_greeted');
                    if (!alreadyGreeted) {
                        sessionStorage.setItem('rapidito_greeted', '1');
                        const firstName = (userData.nombre || 'Cliente').split(' ')[0];
                        tooltip.innerHTML = `¡Hola ${firstName}! 👋 Soy Rapidito.<br><span style="font-size:12px;opacity:0.9">¿En qué puedo ayudarte?</span>`;
                        setTimeout(() => {
                            if (!isBotOpen) {
                                updateTooltipPosition();
                                tooltip.classList.add('show');
                            }
                            setTimeout(() => tooltip.classList.remove('show'), 15000);
                        }, 1000);
                    }
                }
            }
        });

        // Recalculate on resize
        window.addEventListener('resize', () => {
            const saved = loadBubblePosition();
            if (saved) {
                setBubblePosition(saved.x, Math.min(saved.y, window.innerHeight - 76));
            }
        });
    }

    function toggleBot() {
        isBotOpen = !isBotOpen;
        const wrapper = document.getElementById('rapidito-widget-frame-wrapper');
        const badge = document.getElementById('rapidito-badge');
        const tooltip = document.getElementById('rapidito-tooltip');
        
        if (isBotOpen) {
            wrapper.classList.add('show');
            requestAnimationFrame(() => {
                wrapper.classList.add('animate');
            });
            bubbleBtn.innerHTML = '&times;';
            bubbleBtn.style.fontSize = '40px';
            if (badge) badge.style.display = 'none';
            if (tooltip) tooltip.classList.remove('show');
        } else {
            wrapper.classList.remove('animate');
            setTimeout(() => {
                if (!isBotOpen) wrapper.classList.remove('show');
            }, 300);
            bubbleBtn.innerHTML = '<img id="rapidito-avatar-img" src="/rapidito-avatar.png" alt="Rapidito" onerror="this.outerHTML=\'🤖\'" /><div id="rapidito-badge"></div>';
            bubbleBtn.style.fontSize = '32px';
        }
    }

    function init() {
        setInterval(() => {
            const currentData = checkUserSession();
            
            if (currentData) {
                if (!userData) {
                    userData = currentData;
                    hideWhatsApp();
                    drawWidget();
                    
                    if (iframeEl && iframeEl.contentWindow) {
                        iframeEl.contentWindow.postMessage({
                            type: 'init-rapidito',
                            userData: userData
                        }, '*');
                    }
                }
                hideWhatsApp();
            } else {
                if (userData) {
                    userData = null;
                    if (widgetContainer) {
                        widgetContainer.remove();
                        widgetContainer = null;
                        isBotOpen = false;
                    }
                    if (bubbleBtn) { bubbleBtn.remove(); bubbleBtn = null; }
                    var tip = document.getElementById('rapidito-tooltip');
                    if (tip) tip.remove();
                    sessionStorage.removeItem('rapidito_greeted');
                    showWhatsApp();
                }
            }
        }, 1000);
    }

    // Arrancar cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

