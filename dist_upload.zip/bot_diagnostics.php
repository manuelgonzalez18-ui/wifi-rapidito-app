<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

echo "=== BOT DIAGNOSTICS v2 ===\n\n";
echo "PHP Version: " . phpversion() . "\n\n";

echo "--- INCLUDE TEST (uno por uno) ---\n";

// 1. Config
try {
    require_once __DIR__ . '/bot_config.php';
    echo "OK | bot_config.php\n";
    echo "   META_PHONE_ID: " . (defined('META_PHONE_ID') ? META_PHONE_ID : 'MISSING') . "\n";
    echo "   TOKEN length: " . (defined('META_ACCESS_TOKEN') ? strlen(META_ACCESS_TOKEN) : 0) . "\n";
    echo "   MENU items: " . count(json_decode(MENU_OPTIONS, true)) . "\n";
} catch (Throwable $e) {
    echo "ERROR | bot_config.php | " . $e->getMessage() . " on line " . $e->getLine() . "\n";
}

// 2. Session
try {
    require_once __DIR__ . '/bot_session.php';
    echo "OK | bot_session.php\n";
} catch (Throwable $e) {
    echo "ERROR | bot_session.php | " . $e->getMessage() . " on line " . $e->getLine() . "\n";
}

// 3. Sender
try {
    require_once __DIR__ . '/bot_sender.php';
    echo "OK | bot_sender.php\n";
} catch (Throwable $e) {
    echo "ERROR | bot_sender.php | " . $e->getMessage() . " on line " . $e->getLine() . "\n";
}

// 4. Modules
$modules = [
    'bot_modules/mod_debt.php',
    'bot_modules/mod_payment.php',
    'bot_modules/mod_bankinfo.php',
    'bot_modules/mod_fault.php',
    'bot_modules/mod_wifi_password.php',
    'bot_modules/mod_status.php',
    'bot_modules/mod_promise.php',
];
foreach ($modules as $m) {
    try {
        require_once __DIR__ . '/' . $m;
        echo "OK | $m\n";
    } catch (Throwable $e) {
        echo "ERROR | $m | " . $e->getMessage() . " on line " . $e->getLine() . "\n";
    }
}

// 5. Router (last, depends on all modules)
try {
    require_once __DIR__ . '/bot_router.php';
    echo "OK | bot_router.php\n";
} catch (Throwable $e) {
    echo "ERROR | bot_router.php | " . $e->getMessage() . " on line " . $e->getLine() . "\n";
}

echo "\n--- SESSIONS DIR ---\n";
$sd = __DIR__ . '/bot_sessions/';
echo "Exists: " . (is_dir($sd) ? 'YES' : 'NO') . "\n";
echo "Writable: " . (is_writable($sd) ? 'YES' : 'NO') . "\n";

echo "\n--- LOG TAIL ---\n";
$logFile = __DIR__ . '/bot_whatsapp.log';
if (file_exists($logFile)) {
    $lines = file($logFile);
    $last = array_slice($lines, -15);
    foreach ($last as $l) echo $l;
} else {
    echo "No log file found\n";
}

echo "\n\nDONE.\n";
?>
