<?php
/**
 * mod_promise.php - Módulo: Solicitar Promesa de Pago
 * Misma lógica que RequestPromise.jsx del portal de autogestión.
 * 
 * Reglas del portal:
 * - Solo se puede si hay EXACTAMENTE 1 factura pendiente
 * - Fecha máxima dinámica según el día del mes
 * - Envía a /api/promesa-pago/ con accion=1 (activar servicio)
 * - Busca facturas via proxy_invoices.php (Dragnet)
 */

class ModPromise {

    /**
     * Calcula la fecha máxima permitida (misma lógica que RequestPromise.jsx)
     */
    private static function getMaxDate() {
        $today = new DateTime('now', new DateTimeZone('America/Caracas'));
        $day = (int)$today->format('j');
        $month = (int)$today->format('n');
        $year = (int)$today->format('Y');

        if ($day >= 1 && $day <= 5) {
            // Hasta el 10 del mes actual
            $target = new DateTime("$year-$month-10", new DateTimeZone('America/Caracas'));
        } elseif ($day >= 6 && $day <= 13) {
            // Hasta el 14 del mes actual
            $target = new DateTime("$year-$month-14", new DateTimeZone('America/Caracas'));
        } else {
            // Hasta el 5 del mes siguiente
            $nextMonth = $month + 1;
            $nextYear = $year;
            if ($nextMonth > 12) {
                $nextMonth = 1;
                $nextYear++;
            }
            $target = new DateTime("$nextYear-$nextMonth-05", new DateTimeZone('America/Caracas'));
        }

        return $target;
    }

    /**
     * Busca facturas pendientes del cliente (misma lógica que PaymentReport)
     */
    private static function findPendingInvoices($client) {
        $clientUsuario = trim($client['usuario'] ?? '');
        
        if (empty($clientUsuario)) {
            botLog("Promise: No username for client {$client['nombre']}");
            return [];
        }

        // Usar proxy_invoices.php (misma lógica que reportar pago)
        $proxyUrl = 'https://wifirapidito.com/proxy_invoices.php?cliente=' . urlencode($clientUsuario);
        $ch = curl_init($proxyUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 60,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        $facturas = $data['results'] ?? [];

        botLog("Promise invoice search: HTTP $httpCode | Total: " . count($facturas) . " | User: $clientUsuario");

        // Filtrar solo pendientes con monto > 0
        $pendientes = [];
        foreach ($facturas as $f) {
            $estado = strtolower(trim($f['estado'] ?? ''));
            $total = (float)($f['total'] ?? 0);
            $isPending = (
                strpos($estado, 'pendiente') !== false ||
                strpos($estado, 'por_pagar') !== false ||
                strpos($estado, 'sin pagar') !== false ||
                strpos($estado, 'vencida') !== false ||
                strpos($estado, 'unpaid') !== false
            );
            
            if ($isPending && $total > 0) {
                $pendientes[] = $f;
            }
        }

        return $pendientes;
    }

    /**
     * Inicia el flujo de promesa de pago.
     */
    public static function start($session, $from) {
        $client = $session->getClient();

        // Buscar facturas pendientes (misma lógica que el portal)
        $pendientes = self::findPendingInvoices($client);

        botLog("Promise: Found " . count($pendientes) . " pending invoices for {$client['nombre']}");

        // Regla del portal: NO permitir si tiene más de 1 factura pendiente
        if (count($pendientes) > 1) {
            $msg  = "⚠️ *Promesa No Disponible*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "Tienes *" . count($pendientes) . " facturas pendientes*.\n\n";
            $msg .= "El sistema solo permite promesas de pago cuando existe *una única factura pendiente*.\n";
            $msg .= "Por favor, regulariza tu situación.\n\n";
            $msg .= "Escribe *menu* para volver al menú.";

            BotSender::sendText($from, $msg);
            $session->setState('main_menu');
            return;
        }

        // Si no hay facturas pendientes
        if (count($pendientes) === 0) {
            BotSender::sendText($from, "✅ No tienes facturas pendientes. No necesitas una promesa de pago.\n\nEscribe *menu* para volver.");
            $session->setState('main_menu');
            return;
        }

        // Exactamente 1 factura pendiente
        $factura = $pendientes[0];
        $invoiceId = $factura['id_factura'] ?? $factura['folio'] ?? $factura['id'] ?? '';
        $total = $factura['total'] ?? 0;

        $session->setFlowData('invoice_id', $invoiceId);
        $session->setFlowData('invoice_total', $total);

        // Calcular fecha máxima (misma lógica que el portal)
        $maxDate = self::getMaxDate();
        $today = new DateTime('now', new DateTimeZone('America/Caracas'));
        $tomorrow = clone $today;
        $tomorrow->modify('+1 day');
        
        $session->setFlowData('max_date', $maxDate->format('Y-m-d'));
        $session->setFlowData('min_date', $tomorrow->format('Y-m-d'));

        $msg  = "📝 *Solicitar Promesa de Pago*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "👤 {$client['nombre']}\n";
        $msg .= "🧾 Factura: *#{$invoiceId}*\n";
        $msg .= "💵 Monto: *\${$total}*\n";
        $msg .= "⚡ Acción: Registrar y activar servicio\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "📅 *¿Hasta qué fecha puedes pagar?*\n\n";
        $msg .= "Fecha máxima: *" . $maxDate->format('d/m/Y') . "*\n";
        $msg .= "Formato: DD/MM/AAAA\n\n";
        $msg .= "_Ejemplo: " . $maxDate->format('d/m/Y') . "_";

        BotSender::sendText($from, $msg);
        $session->setState('promise_date');
    }

    /**
     * Maneja los pasos del flujo.
     */
    public static function handle($session, $text, $from) {
        $state = $session->getState();

        switch ($state) {
            case 'promise_date':
                self::handleDate($session, $text, $from);
                break;
            case 'promise_confirm':
                self::handleConfirm($session, $text, $from);
                break;
        }
    }

    private static function handleDate($session, $text, $from) {
        $text = str_replace(['-', '.'], '/', trim($text));
        $parts = explode('/', $text);

        if (count($parts) !== 3) {
            BotSender::sendText($from, "❌ Formato incorrecto. Usa DD/MM/AAAA");
            return;
        }

        $date = "{$parts[2]}-{$parts[1]}-{$parts[0]}"; // YYYY-MM-DD
        $timestamp = strtotime($date);
        
        if (!$timestamp) {
            BotSender::sendText($from, "❌ Fecha inválida. Usa DD/MM/AAAA\n_Ejemplo: " . date('d/m/Y', strtotime('+3 days')) . "_");
            return;
        }

        $fd = $session->getFlowData();
        $minDate = strtotime($fd['min_date']);
        $maxDate = strtotime($fd['max_date']);

        if ($timestamp < $minDate) {
            BotSender::sendText($from, "❌ La fecha debe ser a partir de mañana.\n\n_Mínimo: " . date('d/m/Y', $minDate) . "_");
            return;
        }

        if ($timestamp > $maxDate) {
            BotSender::sendText($from, "❌ La fecha excede el límite permitido.\n\n_Máximo: " . date('d/m/Y', $maxDate) . "_");
            return;
        }

        $session->setFlowData('promise_date', $date);
        $session->setFlowData('promise_date_display', $text);

        $msg  = "📝 *Confirma tu promesa:*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "🧾 Factura: *#{$fd['invoice_id']}*\n";
        $msg .= "💵 Monto: *\${$fd['invoice_total']}*\n";
        $msg .= "📅 Fecha límite: *$text*\n";
        $msg .= "⚡ Acción: Registrar y activar servicio\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "¿Confirmar? Responde *Sí* o *No*";

        BotSender::sendText($from, $msg);
        $session->setState('promise_confirm');
    }

    private static function handleConfirm($session, $text, $from) {
        $textLower = strtolower(trim($text));

        if (in_array($textLower, ['no', 'n', 'cancelar'])) {
            BotSender::sendText($from, "❌ Promesa cancelada.\n\nEscribe *menu* para volver.");
            $session->clearFlowData();
            $session->setState('main_menu');
            return;
        }

        if (!in_array($textLower, ['si', 'sí', 's', 'yes', 'ok', 'confirmar'])) {
            BotSender::sendText($from, "Responde *Sí* para confirmar o *No* para cancelar.");
            return;
        }

        BotSender::sendText($from, "⏳ Registrando promesa...");

        $fd = $session->getFlowData();
        $client = $session->getClient();

        // Payload idéntico al portal (RequestPromise.jsx + proxy_promises.php)
        $payload = [
            'id_factura'   => (int)$fd['invoice_id'],
            'fecha_limite' => $fd['promise_date'],
            'comentarios'  => 'Solicitud desde WhatsApp Bot - ' . $client['nombre'],
            'accion'       => 1
        ];

        // Enviar via relay (misma lógica que proxy_promises.php)
        $result = wisphubRelay('/api/promesa-pago/', 'POST', json_encode($payload));
        $httpCode = $result['http_code'];

        // Fallback a multipart si JSON falla (400)
        if ($httpCode === 400) {
            botLog("Promise JSON failed (400). Trying multipart...");
            $result = wisphubRelayMultipart('/api/promesa-pago/', $payload);
            $httpCode = $result['http_code'];
        }

        botLog("Promise: HTTP $httpCode | Client: {$client['nombre']} | Factura: #{$fd['invoice_id']} | Fecha: {$fd['promise_date']} | Response: {$result['response']}");

        if ($httpCode >= 200 && $httpCode < 300) {
            $msg  = "✅ *¡Promesa de pago registrada!*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "🧾 Factura: *#{$fd['invoice_id']}*\n";
            $msg .= "📅 Fecha límite: *{$fd['promise_date_display']}*\n";
            $msg .= "⚡ Tu servicio será reactivado en minutos\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "Recuerda pagar antes de la fecha límite.\n\n";
            $msg .= "Escribe *menu* para volver al menú.";

            // Notificar admin
            $adminMsg  = "🔔 *Promesa de Pago Registrada*\n";
            $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
            $adminMsg .= "👤 {$client['nombre']}\n";
            $adminMsg .= "🧾 Factura: #{$fd['invoice_id']}\n";
            $adminMsg .= "📅 Fecha: {$fd['promise_date_display']}\n";
            $adminMsg .= "📱 Vía: WhatsApp Bot";
            BotSender::sendText(BOT_ADMIN_WA, $adminMsg);
        } else {
            $responseData = json_decode($result['response'], true);
            $errorDetail = '';
            if (is_array($responseData)) {
                $errorDetail = $responseData['error'] ?? $responseData['detail'] ?? json_encode($responseData);
            }
            
            $msg  = "❌ No se pudo registrar la promesa.\n\n";
            if (!empty($errorDetail)) {
                $msg .= "Motivo: $errorDetail\n\n";
            }
            $msg .= "Contacta al admin para solicitar manualmente:\n";
            $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
        }

        BotSender::sendText($from, $msg);
        $session->clearFlowData();
        $session->setState('main_menu');
    }
}
?>
