<?php
/**
 * mod_status.php - Módulo: Estado del servicio
 * Muestra resumen del estado actual del servicio del cliente.
 */

class ModStatus {

    public static function start($session, $from) {
        $client = $session->getClient();
        $clientId = $client['id_servicio'];

        BotSender::sendText($from, "📊 Consultando tu servicio...");

        // Obtener datos actualizados del cliente
        $path = '/api/clientes/?id_servicio=' . $clientId . '&limit=1';
        $result = wisphubRelay($path);
        $data = json_decode($result['response'], true);
        $results = $data['results'] ?? [];

        if (empty($results)) {
            BotSender::sendText($from, "❌ No pude obtener los datos de tu servicio. Intenta más tarde.\n\nEscribe *menu* para volver.");
            $session->setState('main_menu');
            return;
        }

        $c = $results[0];
        $estado = strtoupper($c['estado'] ?? $client['estado'] ?? 'DESCONOCIDO');
        $estadoEmoji = ($estado === 'ACTIVO') ? '🟢' : '🔴';
        $nombre = $c['nombre'] ?? $client['nombre'];

        // Actualizar estado en sesión
        $client['estado'] = $estado;
        $session->setClient($client);

        $msg  = "📊 *Estado del Servicio — $nombre*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "$estadoEmoji Estado: *$estado*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        
        if ($estado !== 'ACTIVO') {
            $msg .= "⚠️ Tu servicio está *suspendido*.\n";
            $msg .= "Escribe *2* para reportar un pago y reactivar.\n\n";
        }

        $msg .= "Escribe *menu* para volver al menú.";

        BotSender::sendText($from, $msg);
        $session->setState('main_menu');
    }
}
?>
