<?php
/**
 * mod_debt.php - Módulo: Consultar deuda en Bs
 * Replica el comportamiento del bot web Rapidito:
 * - Busca la factura pendiente más reciente
 * - Multiplica $25 × tasa BCV del día
 * - Muestra el monto en Bs
 */

class ModDebt {

    /**
     * Inicia el flujo de consulta de deuda.
     */
    public static function start($session, $from) {
        $client = $session->getClient();
        $clientId = $client['id_servicio'];

        BotSender::sendText($from, "🔍 Consultando tu saldo...");

        // 1. Obtener facturas del cliente
        $path = '/api/facturas/?cliente=' . $clientId . '&limit=50';
        $result = wisphubRelay($path);
        $data = json_decode($result['response'], true);
        $facturas = $data['results'] ?? [];

        botLog("Debt query for $clientId: HTTP {$result['http_code']} | Total facturas: " . count($facturas));

        // 2. Buscar factura pendiente más reciente (la que importa)
        $ultimaPendiente = null;
        $totalPendientes = 0;
        foreach ($facturas as $f) {
            $estado = strtolower($f['estado'] ?? '');
            if (strpos($estado, 'pendiente') !== false) {
                $totalPendientes++;
                // La primera que encontremos es la más reciente (viene ordenada por fecha desc)
                if (!$ultimaPendiente) {
                    $ultimaPendiente = $f;
                }
            }
        }

        // 3. Obtener tasa BCV
        $tasaBCV = self::getTasaBCV();

        if (!$ultimaPendiente) {
            // No tiene facturas pendientes
            $msg  = "📋 *Estado de Cuenta — {$client['nombre']}*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "✅ ¡No tienes facturas pendientes!\n";
            $msg .= "Tu saldo está al día 🎉\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "Escribe *menu* para volver al menú.";
        } else {
            // Calcular monto en Bs
            $montoUSD = (float)($ultimaPendiente['total'] ?? 25);
            if ($montoUSD == 0) $montoUSD = 25; // Default $25 si viene en 0
            $montoBs = $montoUSD * $tasaBCV;

            $msg  = "📋 *Estado de Cuenta — {$client['nombre']}*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "💵 Mensualidad: *\$" . number_format($montoUSD, 2) . "*\n";
            $msg .= "📅 Tasa BCV: *Bs. " . number_format($tasaBCV, 2, ',', '.') . "*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "💰 *Total a pagar: Bs. " . number_format($montoBs, 2, ',', '.') . "*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "¿Deseas reportar un pago? Escribe *2*\n";
            $msg .= "¿Ver datos bancarios? Escribe *3*\n";
            $msg .= "Escribe *menu* para volver.";

            // Guardar datos en sesión
            $session->setFlowData('monto_usd', $montoUSD);
            $session->setFlowData('monto_bs', $montoBs);
            $session->setFlowData('tasa_bcv', $tasaBCV);
        }

        BotSender::sendText($from, $msg);
        $session->setState('main_menu');
    }

    /**
     * Handle (no se usa en este módulo — es single-step).
     */
    public static function handle($session, $text, $from) {
        $session->setState('main_menu');
        BotRouter::sendMainMenu($session, $from);
    }

    /**
     * Obtener tasa BCV del día.
     */
    public static function getTasaBCV() {
        // Intento 1: pydolarve.org
        $ch = curl_init('https://pydolarve.org/api/v2/dollar?monitor=bcv');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        if (isset($data['price'])) {
            botLog("BCV rate from pydolarve: " . $data['price']);
            return (float)$data['price'];
        }

        // Intento 2: pydolarvenezuela.com
        $ch = curl_init('https://pydolarvenezuela.com/api/v1/dollar?page=bcv');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $response2 = curl_exec($ch);
        curl_close($ch);

        $data2 = json_decode($response2, true);
        if (isset($data2['monitors']['usd']['price'])) {
            $rate = (float)$data2['monitors']['usd']['price'];
            botLog("BCV rate from pydolarvenezuela: $rate");
            return $rate;
        }

        // Intento 3: exchangerate fallback
        $ch = curl_init('https://ve.dolarapi.com/v1/dolares/oficial');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $response3 = curl_exec($ch);
        curl_close($ch);

        $data3 = json_decode($response3, true);
        if (isset($data3['promedio'])) {
            $rate = (float)$data3['promedio'];
            botLog("BCV rate from dolarapi: $rate");
            return $rate;
        }

        // Fallback manual
        botLog("All BCV rate APIs failed, using fallback", 'WARN');
        return 95.00;
    }
}
?>
