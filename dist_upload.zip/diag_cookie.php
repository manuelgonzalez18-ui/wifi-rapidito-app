<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';
$testUrl = 'https://api.wisphub.app/api/clientes/?usuario=' . urlencode('yairumilano@wifi-rapidito') . '&limit=5';
$results = [];

// Test 1: With CSRF cookie like WispHub shared
$ch = curl_init($testUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key,
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Accept-Language: es-ES,es;q=0.9,en;q=0.8',
    'Cookie: csrftoken=MvCEebfjX5mEN0qCVeiBD1P9bllcePLQsmh7YBMWjWJRLOk9NQ8ZKVGaFZvVH5Ma'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$data = json_decode($response, true);
$results['with_cookie_and_useragent'] = [
    'http_code' => $httpCode,
    'count' => $data['count'] ?? 'N/A',
    'results_count' => isset($data['results']) ? count($data['results']) : 0,
    'snippet' => substr($response, 0, 200)
];

// Test 2: With full browser-like headers
$ch = curl_init($testUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key,
    'User-Agent: PostmanRuntime/7.36.0',
    'Accept: */*',
    'Connection: keep-alive'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
$response2 = curl_exec($ch);
$httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$data2 = json_decode($response2, true);
$results['postman_useragent'] = [
    'http_code' => $httpCode2,
    'count' => $data2['count'] ?? 'N/A',
    'results_count' => isset($data2['results']) ? count($data2['results']) : 0,
    'snippet' => substr($response2, 0, 200)
];

// Test 3: Using cURL exactly as WispHub shared
$ch = curl_init('https://api.wisphub.app/api/clientes/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key ' . $api_key,
    'Cookie: csrftoken=MvCEebfjX5mEN0qCVeiBD1P9bllcePLQsmh7YBMWjWJRLOk9NQ8ZKVGaFZvVH5Ma; csrftoken=MvCEebfjX5mEN0qCVeiBD1P9bllcePLQsmh7YBMWjWJRLOk9NQ8ZKVGaFZvVH5Ma'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$response3 = curl_exec($ch);
$httpCode3 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$data3 = json_decode($response3, true);
$results['exact_wisphub_curl'] = [
    'http_code' => $httpCode3,
    'count' => $data3['count'] ?? 'N/A',
    'results_count' => isset($data3['results']) ? count($data3['results']) : 0,
    'snippet' => substr($response3, 0, 200)
];

echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
