<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';
$testUrl = '/api/clientes/?usuario=' . urlencode('yairumilano@wifi-rapidito') . '&limit=5';
$results = [];

// Test different auth header formats on .net
$tests = [
    'net_apikey'    => ['host' => 'api.wisphub.net', 'header' => 'Authorization: Api-Key ' . $api_key],
    'net_token'     => ['host' => 'api.wisphub.net', 'header' => 'Authorization: Token ' . $api_key],
    'net_bearer'    => ['host' => 'api.wisphub.net', 'header' => 'Authorization: Bearer ' . $api_key],
    'net_basic'     => ['host' => 'api.wisphub.net', 'header' => 'Authorization: Basic ' . base64_encode($api_key . ':')],
    'net_custom'    => ['host' => 'api.wisphub.net', 'header' => 'Api-Key: ' . $api_key],
    'app_apikey'    => ['host' => 'api.wisphub.app', 'header' => 'Authorization: Api-Key ' . $api_key],
];

foreach ($tests as $label => $config) {
    $url = 'https://' . $config['host'] . $testUrl;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        $config['header'],
        'Content-Type: application/json',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($response, true);
    $results[$label] = [
        'http_code' => $httpCode,
        'count' => $data['count'] ?? 'N/A',
        'results_count' => isset($data['results']) ? count($data['results']) : 0,
        'snippet' => substr($response, 0, 200)
    ];
}

echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
