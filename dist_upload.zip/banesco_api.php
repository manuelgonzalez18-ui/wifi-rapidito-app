<?php
/**
 * Configuración de Entorno
 * Cambiar a 'PROD' cuando recibamos las credenciales oficiales de producción.
 */
define('BANESCO_ENV', 'PROD'); // Opciones: 'QA', 'PROD'

// --- Ambientes ---
define('BANESCO_SSO_QA', 'https://sso-sso-project.apps.desplakur3.desintra.banesco.com/auth/realms/realm-api-qa/protocol/openid-connect/token');
define('BANESCO_API_QA', 'https://sid-validador-consulta-de-transacciones-api-qa-production.apps.desplakur3.desintra.banesco.com');

define('BANESCO_SSO_PROD', 'https://sso-sso-project.apps.proplakur.banesco.com/auth/realms/realm-api-prd/protocol/openid-connect/token');
define('BANESCO_API_PROD', 'https://sid-validador-consulta-de-transacciones-3scale-apicast-61e25ec.apps.proplakur.banesco.com');

// --- Credenciales ---
define('BANESCO_CLIENT_ID_QA', '136d814a');
define('BANESCO_CLIENT_SECRET_QA', '42a569a48580b4500714c698d41ad84e');

define('BANESCO_CLIENT_ID_PROD', '45fd2fbe'); 
define('BANESCO_CLIENT_SECRET_PROD', '5faca3ed3503855c78feff028be80584'); 

// Determinar constantes finales según entorno
define('BANESCO_SSO_URL', (BANESCO_ENV === 'PROD') ? BANESCO_SSO_PROD : BANESCO_SSO_QA);
define('BANESCO_API_URL', (BANESCO_ENV === 'PROD') ? BANESCO_API_PROD : BANESCO_API_QA);
define('BANESCO_CLIENT_ID', (BANESCO_ENV === 'PROD') ? BANESCO_CLIENT_ID_PROD : BANESCO_CLIENT_ID_QA);
define('BANESCO_CLIENT_SECRET', (BANESCO_ENV === 'PROD') ? BANESCO_CLIENT_SECRET_PROD : BANESCO_CLIENT_SECRET_QA);

// Cache para el token (archivo temporal)
define('BANESCO_TOKEN_CACHE', sys_get_temp_dir() . '/banesco_token_' . strtolower(BANESCO_ENV) . '.json');

class BanescoAPI {
    
    /**
     * Obtiene un token válido, ya sea de caché o solicitando uno nuevo.
     * Usa grant_type=password con Basic Auth header (según indicaciones de Banesco).
     */
    private static function getToken() {
        if (file_exists(BANESCO_TOKEN_CACHE)) {
            $data = json_decode(file_get_contents(BANESCO_TOKEN_CACHE), true);
            if (isset($data['access_token']) && $data['expires_at'] > time()) {
                return $data['access_token'];
            }
        }
        
        $ch = curl_init(BANESCO_SSO_URL);
        
        // Body: grant_type=password con username, password y scope
        $postData = http_build_query([
            'grant_type' => 'password',
            'username'   => BANESCO_CLIENT_ID,
            'password'   => BANESCO_CLIENT_SECRET,
            'scope'      => 'CONSULTA DE TRANSACCIONES'
        ]);
        
        // Client Authentication: Send as Basic Auth header
        $basicAuth = base64_encode(BANESCO_CLIENT_ID . ':' . BANESCO_CLIENT_SECRET);
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . $basicAuth
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || !$response) {
            throw new Exception("Error obteniendo token Banesco SSO. Code: $httpCode. Response: $response");
        }
        
        $tokenData = json_decode($response, true);
        if (!isset($tokenData['access_token'])) {
            throw new Exception("Token de Banesco no encontrado en la respuesta.");
        }
        
        // Guardar en caché, asumiendo un margen de seguridad (ej. 60 segundos antes)
        $expiresIn = $tokenData['expires_in'] ?? 300;
        file_put_contents(BANESCO_TOKEN_CACHE, json_encode([
            'access_token' => $tokenData['access_token'],
            'expires_at'   => time() + $expiresIn - 60
        ]));
        
        return $tokenData['access_token'];
    }
    
    /**
     * Consulta una transacción por su referencia.
     * @param string $referenceNumber Número de referencia del pago
     * @param array $options Opciones adicionales (accountId, amount, phoneNum, bankId, paymentDate)
     */
    public static function checkTransaction($referenceNumber, $options = []) {
        $token = self::getToken();
        
        $accountId = $options['accountId'] ?? '01340332563321061868';
        $amount = isset($options['amount']) ? (float)$options['amount'] : null;
        $phoneNum = $options['phone_emisor'] ?? $options['phoneNum'] ?? null;
        
        // Normalización de teléfono para Banesco (Requiere 12 dígitos, prefijo 58)
        if ($phoneNum) {
            $phoneNum = preg_replace('/\D/', '', $phoneNum); // Solo números
            if (strpos($phoneNum, '0') === 0) {
                $phoneNum = '58' . substr($phoneNum, 1);
            } elseif (strlen($phoneNum) === 10) {
                $phoneNum = '58' . $phoneNum;
            }
        }

        $bankIdRaw = $options['banco_origen'] ?? $options['bankId'] ?? null;
        $bankId = $bankIdRaw;
        
        // Sanitización de Bank ID (Mapeo de nombres a códigos si es necesario)
        if ($bankId) {
            $bankId = preg_replace('/\D/', '', $bankId); // Intentar solo números
            if (empty($bankId) && !empty($bankIdRaw)) {
                // Fallback si vino el nombre (basado en los logs vistos)
                $nombresBancos = [
                    'venezuela'    => '0102',
                    'mercantil'    => '0105',
                    'provincial'   => '0108',
                    'bancaribe'    => '0114',
                    'exterior'     => '0115',
                    'banesco'      => '0134',
                    'bfc'          => '0151',
                    'tesoro'       => '0163',
                    'bancamiga'    => '0172',
                    'bicentenario' => '0175',
                    'activo'       => '0171',
                    'plaza'        => '0138',
                    'del sur'      => '0157',
                ];
                $bankIdLower = strtolower($bankIdRaw);
                foreach ($nombresBancos as $nombre => $code) {
                    if (strpos($bankIdLower, $nombre) !== false) {
                        $bankId = $code;
                        break;
                    }
                }
            }
        }
        
        // Si sigue vacío y es Banesco la cuenta destino, podemos asumir 0134 como fallback de último recurso
        if (empty($bankId) && $accountId === '01340332563321061868') {
            $bankId = '0134';
        }
        
        // Formatear fecha para startDt/endDt (YYYY-MM-DD)
        $paymentDate = $options['payment_date'] ?? $options['paymentDate'] ?? date('Y-m-d');
        $formattedDate = date('Y-m-d', strtotime($paymentDate));

        // Endpoint structure differs slightly between QA and PROD
        $endpointSuffix = (BANESCO_ENV === 'PROD') 
            ? '/financial-account/transactions' 
            : '/transactions/financial-account/transactions';
        $url = BANESCO_API_URL . $endpointSuffix;        
        $payload = [
            'dataRequest' => [
                'device' => [
                    'description' => 'Wifi Rapidito Portal',
                    'ipAddress'   => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'type'        => 'Web'
                ],
                'transaction' => [
                    'referenceNumber' => (string)$referenceNumber,
                    'accountId'       => $accountId,
                    'amount'          => $amount,
                    'startDt'         => $formattedDate,
                    'phoneNum'        => $phoneNum,
                    'bankId'          => $bankId
                ]
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            // 'user_key' no es requerido si usamos OAuth con Client ID según lo estándar, 
            // pero si la API Gateway lo exige, lo agregaremos aquí
            // 'user_key: 7660a1327740be8cc3b3fcb3f291ae77' 
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20); // Timeout rápido
        
        // Log request payload
        self::logDebug("REQUEST SENT", $payload);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            self::logDebug("CURL ERROR", ['error' => $error]);
            throw new Exception("Error cURL Banesco API: $error");
        }
        
        // Log response
        self::logDebug("RESPONSE RECEIVED", [
            'httpCode' => $httpCode,
            'body' => json_decode($response, true) ?? $response
        ]);
        
        $data = json_decode($response, true);
        
        // Interpretar respuesta según Swagger
        $httpStatus = $data['httpStatus'] ?? null;
        
        if (!$httpStatus) {
            throw new Exception("Respuesta inválida de API Banesco. Code: $httpCode.");
        }
        
        if ($httpStatus['statusCode'] === '200' && $httpStatus['statusDesc'] === 'OK') {
            // Buscar la transacción de CRÉDITO (CR), ignorar la comisión (DB)
            $transactions = $data['dataResponse']['transactionDetail'] ?? [];
            $creditTxn = null;
            foreach ($transactions as $txn) {
                if (($txn['trnType'] ?? '') === 'CR') {
                    $creditTxn = $txn;
                    break;
                }
            }
            
            if (!$creditTxn && count($transactions) > 0) {
                $creditTxn = $transactions[0]; // Fallback al primero
            }
            
            return [
                'success' => true,
                'amount'  => (float)($creditTxn['amount'] ?? 0),
                'date'    => $creditTxn['trnDate'] ?? '',
                'concept' => trim($creditTxn['concept'] ?? ''),
                'refNum'  => $creditTxn['referenceNumber'] ?? '',
                'data'    => $data['dataResponse'] ?? null
            ];
        }
        
        if ($httpStatus['statusCode'] === '70001') {
            return [
                'success' => false,
                'message' => 'No se encontraron resultados para la referencia indicada. Verifique que la transferencia a Banesco sea exitosa.'
            ];
        }
        
        if ($httpStatus['statusCode'] === 'CRT503') {
            throw new Exception("Banesco: Servicio en horario de mantenimiento. Intente más tarde.");
        }
        
        return [
            'success' => false,
            'message' => $httpStatus['statusDesc'] ?? "Error en la validación del banco (Code: {$httpStatus['statusCode']})"
        ];
    }

    /**
     * Sistema de log para depuración de la API.
     */
    private static function logDebug($title, $data) {
        $logFile = __DIR__ . '/banesco_api_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        $logMsg = "[$timestamp] === $title ===\n" . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n" . str_repeat('-', 40) . "\n";
        file_put_contents($logFile, $logMsg, FILE_APPEND);
    }
}
?>
