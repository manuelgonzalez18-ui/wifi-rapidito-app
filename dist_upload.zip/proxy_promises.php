<?php
// proxy_promises.php - v2.1 (Automated Promise Handler)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/config_wisphub.php';

$logFile = __DIR__ . '/api_logs.txt';
function writeLog($msg) {
    global $logFile;
    $date = date('Y-m-d H:i:s');
    @file_put_contents($logFile, "[$date][PROMISE] $msg\n", FILE_APPEND);
}

$inputJSON = file_get_contents('php://input');
$data = json_decode($inputJSON, true) ?: $_POST;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Leave the date format explicitly as supplied from the frontend (YYYY-MM-DD)
    $fecha_limite = $data['fecha_limite'] ?? null;

    $targetPath = '/api/promesa-pago/'; // <--- The path was updated to use hyphen instead of underscore!
    
    // 2. Call Relay
    // We try to send as JSON first, but prepare for common WispHub errors
    $payload = [
        "id_factura" => $data['id_factura'],
        "fecha_limite" => $fecha_limite,
        "comentarios" => $data['comentarios'] ?? 'Solicitud desde portal',
        "accion" => 1
    ];

    $res = wisphubRelay($targetPath, 'POST', json_encode($payload));
    $http_code = $res['http_code'];
    $response = $res['response'];

    // Si falla el JSON (400 Bad Request), intentamos Form-Data (Multipart)
    // Algunos endpoints de WispHub son estrictos con el Content-Type
    if ($http_code === 400) {
        writeLog("JSON relay returned 400. Attempting fallback with Form-Data...");
        $res = wisphubRelayMultipart($targetPath, $payload);
        $http_code = $res['http_code'];
        $response = $res['response'];
    }

    // LOG DETALLADO
    writeLog("REQ: $targetPath | PAYLOAD: " . json_encode($payload) . " | CODE: $http_code | RES: " . ($response ?: 'EMPTY RESPONSE'));

    // 3. Handle Empty Response
    if (empty($response) && $http_code >= 400) {
        $response = json_encode([
            "error" => "El servidor de WispHub no devolvió ninguna respuesta (Code: $http_code).",
            "code" => $http_code,
            "details" => "Posible error de conexión o credenciales inválidas en el Relay."
        ]);
    }

    // 4. Email Notification on success
    if ($http_code === 201 || $http_code === 200) {
        sendEmailNotification($payload);
    }

    http_response_code($http_code);
    header('Content-Type: application/json');
    echo $response;
    exit;
}

// GET Fallback
http_response_code(405);
echo json_encode(["error" => "Method not allowed"]);

/**
 * Notificación de Promesa de Pago
 */
function sendEmailNotification($data) {
    $to = "admin@wifirapidito.com";
    $subject = "NUEVA PROMESA AUTOMÁTICA: Cliente/Servicio " . ($data['cliente'] ?? 'N/A');
    
    $headers = "From: noreply@wifirapidito.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $msgBody = "<html><body style='font-family: sans-serif;'>";
    $msgBody .= "<h2 style='color: #0891b2;'>Promesa de Pago Registrada</h2>";
    $msgBody .= "<p><strong>Cliente/Servicio:</strong> " . ($data['cliente'] ?? 'N/A') . "</p>";
    $msgBody .= "<p><strong>ID Factura:</strong> " . ($data['id_factura'] ?? 'N/A') . "</p>";
    $msgBody .= "<p><strong>Fecha Límite:</strong> " . ($data['fecha_limite'] ?? 'N/A') . "</p>";
    $msgBody .= "<div style='background: #ecfeff; padding: 15px; border-radius: 8px; border: 1px solid #a5f3fc;'>";
    $msgBody .= "<strong>Estado:</strong> Activación automática solicitada vía API.<br>";
    $msgBody .= "</div><br>";
    $msgBody .= "<p><em>Sistema Wifi Rapidito</em></p>";
    $msgBody .= "</body></html>";
    
    @mail($to, $subject, $msgBody, $headers);
}
?>
