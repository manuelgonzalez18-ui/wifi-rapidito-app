<?php
require_once __DIR__ . '/config_wisphub.php';

header('Content-Type: text/plain');

$paths_to_test = [
    '/api/promesa_pago/',
    '/api/promesas_pago/',
    '/api/promesa-pago/',
    '/api/promesas-pago/'
];

$payload = [
    "id_factura" => 6900,
    "fecha_limite" => "2026/04/04",
    "comentarios" => "Testing endpoints from debug script",
    "accion" => 1
];

echo "== TESTING PATHS VIA RELAY (JSON) ==\n\n";

foreach ($paths_to_test as $path) {
    echo "Testing Path: $path\n";
    $res = wisphubRelay($path, 'POST', json_encode($payload));
    
    echo "HTTP Code: " . $res['http_code'] . "\n";
    if ($res['http_code'] >= 200 && $res['http_code'] < 300) {
        echo "SUCCESS! Response: " . $res['response'] . "\n\n";
    } else {
        $preview = strip_tags(substr($res['response'], 0, 150));
        echo "FAILED. Preview: $preview...\n\n";
    }
}

echo "== TESTING PATHS VIA RELAY (MULTIPART) ==\n\n";

foreach ($paths_to_test as $path) {
    echo "Testing Path: $path (Multipart)\n";
    $res = wisphubRelayMultipart($path, $payload);
    
    echo "HTTP Code: " . $res['http_code'] . "\n";
    if ($res['http_code'] >= 200 && $res['http_code'] < 300) {
        echo "SUCCESS! Response: " . $res['response'] . "\n\n";
    } else {
        $preview = strip_tags(substr($res['response'], 0, 150));
        echo "FAILED. Preview: $preview...\n\n";
    }
}
?>
