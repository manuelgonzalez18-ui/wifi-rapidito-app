<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Check 1: Does login_wisphub.php have relay code?
$loginFile = file_get_contents(__DIR__ . '/login_wisphub.php');
$checks = [
    'has_relay_url' => strpos($loginFile, 'wisphub-relay.wifirapidito.workers.dev') !== false,
    'has_relay_secret' => strpos($loginFile, 'wfr-relay-2026-secure') !== false,
    'has_wisphubApiCall' => strpos($loginFile, 'wisphubApiCall') !== false,
    'has_X_Relay_Secret' => strpos($loginFile, 'X-Relay-Secret') !== false,
    'has_old_direct_curl' => strpos($loginFile, "curl_init(\$exactUrl)") !== false,
    'file_size' => strlen($loginFile),
    'last_modified' => date('Y-m-d H:i:s', filemtime(__DIR__ . '/login_wisphub.php'))
];

// Check 2: Test the relay from this server
$RELAY_URL = 'https://wisphub-relay.wifirapidito.workers.dev';
$ch = curl_init($RELAY_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Api-Key OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s',
    'Content-Type: application/json',
    'X-Relay-Secret: wfr-relay-2026-secure',
    'X-Target-Path: /api/clientes/?usuario=yairumilano%40wifi-rapidito&limit=5'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

$data = json_decode($response, true);
$relayTest = [
    'relay_http_code' => $httpCode,
    'relay_error' => $err,
    'relay_count' => $data['count'] ?? 'N/A',
    'relay_results_count' => isset($data['results']) ? count($data['results']) : 0,
    'relay_first_name' => $data['results'][0]['nombre'] ?? 'N/A',
    'relay_snippet' => substr($response, 0, 200)
];

echo json_encode(['login_file_checks' => $checks, 'relay_test' => $relayTest], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
