<?php
/**
 * mod_wifi_password.php - Módulo: Cambiar Clave Wifi
 * Flujo completo con creación de ticket de soporte:
 * 1. Pedir código MAC del router (12 dígitos)
 * 2. Pedir nombre de la comunidad/red
 * 3. Pedir nueva clave deseada
 * 4. Confirmar y crear ticket en WispHub
 */

class ModWifiPassword {

    /**
     * Inicia el flujo de cambio de clave.
     */
    public static function start($session, $from) {
        $client = $session->getClient();

        $msg  = "🔑 *Cambiar Clave WiFi — {$client['nombre']}*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "Para cambiar tu clave necesitamos verificar tu router.\n\n";
        $msg .= "📝 *Paso 1 de 3:* Escribe el *código MAC* de tu router.\n\n";
        $msg .= "Son *12 caracteres* que aparecen en la caja del router o en una etiqueta detrás del equipo.\n\n";
        $msg .= "_Ejemplo: A1B2C3D4E5F6_ 👇";

        BotSender::sendText($from, $msg);
        $session->setState('wifi_mac');
    }

    /**
     * Maneja los pasos del flujo.
     */
    public static function handle($session, $text, $from) {
        $state = $session->getState();

        switch ($state) {
            case 'wifi_mac':
                self::handleMac($session, $text, $from);
                break;
            case 'wifi_community':
                self::handleCommunity($session, $text, $from);
                break;
            case 'wifi_new_password':
                self::handleNewPassword($session, $text, $from);
                break;
            case 'wifi_confirm':
                self::handleConfirm($session, $text, $from);
                break;
        }
    }

    /**
     * Paso 1: Recibir código MAC del router.
     */
    private static function handleMac($session, $text, $from) {
        // Limpiar: quitar espacios, guiones, dos puntos
        $mac = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', trim($text)));

        if (strlen($mac) !== 12) {
            $msg  = "❌ El código MAC debe tener *12 caracteres*.\n\n";
            $msg .= "Búscalo en la caja del router o en la etiqueta detrás del equipo.\n\n";
            $msg .= "_Ejemplo: A1B2C3D4E5F6 o A1:B2:C3:D4:E5:F6_";
            BotSender::sendText($from, $msg);
            return;
        }

        // Formatear MAC con dos puntos
        $macFormatted = implode(':', str_split($mac, 2));
        $session->setFlowData('router_mac', $macFormatted);

        $msg  = "✅ *MAC recibida:* $macFormatted\n\n";
        $msg .= "📡 *Paso 2 de 3:* Escribe el *nombre de tu comunidad* o red WiFi.\n\n";
        $msg .= "_Ejemplo: Residencias Los Pinos_";

        BotSender::sendText($from, $msg);
        $session->setState('wifi_community');
    }

    /**
     * Paso 2: Recibir nombre de la comunidad.
     */
    private static function handleCommunity($session, $text, $from) {
        $community = trim($text);

        if (strlen($community) < 3) {
            BotSender::sendText($from, "❌ El nombre de la comunidad es muy corto. Escríbelo de nuevo:");
            return;
        }

        $session->setFlowData('community', $community);

        $msg  = "✅ Comunidad: *$community*\n\n";
        $msg .= "🔐 *Paso 3 de 3:* Escribe tu *nueva clave WiFi*.\n\n";
        $msg .= "⚠️ Requisitos:\n";
        $msg .= "• Mínimo *8 caracteres*\n";
        $msg .= "• Sin espacios";

        BotSender::sendText($from, $msg);
        $session->setState('wifi_new_password');
    }

    /**
     * Paso 3: Recibir nueva clave.
     */
    private static function handleNewPassword($session, $text, $from) {
        $newPass = trim($text);

        if (strlen($newPass) < 8) {
            BotSender::sendText($from, "❌ La clave debe tener *mínimo 8 caracteres*. Intenta de nuevo:");
            return;
        }

        if (preg_match('/\s/', $newPass)) {
            BotSender::sendText($from, "❌ La clave *no puede contener espacios*. Intenta de nuevo:");
            return;
        }

        $session->setFlowData('new_password', $newPass);

        // Mostrar resumen para confirmar
        $client = $session->getClient();
        $fd = $session->getFlowData();

        $msg  = "📋 *Resumen del cambio de clave:*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "👤 Cliente: *{$client['nombre']}*\n";
        $msg .= "📡 Comunidad: *{$fd['community']}*\n";
        $msg .= "🔑 Nueva clave: *{$fd['new_password']}*\n";
        $msg .= "🔗 MAC Router: *{$fd['router_mac']}*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "¿Los datos son correctos?\n\n";
        $msg .= "*SI* — Crear ticket de soporte\n";
        $msg .= "*NO* — Cancelar y volver al menú";

        BotSender::sendText($from, $msg);
        $session->setState('wifi_confirm');
    }

    /**
     * Paso 4: Confirmar y crear ticket.
     */
    private static function handleConfirm($session, $text, $from) {
        $textLower = strtolower(trim($text));

        if (in_array($textLower, ['no', 'cancelar', 'n'])) {
            BotSender::sendText($from, "❌ Cambio de clave cancelado.\n\nEscribe *menu* para volver al menú.");
            $session->clearFlowData();
            $session->setState('main_menu');
            return;
        }

        if (!in_array($textLower, ['si', 'sí', 's', 'yes', 'confirmar'])) {
            BotSender::sendText($from, "Escribe *SI* para confirmar o *NO* para cancelar.");
            return;
        }

        BotSender::sendText($from, "⏳ Creando ticket de soporte...");

        $client = $session->getClient();
        $fd = $session->getFlowData();

        // 1. Crear ticket en WispHub
        $ticketDesc  = "Cambio De Contraseña En Router Wifi\n\n";
        $ticketDesc .= "Comunidad: {$fd['community']}\n";
        $ticketDesc .= "MAC Router: {$fd['router_mac']}\n";
        $ticketDesc .= "Clave nueva solicitada: {$fd['new_password']}\n\n";
        $ticketDesc .= "Reportado desde: WhatsApp Bot\n";
        $ticketDesc .= "Teléfono: $from";

        // Técnicos reales (rotación)
        $technicians = ['2223475', '2379997', '5853064'];
        date_default_timezone_set('America/Caracas');
        $now = date('d/m/Y H:i');

        // Replicar EXACTAMENTE final_pilot_wisphub.php (servicio=667, Internet Lento → 201 OK)
        $ticketData = [
            'servicio'             => (string)$client['id_servicio'],
            'asunto'               => 'Internet Lento',
            'asuntos_default'      => 'Internet Lento',
            'departamento'         => 'Soporte Técnico',
            'departamentos_default'=> 'Soporte Técnico',
            'descripcion'          => $ticketDesc,
            'razon_falla'          => 'Internet Lento',
            'prioridad'            => '2',
            'estado'               => '1',
            'tecnico'              => $technicians[array_rand($technicians)],
            'origen_reporte'       => 'oficina',
            'fecha_inicio'         => $now,
            'fecha_final'          => $now
        ];

        $jsonPayload = json_encode($ticketData);
        botLog("TICKET PAYLOAD: $jsonPayload");

        $ch = curl_init('https://api.wisphub.app/api/tickets/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Api-Key ' . WISPHUB_TOKEN,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $whResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $responseWH = json_decode($whResponse, true);
        $ticketId = $responseWH['id'] ?? $responseWH['id_ticket'] ?? '---';

        botLog("WiFi password ticket WispHub: HTTP $httpCode | ID: $ticketId | Response: $whResponse | Client: {$client['nombre']}");

        // 2. Enviar email de respaldo
        self::createTicket($client, $fd, $from, $ticketId);

        if ($httpCode >= 200 && $httpCode < 300) {
            $msg  = "✅ *¡Ticket creado exitosamente!*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "🔢 Ticket: *#$ticketId*\n";
            $msg .= "📋 Asunto: Cambio De Contraseña En Router Wifi\n";
            $msg .= "📡 Comunidad: *{$fd['community']}*\n";
            $msg .= "🔑 Nueva clave: *{$fd['new_password']}*\n";
            $msg .= "🔗 MAC: *{$fd['router_mac']}*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "⏰ Nuestro equipo técnico procesará tu solicitud a la brevedad.\n";
            $msg .= "Te notificaremos cuando el cambio esté listo.\n\n";
            $msg .= "Escribe *menu* para volver al menú.";
        } else {
            $msg  = "❌ No se pudo crear el ticket de soporte.\n\n";
            $msg .= "Intenta más tarde o contacta al admin:\n";
            $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
        }

        BotSender::sendText($from, $msg);

        // Notificar al admin
        if ($httpCode >= 200 && $httpCode < 300) {
            $adminMsg  = "🔔 *Nuevo Ticket - Cambio de Clave WiFi*\n";
            $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
            $adminMsg .= "🔢 Ticket: #$ticketId\n";
            $adminMsg .= "👤 Cliente: {$client['nombre']}\n";
            $adminMsg .= "📱 WhatsApp: $from\n";
            $adminMsg .= "🆔 ID Servicio: {$client['id_servicio']}\n";
            $adminMsg .= "📡 Comunidad: {$fd['community']}\n";
            $adminMsg .= "🔑 Clave nueva: {$fd['new_password']}\n";
            $adminMsg .= "🔗 MAC Router: {$fd['router_mac']}\n";
            BotSender::sendText(BOT_ADMIN_WA, $adminMsg);
        }

        $session->clearFlowData();
        $session->setState('main_menu');
    }

    /**
     * Envía email de respaldo con los datos del ticket.
     */
    private static function createTicket($client, $fd, $from, $ticketId = '---') {
        $to = "soporte@wifirapidito.com";
        $subject = "🔑 TICKET #$ticketId CAMBIO CLAVE WIFI: {$client['nombre']} - ID {$client['id_servicio']}";

        $headers = "From: noreply@wifirapidito.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        $body  = "<html><body style='font-family: sans-serif; color: #333;'>";
        $body .= "<h2 style='color: #f59e0b;'>🔑 Solicitud de Cambio de Clave WiFi</h2>";
        $body .= "<hr style='border: 1px solid #eee;'>";
        $body .= "<p><strong>Cliente:</strong> {$client['nombre']}</p>";
        $body .= "<p><strong>ID Servicio:</strong> {$client['id_servicio']}</p>";
        $body .= "<p><strong>Cédula:</strong> {$client['cedula']}</p>";
        $body .= "<p><strong>WhatsApp:</strong> $from</p>";
        $body .= "<p><strong>Comunidad:</strong> {$fd['community']}</p>";
        $body .= "<p><strong>MAC Router:</strong> {$fd['router_mac']}</p>";
        $body .= "<p style='background: #fef3c7; padding: 15px; border-left: 4px solid #f59e0b;'>";
        $body .= "<strong>🔑 Nueva clave solicitada:</strong><br>";
        $body .= "<span style='font-size: 18px; font-weight: bold;'>{$fd['new_password']}</span></p>";
        $body .= "<p><strong>Origen:</strong> Bot WhatsApp Rapidito</p>";
        $body .= "</body></html>";

        $result = mail($to, $subject, $body, $headers);
        
        botLog("WiFi password email: " . ($result ? "SENT" : "FAILED") . " | Client: {$client['nombre']} | MAC: {$fd['router_mac']}");
        
        return $result;
    }
}
?>
