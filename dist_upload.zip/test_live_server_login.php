$ch = curl_init('https://wifirapidito.com/login_wisphub.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['user' => 'anaveliz', 'password' => 'ana12345'])); // from the previous successful direct test
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$res = curl_exec($ch);
echo "Result:\n" . $res;
