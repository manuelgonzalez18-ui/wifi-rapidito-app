const https = require('https');

const options = {
  hostname: 'wifirapidito.com',
  port: 443,
  path: '/wisphub_relay.php',
  method: 'GET',
};

const req = https.request(options, res => {
  let body = '';
  res.on('data', d => body += d);
  res.on('end', () => console.log('HTTP: ' + res.statusCode + '\nBody: ' + body));
});

req.on('error', error => {
  console.error(error);
});

req.end();
