<?php
/**
 * bot_sender.php - Envío de mensajes vía WhatsApp Cloud API
 * Wrapper para la Graph API de Meta.
 */
require_once __DIR__ . '/bot_config.php';

class BotSender {

    /**
     * Envía un mensaje de texto simple.
     */
    public static function sendText($to, $text) {
        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $to,
            'type'              => 'text',
            'text'              => [
                'preview_url' => false,
                'body'        => $text
            ]
        ];
        return self::callAPI($payload);
    }

    /**
     * Envía un mensaje interactivo con botones de lista.
     */
    public static function sendList($to, $bodyText, $buttonText, $sections) {
        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $to,
            'type'              => 'interactive',
            'interactive'       => [
                'type' => 'list',
                'body' => ['text' => $bodyText],
                'action' => [
                    'button'   => $buttonText,
                    'sections' => $sections
                ]
            ]
        ];
        return self::callAPI($payload);
    }

    /**
     * Envía un mensaje interactivo con botones de respuesta rápida (máx 3).
     */
    public static function sendButtons($to, $bodyText, $buttons) {
        $formattedButtons = [];
        foreach ($buttons as $id => $title) {
            $formattedButtons[] = [
                'type'  => 'reply',
                'reply' => [
                    'id'    => (string)$id,
                    'title' => substr($title, 0, 20) // WhatsApp limita a 20 chars
                ]
            ];
        }

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $to,
            'type'              => 'interactive',
            'interactive'       => [
                'type' => 'button',
                'body' => ['text' => $bodyText],
                'action' => [
                    'buttons' => $formattedButtons
                ]
            ]
        ];
        return self::callAPI($payload);
    }

    /**
     * Marca un mensaje como leído.
     */
    public static function markAsRead($messageId) {
        $payload = [
            'messaging_product' => 'whatsapp',
            'status'            => 'read',
            'message_id'        => $messageId
        ];
        return self::callAPI($payload);
    }

    /**
     * Llamada a la Graph API de Meta.
     */
    private static function callAPI($payload) {
        $ch = curl_init(META_API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . META_ACCESS_TOKEN,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            botLog("Meta API CURL Error: $error", 'ERROR');
            return false;
        }

        if ($httpCode !== 200) {
            botLog("Meta API Error ($httpCode): $response", 'ERROR');
            return false;
        }

        botLog("Message sent to {$payload['to']} | Type: {$payload['type']}");
        return json_decode($response, true);
    }

    /**
     * Descarga un archivo multimedia de WhatsApp usando su media ID.
     * Retorna ['data' => binary, 'mime' => 'image/jpeg', 'filename' => '...'] o null.
     */
    public static function downloadMedia($mediaId) {
        if (empty($mediaId)) return null;
        
        // Paso 1: Obtener URL del media
        $metaUrl = 'https://graph.facebook.com/' . META_API_VERSION . '/' . $mediaId;
        $ch = curl_init($metaUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . META_ACCESS_TOKEN
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $response = curl_exec($ch);
        curl_close($ch);
        
        $mediaInfo = json_decode($response, true);
        $downloadUrl = $mediaInfo['url'] ?? '';
        $mimeType = $mediaInfo['mime_type'] ?? 'image/jpeg';
        
        if (empty($downloadUrl)) {
            botLog("downloadMedia: No URL found for media $mediaId", 'ERROR');
            return null;
        }
        
        // Paso 2: Descargar el archivo binario
        $ch2 = curl_init($downloadUrl);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . META_ACCESS_TOKEN
        ]);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch2, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
        $binaryData = curl_exec($ch2);
        $httpCode = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        
        if ($httpCode !== 200 || empty($binaryData)) {
            botLog("downloadMedia: Failed to download media $mediaId (HTTP $httpCode)", 'ERROR');
            return null;
        }
        
        // Determinar extensión
        $ext = 'jpg';
        if (strpos($mimeType, 'png') !== false) $ext = 'png';
        elseif (strpos($mimeType, 'webp') !== false) $ext = 'webp';
        
        botLog("downloadMedia: Downloaded $mediaId (" . strlen($binaryData) . " bytes, $mimeType)");
        
        return [
            'data'     => $binaryData,
            'mime'     => $mimeType,
            'filename' => "whatsapp_$mediaId.$ext"
        ];
    }
}
?>
