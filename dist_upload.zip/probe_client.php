<?php
// Probe para ver la estructura completa de un cliente en WispHub
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

require_once __DIR__ . '/config_wisphub.php';

echo "=== PROBE CLIENT DATA ===\n\n";

// Buscar Juliana
$path = '/api/clientes/?buscar=juliana&limit=3';
$result = wisphubRelay($path);
echo "CLIENTES RESPONSE (HTTP {$result['http_code']}):\n";
echo $result['response'] . "\n\n";

// Buscar servicios
$path2 = '/api/servicios/?cliente=21&limit=5';
$result2 = wisphubRelay($path2);
echo "SERVICIOS ?cliente=21 (HTTP {$result2['http_code']}):\n";
echo $result2['response'] . "\n\n";

// Buscar servicios alt
$path3 = '/api/servicios/?buscar=juliana&limit=5';
$result3 = wisphubRelay($path3);
echo "SERVICIOS ?buscar=juliana (HTTP {$result3['http_code']}):\n";
echo $result3['response'] . "\n\n";

echo "DONE.\n";
?>
