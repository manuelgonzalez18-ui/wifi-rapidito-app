<?php
header("Content-Type: text/plain");

$api_key = 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s';
$url = 'https://api.wisphub.net/api/promesa_pago/';

// Data from user's screenshot
$id_factura = 6900;
$fecha_raw = '2026-04-04';
$fecha_slashes = str_replace('-', '/', $fecha_raw);

$payloads = [
    "JSON with hyphens" => [
        "data" => [
            "id_factura" => $id_factura,
            "fecha_limite" => $fecha_raw,
            "comentarios" => "Debug Promise Automation - Hyphens",
            "accion" => 1
        ],
        "json" => true
    ],
    "JSON with slashes" => [
        "data" => [
            "id_factura" => $id_factura,
            "fecha_limite" => $fecha_slashes,
            "comentarios" => "Debug Promise Automation - Slashes",
            "accion" => 1
        ],
        "json" => true
    ],
    "Form-Data with slashes" => [
        "data" => [
            "id_factura" => $id_factura,
            "fecha_limite" => $fecha_slashes,
            "comentarios" => "Debug Promise Automation - Form",
            "accion" => 1
        ],
        "json" => false
    ]
];

foreach ($payloads as $name => $test) {
    echo "--- Testing: $name ---\n";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Api-Key ' . $api_key,
        $test['json'] ? 'Content-Type: application/json' : 'Content-Type: multipart/form-data'
    ]);
    
    $body = $test['json'] ? json_encode($test['data']) : $test['data'];
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "Response Code: $code\n";
    echo "Response Body: $response\n\n";
}
?>
