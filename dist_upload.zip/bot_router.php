<?php
/**
 * bot_router.php - Motor de conversación del Bot WhatsApp Rapidito
 * Maneja el estado de cada conversación y enruta a los módulos correspondientes.
 */
require_once __DIR__ . '/bot_config.php';
require_once __DIR__ . '/bot_sender.php';

// Cargar módulos
require_once __DIR__ . '/bot_modules/mod_debt.php';
require_once __DIR__ . '/bot_modules/mod_bankinfo.php';
require_once __DIR__ . '/bot_modules/mod_status.php';
require_once __DIR__ . '/bot_modules/mod_payment.php';
require_once __DIR__ . '/bot_modules/mod_fault.php';
require_once __DIR__ . '/bot_modules/mod_wifi_password.php';
require_once __DIR__ . '/bot_modules/mod_promise.php';

class BotRouter {

    /**
     * Punto de entrada principal. Recibe la sesión y el mensaje del usuario.
     */
    public static function handle($session, $text, $from) {
        $text = trim($text);
        $textLower = strtolower($text);

        // Comandos globales (funcionan en cualquier estado)
        if (in_array($textLower, ['menu', 'menú', 'inicio', 'empezar'])) {
            if ($session->isAuthenticated()) {
                $session->setState('main_menu');
                $session->clearFlowData();
                self::sendMainMenu($session, $from);
                return;
            } else {
                $session->reset();
                self::sendWelcome($from);
                return;
            }
        }

        if (in_array($textLower, ['salir', 'exit', 'bye', 'chao', 'adios', 'adiós'])) {
            BotSender::sendText($from, "👋 ¡Hasta luego! Escribe en cualquier momento para volver a chatear con " . BOT_NAME . " ⚡");
            $session->reset();
            return;
        }

        // Saludo inicial (hola, hi, etc.) — SIEMPRE reinicia la conversación desde cero
        if (in_array($textLower, ['hola', 'hi', 'hey', 'buenas', 'buenos dias', 'buenas tardes', 'buenas noches', 'saludos'])) {
            $session->reset();
            self::sendWelcome($from);
            return;
        }

        // ========================================
        // DETECCIÓN DE INTENCIÓN POR PALABRAS CLAVE
        // Solo funciona desde main_menu (NO durante flujos activos)
        // ========================================
        if ($session->isAuthenticated()) {
            $currentState = $session->getState();
            // Solo detectar intención desde main_menu (evita interrumpir flujos activos)
            $inActiveFlow = (
                $currentState !== 'main_menu' &&
                $currentState !== 'awaiting_username'
            );
            
            if (!$inActiveFlow) {
                $detectedModule = self::detectIntent($textLower);
                if ($detectedModule && $currentState !== 'awaiting_username') {
                    $session->clearFlowData();
                    self::launchModule($session, $detectedModule, $from);
                    return;
                }
            }
        }

        // Obtener estado actual
        $state = $session->getState();
        botLog("Router | Phone: $from | State: $state | Input: $text");

        // Enrutar según estado
        switch ($state) {

            // ========================================
            // PASO 0: Identificación por usuario
            // ========================================
            case 'awaiting_username':
                self::handleIdentification($session, $text, $from);
                break;

            // ========================================
            // MENÚ PRINCIPAL: Espera selección
            // ========================================
            case 'main_menu':
                self::handleMenuSelection($session, $text, $from);
                break;

            // ========================================
            // MÓDULO: Consultar Deuda
            // ========================================
            case 'debt_flow':
                ModDebt::handle($session, $text, $from);
                break;

            // ========================================
            // MÓDULO: Reportar Pago
            // ========================================
            case 'payment_type':
            case 'payment_bank':
            case 'payment_phone_emisor':
            case 'payment_reference':
            case 'payment_amount':
            case 'payment_date':
            case 'payment_confirm':
                ModPayment::handle($session, $text, $from);
                break;

            // ========================================
            // MÓDULO: Reportar Falla (todos los tipos)
            // ========================================
            case 'fault_type_select':
            case 'fault_name':
            case 'fault_phone':
            case 'fault_community':
            case 'fault_mac':
            case 'fault_red_light':
            case 'fault_description':
                ModFault::handle($session, $text, $from);
                break;

            // ========================================
            // MÓDULO: Cambiar Clave Wifi (Ticket)
            // ========================================
            case 'wifi_mac':
            case 'wifi_community':
            case 'wifi_new_password':
            case 'wifi_confirm':
                ModWifiPassword::handle($session, $text, $from);
                break;

            // ========================================
            // MÓDULO: Promesa de Pago
            // ========================================
            case 'promise_date':
            case 'promise_confirm':
                ModPromise::handle($session, $text, $from);
                break;

            // ========================================
            // ESTADO DESCONOCIDO: Resetear
            // ========================================
            default:
                botLog("Unknown state: $state for $from. Resetting.", 'WARN');
                if ($session->isAuthenticated()) {
                    $session->setState('main_menu');
                    self::sendMainMenu($session, $from);
                } else {
                    $session->reset();
                    self::sendWelcome($from);
                }
                break;
        }
    }

    // ========================================
    // MENSAJES DEL SISTEMA
    // ========================================

    /**
     * Enviar bienvenida (primera interacción).
     */
    private static function sendWelcome($from) {
        $msg  = "¡Hola! Soy *" . BOT_NAME . "* ⚡ tu asistente de Wifi Rapidito.\n\n";
        $msg .= "Para comenzar, dime tu *nombre de usuario*.\n";
        $msg .= "Es tu usuario asignado en Wifi Rapidito 📶\n\n";
        $msg .= "_Ejemplo: normaavila_";

        BotSender::sendText($from, $msg);
    }

    /**
     * Buscar usuario en WispHub y cargar perfil en sesión.
     */
    private static function handleIdentification($session, $text, $from) {
        $username = strtolower(trim($text));
        
        // Limpiar input
        $username = preg_replace('/[^a-z0-9._@-]/', '', $username);

        if (empty($username)) {
            BotSender::sendText($from, "❌ Por favor escribe tu nombre de usuario.\n\n_Ejemplo: normaavila_");
            return;
        }

        BotSender::sendText($from, "🔍 Buscando tu cuenta...");

        // Agregar sufijo si no tiene @
        $searchUser = $username;
        if (strpos($username, '@') === false && !is_numeric($username)) {
            $searchUser = $username . '@wifi-rapidito';
        }

        // Estrategia 1: Búsqueda exacta por usuario
        $path = '/api/clientes/?usuario=' . urlencode($searchUser) . '&limit=10';
        $result = wisphubRelay($path);
        $data = json_decode($result['response'], true);
        $candidates = $data['results'] ?? [];

        // Estrategia 2: Si es numérico, buscar por cédula
        if (empty($candidates) && is_numeric($username)) {
            $path2 = '/api/clientes/?cedula=' . urlencode($username) . '&limit=10';
            $result2 = wisphubRelay($path2);
            $data2 = json_decode($result2['response'], true);
            $candidates = $data2['results'] ?? [];
        }

        // Estrategia 3: Fallback búsqueda general
        if (empty($candidates)) {
            $path3 = '/api/clientes/?buscar=' . urlencode($username) . '&limit=10';
            $result3 = wisphubRelay($path3);
            $data3 = json_decode($result3['response'], true);
            $candidates = $data3['results'] ?? [];
        }

        if (empty($candidates)) {
            $msg  = "❌ *Usuario no encontrado*\n\n";
            $msg .= "Verifica tu usuario e intenta de nuevo.\n";
            $msg .= "Tu usuario es el que te fue asignado en Wifi Rapidito (sin espacios, sin @).\n\n";
            $msg .= "_Ejemplo: normaavila_\n\n";
            $msg .= "💡 Si no recuerdas tu usuario, escribe al admin:\n";
            $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
            BotSender::sendText($from, $msg);
            return;
        }

        // Buscar match exacto entre los candidatos
        $client = null;
        $uClean = str_replace('@wifi-rapidito', '', $username);

        foreach ($candidates as $c) {
            $uPortal = strtolower(str_replace('@wifi-rapidito', '', $c['usuario'] ?? ''));
            if ($uPortal === $uClean) {
                $client = $c;
                break;
            }
        }

        // Si no hubo match exacto por usuario, verificar por cédula (si es numérico)
        if (!$client && is_numeric($username)) {
            foreach ($candidates as $c) {
                if (($c['cedula'] ?? '') === $username) {
                    $client = $c;
                    break;
                }
            }
        }

        // Si después de validar no hay match real, informar al usuario
        if (!$client) {
            $msg  = "❌ *Usuario no encontrado*\n\n";
            $msg .= "No encontré una cuenta que coincida con *$username*.\n";
            $msg .= "Verifica tu usuario e intenta de nuevo.\n\n";
            $msg .= "_Ejemplo: normaavila_\n\n";
            $msg .= "💡 Si no recuerdas tu usuario, escribe al admin:\n";
            $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
            BotSender::sendText($from, $msg);
            return;
        }

        // Cargar datos de promesa de pago
        $promesaInfo = null;
        $clientId = $client['id_servicio'] ?? $client['id_cliente'] ?? '';
        if (!empty($clientId)) {
            $pathP = '/api/promesas-pago/?cliente=' . $clientId;
            $resultP = wisphubRelay($pathP);
            $dataP = json_decode($resultP['response'], true);
            if (isset($dataP['results']) && count($dataP['results']) > 0) {
                $promesaInfo = $dataP['results'][0];
            }
        }

        // Buscar el ID de servicio REAL (para tickets de WispHub)
        // /api/clientes/ devuelve id_servicio que es el ID del cliente, NO del servicio
        $realServiceId = $clientId; // fallback
        $cedula = $client['cedula'] ?? '';
        if (!empty($cedula)) {
            $pathS = '/api/servicios/?cedula=' . urlencode($cedula) . '&limit=5';
            $resultS = wisphubRelay($pathS);
            $dataS = json_decode($resultS['response'], true);
            $servicios = $dataS['results'] ?? [];
            if (!empty($servicios)) {
                $realServiceId = $servicios[0]['id_servicio'] ?? $servicios[0]['id'] ?? $clientId;
                botLog("Service lookup by cedula $cedula: found service ID $realServiceId");
            } else {
                // Fallback: buscar por nombre
                $nombre = $client['nombre'] ?? '';
                $pathS2 = '/api/servicios/?buscar=' . urlencode($nombre) . '&limit=5';
                $resultS2 = wisphubRelay($pathS2);
                $dataS2 = json_decode($resultS2['response'], true);
                $servicios2 = $dataS2['results'] ?? [];
                if (!empty($servicios2)) {
                    $realServiceId = $servicios2[0]['id_servicio'] ?? $servicios2[0]['id'] ?? $clientId;
                    botLog("Service lookup by name $nombre: found service ID $realServiceId");
                }
            }
        }

        // Guardar perfil en sesión
        $clientProfile = [
            'id_servicio'    => $realServiceId,
            'id_cliente'     => $client['id_cliente'] ?? $clientId,
            'usuario'        => $client['usuario'] ?? '',
            'nombre'         => $client['nombre'] ?? 'Cliente',
            'cedula'         => $client['cedula'] ?? '',
            'telefono'       => $client['telefono'] ?? '',
            'saldo'          => $client['saldo'] ?? '0.00',
            'estado'         => $client['estado'] ?? 'ACTIVO',
            'direccion'      => $client['direccion_principal'] ?? '',
            'password_servicio' => $client['password_servicio'] ?? '',
            'promesa_pago'   => $promesaInfo
        ];

        $session->setClient($clientProfile);
        botLog("User identified: {$clientProfile['nombre']} (ID: {$clientProfile['id_servicio']}) for phone $from");

        // Mostrar confirmación + menú
        $estadoEmoji = (strtoupper($clientProfile['estado']) === 'ACTIVO') ? '🟢' : '🔴';
        
        $msg  = "✅ *¡Te encontré!*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "👤 *{$clientProfile['nombre']}*\n";
        $msg .= "📡 Estado: $estadoEmoji {$clientProfile['estado']}\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n";

        BotSender::sendText($from, $msg);

        // Enviar menú
        self::sendMainMenu($session, $from);
    }

    /**
     * Enviar menú principal.
     */
    public static function sendMainMenu($session, $from) {
        $client = $session->getClient();
        $name = $client['nombre'] ?? 'Cliente';

        $menuOptions = json_decode(MENU_OPTIONS, true);
        $msg = "¿En qué puedo ayudarte, *$name*?\n\n";
        
        foreach ($menuOptions as $num => $opt) {
            $msg .= "*$num.* {$opt['label']}\n";
        }
        
        $msg .= "\nEscribe el *número* de la opción 👇";

        BotSender::sendText($from, $msg);
    }

    /**
     * Procesar selección del menú principal.
     */
    private static function handleMenuSelection($session, $text, $from) {
        $menuOptions = json_decode(MENU_OPTIONS, true);
        $text = trim($text);

        // Primero intentar por número
        if (isset($menuOptions[$text])) {
            $module = $menuOptions[$text]['module'];
            $session->clearFlowData();
            botLog("Menu selection: $text -> module: $module for $from");
            self::launchModule($session, $module, $from);
            return;
        }

        // Si no es número, intentar por lenguaje natural
        $detectedModule = self::detectIntent(strtolower($text));
        if ($detectedModule) {
            $session->clearFlowData();
            botLog("Menu NLP selection: '$text' -> module: $detectedModule for $from");
            self::launchModule($session, $detectedModule, $from);
            return;
        }

        // No entendido
        BotSender::sendText($from, "❓ No entendí tu selección.\n\nPuedes escribir un *número* (1-7) o decirme qué necesitas, por ejemplo:\n• _cuánto debo_\n• _reportar pago_\n• _cambiar clave_\n• _datos bancarios_\n\nO escribe *menu* para ver las opciones.");
    }

    /**
     * Detectar intención por palabras clave.
     * Retorna el módulo detectado o null si no se reconoce.
     */
    private static function detectIntent($text) {
        $intentMap = [
            'debt' => [
                'deuda', 'debo', 'cuanto debo', 'cuánto debo', 'saldo', 'factura',
                'facturas', 'cobro', 'cuanto es', 'cuánto es', 'precio',
                'mensualidad', 'bolivares', 'bolívares', 'consultar deuda'
            ],
            'payment' => [
                'pago', 'pagar', 'reportar pago', 'reporte', 'transferencia',
                'transferi', 'pagué', 'pague', 'deposito', 'depósito',
                'ya pagué', 'ya pague', 'referencia', 'comprobante'
            ],
            'bankinfo' => [
                'datos bancarios', 'cuenta', 'numero de cuenta', 'número de cuenta',
                'pago movil', 'pago móvil', 'donde pago', 'como pago', 'cómo pago',
                'a donde transfiero', 'banco', 'datos del banco', 'datos para pagar'
            ],
            'fault_nointernet' => [
                'sin internet', 'no tengo internet', 'no conecta', 'no me conecta',
                'no agarra', 'sin servicio', 'no funciona', 'se cayó', 'se cayo'
            ],
            'fault_slow' => [
                'internet lento', 'lento', 'muy lento', 'va lento', 'tarda mucho'
            ],
            'fault_intermittent' => [
                'intermitente', 'se va y viene', 'inestable', 'se desconecta'
            ],
            'fault_massive' => [
                'falla masiva', 'todos sin internet', 'falla general', 'toda la zona'
            ],
            'fault' => [
                'falla', 'problema', 'reportar falla', 'ticket', 'soporte', 'ayuda técnica'
            ],
            'wifi_password' => [
                'clave', 'contraseña', 'password', 'cambiar clave', 'cambiar contraseña',
                'clave wifi', 'clave del wifi', 'nueva clave', 'resetear clave'
            ],
            'status' => [
                'estado', 'mi estado', 'servicio', 'activo', 'suspendido',
                'cortado', 'estoy activo', 'mi servicio', 'estado del servicio'
            ],
            'promise' => [
                'promesa', 'promesa de pago', 'plazo', 'dame tiempo',
                'extensión', 'extension', 'solicitar promesa', 'prórroga', 'prorroga'
            ],
        ];

        foreach ($intentMap as $module => $keywords) {
            foreach ($keywords as $keyword) {
                if (strpos($text, $keyword) !== false) {
                    return $module;
                }
            }
        }

        return null;
    }

    /**
     * Lanzar un módulo específico.
     */
    private static function launchModule($session, $module, $from) {
        switch ($module) {
            case 'debt':
                ModDebt::start($session, $from);
                break;
            case 'payment':
                ModPayment::start($session, $from);
                break;
            case 'bankinfo':
                ModBankInfo::start($session, $from);
                break;
            case 'fault_nointernet':
                ModFault::startTyped($session, $from, 'Sin Internet', '🔴');
                break;
            case 'fault_slow':
                ModFault::startTyped($session, $from, 'Internet Lento', '🟡');
                break;
            case 'fault_intermittent':
                ModFault::startTyped($session, $from, 'Intermitente', '🟦');
                break;
            case 'fault_massive':
                ModFault::startTyped($session, $from, 'Falla Masiva en mi Comunidad', '⚠️');
                break;
            case 'fault':
                ModFault::start($session, $from);
                break;
            case 'wifi_password':
                ModWifiPassword::start($session, $from);
                break;
            case 'status':
                ModStatus::start($session, $from);
                break;
            case 'promise':
                ModPromise::start($session, $from);
                break;
            default:
                BotSender::sendText($from, "⚙️ Esta función está en desarrollo. Intenta otra opción.");
                break;
        }
    }
}
?>
