<?php
// Test script to invoke proxy_banesco.php directly and print strictly its raw output.
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST['invoice_id'] = '6896';
$_POST['reference'] = '12346022338';
$_POST['amount'] = '578';
$_POST['user_name'] = 'Test';
$_POST['payment_date'] = '2026-03-05';
$_POST['forma_pago'] = 16749;
$_POST['payment_type'] = 'tf_banesco';
$_POST['payment_type_label'] = 'Transferencia de Banesco a Banesco';

// Capture output
ob_start();
try {
    require __DIR__ . '/proxy_banesco.php';
} catch (Throwable $e) {
    echo "CAUGHT EXCEPTION: " . $e->getMessage() . "\n" . $e->getTraceAsString();
}
$output = ob_get_clean();

echo "=== RAW OUTPUT START ===\n";
echo $output;
echo "\n=== RAW OUTPUT END ===\n";
?>
