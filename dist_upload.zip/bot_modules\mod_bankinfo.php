<?php
/**
 * mod_bankinfo.php - Módulo: Datos bancarios
 * Muestra datos bancarios estáticos para que el cliente haga su pago.
 */

class ModBankInfo {

    public static function start($session, $from) {
        $bankInfo = json_decode(BANK_INFO, true);
        $t = $bankInfo['transferencia'];
        $p = $bankInfo['pago_movil'];

        $msg  = "🏦 *Datos Bancarios de WiFi Rapidito*\n";
        $msg .= "Para facilitar el pago de tu mensualidad:\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "📱 *Para Pago Móvil:*\n";
        $msg .= "Banco: {$p['banco']}\n";
        $msg .= "Teléfono: {$p['telefono']}\n";
        $msg .= "Documento: {$p['cedula']}\n\n";
        $msg .= "🏛️ *Para Transferencias o Depósitos:*\n";
        $msg .= "A nombre de:\n";
        $msg .= "_{$t['titular']}_\n";
        $msg .= "Documento: {$t['rif']}\n";
        $msg .= "N° de Cuenta: {$t['cuenta']}\n";
        $msg .= "Banco: {$t['banco']}\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "Recuerda reportar tu pago una vez realizado. ¡Gracias!\n";
        $msg .= "💡 Escribe *2* para reportar tu pago o *menu* para volver.";

        BotSender::sendText($from, $msg);
        $session->setState('main_menu');
    }
}
?>
