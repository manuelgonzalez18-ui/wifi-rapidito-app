<?php
/**
 * bot_config.php - Configuración centralizada del Bot de WhatsApp Rapidito
 * V1.0 - Asistente Virtual Wifi Rapidito
 */

// Importar configuración WispHub existente
require_once __DIR__ . '/config_wisphub.php';

// =============================================
// META WHATSAPP CLOUD API
// =============================================
define('META_VERIFY_TOKEN', 'rapidito_whatsapp_2026');  // Token para verificar webhook
define('META_ACCESS_TOKEN', 'EAAfAd3ZCedFcBRA9UDWvinDq229wcwQPfDrYqzpqkGyrZCN3SU1ufNLWsuQwwva8BZC6NMai4CweNz0RN0iYfIaZBXqaQhUFykAheZCGu7rjJTBCmviPT5IqNXNHbWgRYChN3Bqaq3pBq7RNZBz0bpvCgYTtcSGSMdHTNYa15DxTNll9cYc21qkiieMUugPfKZA4gZDZD');
define('META_PHONE_ID',     '1034484946421943');
define('META_API_VERSION',  'v25.0');
define('META_API_URL',      'https://graph.facebook.com/' . META_API_VERSION . '/' . META_PHONE_ID . '/messages');
define('META_APP_SECRET',   'aba73209eb32e7a1337d5c9840af9312');

// =============================================
// BOT IDENTITY
// =============================================
define('BOT_NAME',       'Rapidito');
define('BOT_ADMIN_WA',   '584120330315'); // Número del admin para escalamiento
define('BOT_LOG_FILE',   __DIR__ . '/bot_whatsapp.log');

// =============================================
// SESSION CONFIG
// =============================================
define('BOT_SESSION_DIR',    __DIR__ . '/bot_sessions/');
define('BOT_SESSION_TTL',    3600); // 1 hora de inactividad = sesión expirada
define('BOT_RATE_LIMIT_MSG', 10);   // Máximo 10 mensajes por minuto
define('BOT_RATE_LIMIT_PAY', 3);    // Máximo 3 intentos de pago por hora

// =============================================
// DATOS BANCARIOS (ESTÁTICOS)
// =============================================
define('BANK_INFO', json_encode([
    'transferencia' => [
        'banco'    => 'Banesco',
        'cuenta'   => '0134-0332-56-3321061868',
        'rif'      => 'J-402638850',
        'titular'  => 'Inversiones Tu Super PC 2013 C.A'
    ],
    'pago_movil' => [
        'telefono' => '0412-0330315',
        'cedula'   => 'J-402638850',
        'banco'    => 'Banesco'
    ]
]));

// =============================================
// MENÚ PRINCIPAL
// =============================================
define('MENU_OPTIONS', json_encode([
    '1' => ['label' => '💰 ¿Cuánto debo?',              'module' => 'debt'],
    '2' => ['label' => '💳 Reportar Pago',               'module' => 'payment'],
    '3' => ['label' => '🏦 Datos Bancarios',             'module' => 'bankinfo'],
    '4' => ['label' => '🔴 Sin Internet',                'module' => 'fault_nointernet'],
    '5' => ['label' => '🟡 Internet Lento',              'module' => 'fault_slow'],
    '6' => ['label' => '🟦 Intermitente',                'module' => 'fault_intermittent'],
    '7' => ['label' => '⚠️ Falla Masiva en mi Comunidad', 'module' => 'fault_massive'],
    '8' => ['label' => '🔑 Cambiar Clave',               'module' => 'wifi_password'],
    '9' => ['label' => '📊 Estado de mi Servicio',       'module' => 'status'],
    '10' => ['label' => '💜 Promesa de Pago',            'module' => 'promise'],
]));

// =============================================
// MAPEO DE BANCOS (para Banesco API)
// =============================================
define('BANK_MAP', json_encode([
    '1'  => ['name' => '0102 - Banco de Venezuela',                'code' => '0102'],
    '2'  => ['name' => '0104 - Venezolano de Crédito',             'code' => '0104'],
    '3'  => ['name' => '0105 - Banco Mercantil',                   'code' => '0105'],
    '4'  => ['name' => '0108 - BBVA Provincial',                   'code' => '0108'],
    '5'  => ['name' => '0114 - Bancaribe',                         'code' => '0114'],
    '6'  => ['name' => '0115 - Banco Exterior',                    'code' => '0115'],
    '7'  => ['name' => '0128 - Banco Caroní',                      'code' => '0128'],
    '8'  => ['name' => '0134 - Banesco',                           'code' => '0134'],
    '9'  => ['name' => '0137 - Banco Sofitasa',                    'code' => '0137'],
    '10' => ['name' => '0138 - Banco Plaza',                       'code' => '0138'],
    '11' => ['name' => '0146 - Bangente',                          'code' => '0146'],
    '12' => ['name' => '0151 - Fondo Común (BFC)',                 'code' => '0151'],
    '13' => ['name' => '0156 - 100% Banco',                        'code' => '0156'],
    '14' => ['name' => '0157 - Delsur Banco Universal',            'code' => '0157'],
    '15' => ['name' => '0163 - Banco del Tesoro',                  'code' => '0163'],
    '16' => ['name' => '0166 - Banco Agrícola',                    'code' => '0166'],
    '17' => ['name' => '0168 - Bancrecer',                         'code' => '0168'],
    '18' => ['name' => '0169 - Banco Microfinanciero',             'code' => '0169'],
    '19' => ['name' => '0171 - Banco Activo',                      'code' => '0171'],
    '20' => ['name' => '0172 - Bancamiga',                         'code' => '0172'],
    '21' => ['name' => '0174 - Banplus',                           'code' => '0174'],
    '22' => ['name' => '0175 - Banco Digital de los Trabajadores', 'code' => '0175'],
    '23' => ['name' => '0177 - Banfanb',                           'code' => '0177'],
    '24' => ['name' => '0178 - N58 Banco Digital',                 'code' => '0178'],
    '25' => ['name' => '0191 - Banco Nacional de Crédito',         'code' => '0191'],
    '26' => ['name' => '0601 - Instituto Municipal de Crédito',    'code' => '0601'],
]));

// =============================================
// LOGGING
// =============================================
function botLog($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] [$level] $message\n";
    @file_put_contents(BOT_LOG_FILE, $entry, FILE_APPEND);
}

// Crear directorio de sesiones si no existe
if (!is_dir(BOT_SESSION_DIR)) {
    @mkdir(BOT_SESSION_DIR, 0755, true);
}
?>
