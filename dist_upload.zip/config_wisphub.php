<?php
// config_wisphub.php - Configuración centralizada para API de Wisphub
define('WISPHUB_TOKEN', 'OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s');
define('WISPHUB_API_URL', 'https://api.wisphub.app/api/');
define('WISPHUB_STAFF_USER', 'admin@wifi-rapidito');

// --- RELAY via Hostinger (bypass IP block) ---
define('WISPHUB_RELAY_URL', 'https://wifirapidito.com/wisphub_relay.php');
define('WISPHUB_RELAY_SECRET', 'wfr-relay-2026-secure');

// Aliases para compatibilidad con scripts existentes
define('VPS_RELAY_URL', WISPHUB_RELAY_URL);
define('VPS_RELAY_SECRET', WISPHUB_RELAY_SECRET);
define('WISPHUB_API_KEY', WISPHUB_TOKEN);

function wisphubRelay($path, $method = 'GET', $body = null) {
    $ch = curl_init(WISPHUB_RELAY_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    $headers = [
        'Authorization: Api-Key ' . WISPHUB_TOKEN,
        'Content-Type: application/json',
        'X-Relay-Secret: ' . WISPHUB_RELAY_SECRET,
        'X-Target-Path: ' . $path
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    if ($body) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['response' => $response, 'http_code' => $httpCode];
}

function wisphubRelayMultipart($path, $fields) {
    $ch = curl_init(WISPHUB_RELAY_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    $headers = [
        'Authorization: Api-Key ' . WISPHUB_TOKEN,
        'X-Relay-Secret: ' . WISPHUB_RELAY_SECRET,
        'X-Target-Path: ' . $path
        // Content-Type will be automatically set to multipart/form-data by cURL
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['response' => $response, 'http_code' => $httpCode];
}
?>
