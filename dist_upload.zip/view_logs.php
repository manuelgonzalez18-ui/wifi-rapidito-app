<?php
// Simple script to read the last N lines of api_logs.txt
$logFile = __DIR__ . '/api_logs.txt';
$linesToRead = 20;

header("Content-Type: text/plain");

if (!file_exists($logFile)) {
    echo "Log file not found at: $logFile\n";
    exit;
}

$file = file($logFile);
$lastLines = array_slice($file, -$linesToRead);

echo "--- LAST $linesToRead LINES OF api_logs.txt ---\n\n";
foreach ($lastLines as $line) {
    echo $line;
}
?>
