const https = require('https');

const data = JSON.stringify({ user: 'anaveliz', password: '123' });

const options = {
  hostname: 'wifirapidito.com',
  port: 443,
  path: '/login_wisphub.php',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = https.request(options, res => {
  let body = '';
  res.on('data', d => body += d);
  res.on('end', () => console.log('HTTP: ' + res.statusCode + '\nBody: ' + body));
});

req.on('error', error => {
  console.error(error);
});

req.write(data);
req.end();
