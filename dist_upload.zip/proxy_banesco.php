<?php
/**
 * proxy_banesco.php - Proxy para Validación Automática Banesco + Registro en WispHub
 * Endpoint: POST /api/facturas/{id}/registrar-pago/
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

ob_start(); // Prevenir cualquier salida accidental antes del JSON

require_once __DIR__ . '/banesco_api.php';
require_once __DIR__ . '/config_wisphub.php';

// ── ARCHIVO DE REFERENCIAS VALIDADAS ──
define('VALIDATED_REFS_FILE', __DIR__ . '/validated_references.json');

// Mapa forma_pago (Consistente con proxy_payments.php)
const FORMAS_PAGO_MAP = [
    'transferencia' => 16749,
    'efectivo'      => 16748,
];

/**
 * Verifica si una referencia ya fue validada previamente.
 * @return array|null  Datos de la validación previa, o null si es nueva.
 */
function checkDuplicateReference($referencia) {
    if (!file_exists(VALIDATED_REFS_FILE)) {
        return null;
    }

    $data = json_decode(file_get_contents(VALIDATED_REFS_FILE), true);
    if (!is_array($data)) return null;

    // Buscar la referencia (key = referencia normalizada)
    $refKey = trim($referencia);
    if (isset($data[$refKey])) {
        return $data[$refKey];
    }

    return null;
}

/**
 * Registra una referencia como validada exitosamente.
 */
function saveValidatedReference($referencia, $facturaId, $monto, $nombreUser, $paymentType = '') {
    $data = [];
    if (file_exists(VALIDATED_REFS_FILE)) {
        $data = json_decode(file_get_contents(VALIDATED_REFS_FILE), true);
        if (!is_array($data)) $data = [];
    }

    $refKey = trim($referencia);
    $now = new DateTime('now', new DateTimeZone('America/Caracas'));

    $data[$refKey] = [
        'referencia'    => $refKey,
        'factura_id'    => $facturaId,
        'monto'         => $monto,
        'nombre_user'   => $nombreUser,
        'payment_type'  => $paymentType,
        'validated_at'  => $now->format('Y-m-d H:i:s'),
        'validated_date' => $now->format('d/m/Y'),
        'validated_time' => $now->format('h:i:s A'),
    ];

    file_put_contents(VALIDATED_REFS_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

/**
 * Registra el pago en WispHub tras validación exitosa en Banesco.
 * Utiliza el endpoint corregido: /api/facturas/{id}/registrar-pago/
 */
function registrarPagoAutorizado($facturaId, $referencia, $fechaPago, $formaPago, $totalCobrado) {
    // Endpoint corregido tras pruebas terminales: /api/facturas/{id}/registrar-pago/
    $targetPath = "/api/facturas/{$facturaId}/registrar-pago/";
    
    // WispHub exige YYYY-MM-DD hh:mm para registrar-pago explícitamente si se envía fecha
    $fechaFormateada = date('Y-m-d H:i', strtotime($fechaPago));
    
    $payload = [
        'referencia'    => $referencia,
        'fecha_pago'    => $fechaFormateada,
        'total_cobrado' => (float)$totalCobrado,
        'accion'        => 1, // ACTIVACIÓN AUTOMÁTICA
        'forma_pago'    => (int)$formaPago
    ];
    
    $ch = curl_init(VPS_RELAY_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Api-Key ' . WISPHUB_TOKEN,
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Relay-Secret: ' . VPS_RELAY_SECRET,
            'X-Target-Path: ' . $targetPath,
        ],
    ]);

    $response  = curl_exec($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        throw new Exception("Error de conexión WispHub (registrar-pago): $curlError");
    }

    $data = json_decode($response, true);

    if ($httpCode !== 200 && $httpCode !== 201) {
        if (isset($data['errors'])) {
            $errorMsg = "";
            foreach ($data['errors'] as $field => $msgs) {
                $errorMsg .= "$field: " . implode(", ", $msgs) . ". ";
            }
            throw new Exception("WispHub Error: $errorMsg");
        }
        $msg = $data['detail'] ?? "Error HTTP $httpCode en registrar-pago";
        throw new Exception($msg);
    }

    return [
        'success' => true,
        'data'    => $data
    ];
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }

    $facturaId = $_POST['invoice_id'] ?? null;
    $referencia = trim($_POST['reference'] ?? '');
    $monto = $_POST['amount'] ?? 0;
    $fecha = $_POST['payment_date'] ?? date('Y-m-d H:i');
    $nombreUser = $_POST['user_name'] ?? '';
    $formaPago = $_POST['forma_pago'] ?? 16749;
    $paymentType = $_POST['payment_type'] ?? '';
    $paymentTypeLabel = $_POST['payment_type_label'] ?? '';

    if (!$facturaId || !$referencia || !$monto) {
        throw new Exception("Faltan datos requeridos (Factura, Referencia o Monto)");
    }

    // ═══ PASO 0: Verificar referencia duplicada ═══
    $prevValidation = checkDuplicateReference($referencia);
    if ($prevValidation) {
        ob_end_clean();
        http_response_code(409); // Conflict
        echo json_encode([
            'status'  => 'duplicate',
            'message' => "Esta referencia ya fue validada el {$prevValidation['validated_date']} a las {$prevValidation['validated_time']}. No se permite validar la misma referencia más de una vez.",
            'validated_at'   => $prevValidation['validated_at'],
            'validated_date' => $prevValidation['validated_date'],
            'validated_time' => $prevValidation['validated_time'],
            'factura_id'     => $prevValidation['factura_id'],
        ]);
        exit;
    }

    // 1. Validar en Banesco
    $banescoResponse = BanescoAPI::checkTransaction($referencia, [
        'amount'       => $monto,
        'payment_date' => $fecha,
        'banco_origen' => $_POST['banco_origen'] ?? null,
        'phone_emisor' => $_POST['phone_emisor'] ?? null
    ]);
    
    if (!$banescoResponse['success']) {
        throw new Exception("Error Banesco: " . $banescoResponse['message']);
    }

    // 2. Si Banesco confirma, registrar en WispHub para auto-activación
    $resultado = registrarPagoAutorizado($facturaId, $referencia, $fecha, $formaPago, $monto);

    // 3. Guardar referencia como validada (prevenir duplicados futuros)
    saveValidatedReference($referencia, $facturaId, $monto, $nombreUser, $paymentTypeLabel);

    ob_end_clean();
    echo json_encode([
        'status'  => 'success',
        'message' => '¡Pago validado y servicio activado automáticamente!',
        'banesco' => $banescoResponse['data'],
        'wisphub' => $resultado['data']
    ]);

} catch (Exception $e) {
    if (ob_get_length()) ob_end_clean();
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
