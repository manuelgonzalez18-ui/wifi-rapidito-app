const https = require('https');
const http = require('http');

const options = {
  hostname: 'srv1293381.hstgr.cloud',
  port: 80,
  path: '/wisphub_relay.php',
  method: 'GET',
};

const req = http.request(options, res => {
  let body = '';
  res.on('data', d => body += d);
  res.on('end', () => console.log('HTTP: ' + res.statusCode + '\nBody: ' + body));
});

req.on('error', error => {
  console.error(error);
});

req.end();
