<?php
require_once __DIR__ . '/config_wisphub.php';
header("Content-Type: text/plain");

$search = "6900";
echo "Searching for invoice: $search...\n";

$path = "/api/facturas/?search=" . urlencode($search);
$res = wisphubRelay($path);

echo "HTTP Code: " . $res['http_code'] . "\n";
echo "Response: " . $res['response'] . "\n";
?>
