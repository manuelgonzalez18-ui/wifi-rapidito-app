<?php
/**
 * bot_session.php - Gestor de sesiones del Bot WhatsApp Rapidito
 * Almacena sesiones por número de teléfono en archivos JSON.
 */
require_once __DIR__ . '/bot_config.php';

class BotSession {
    
    private $phone;
    private $filePath;
    private $data;

    public function __construct($phone) {
        $this->phone = preg_replace('/\D/', '', $phone);
        $this->filePath = BOT_SESSION_DIR . $this->phone . '.json';
        $this->load();
    }

    /**
     * Carga la sesión desde disco, o crea una nueva si no existe/expiró.
     */
    private function load() {
        if (file_exists($this->filePath)) {
            $raw = file_get_contents($this->filePath);
            $this->data = json_decode($raw, true);
            
            // Verificar expiración
            if (isset($this->data['last_activity'])) {
                $elapsed = time() - $this->data['last_activity'];
                if ($elapsed > BOT_SESSION_TTL) {
                    botLog("Session expired for {$this->phone} (inactive {$elapsed}s)");
                    $this->reset();
                    return;
                }
            }
        } else {
            $this->reset();
        }
    }

    /**
     * Resetea la sesión a estado inicial (solicitar usuario).
     */
    public function reset() {
        $this->data = [
            'phone'         => $this->phone,
            'state'         => 'awaiting_username',
            'client'        => null,
            'flow_data'     => [],
            'msg_count'     => 0,
            'pay_attempts'  => 0,
            'last_activity' => time(),
            'created_at'    => time()
        ];
        $this->save();
    }

    /**
     * Guardar sesión a disco.
     */
    public function save() {
        $this->data['last_activity'] = time();
        @file_put_contents($this->filePath, json_encode($this->data, JSON_PRETTY_PRINT));
    }

    // --- GETTERS ---

    public function getState()    { return $this->data['state'] ?? 'awaiting_username'; }
    public function getClient()   { return $this->data['client'] ?? null; }
    public function getFlowData() { return $this->data['flow_data'] ?? []; }
    public function getPhone()    { return $this->phone; }
    
    public function isAuthenticated() {
        return !empty($this->data['client']);
    }

    // --- SETTERS ---

    public function setState($state) {
        $this->data['state'] = $state;
        $this->save();
    }

    public function setClient($clientData) {
        $this->data['client'] = $clientData;
        $this->data['state'] = 'main_menu';
        $this->save();
    }

    public function setFlowData($key, $value) {
        $this->data['flow_data'][$key] = $value;
        $this->save();
    }

    public function clearFlowData() {
        $this->data['flow_data'] = [];
        $this->save();
    }

    // --- RATE LIMITING ---

    /**
     * Incrementa conteo de mensajes. Retorna false si excede el límite.
     */
    public function checkRateLimit() {
        $this->data['msg_count'] = ($this->data['msg_count'] ?? 0) + 1;
        
        // Reset counter cada minuto
        $minuteKey = 'rate_minute_' . date('YmdHi');
        if (!isset($this->data[$minuteKey])) {
            $this->data[$minuteKey] = 0;
            // Limpiar contadores viejos
            foreach ($this->data as $k => $v) {
                if (strpos($k, 'rate_minute_') === 0 && $k !== $minuteKey) {
                    unset($this->data[$k]);
                }
            }
        }
        $this->data[$minuteKey]++;
        $this->save();
        
        return $this->data[$minuteKey] <= BOT_RATE_LIMIT_MSG;
    }

    /**
     * Incrementa intentos de pago. Retorna false si excede el límite.
     */
    public function checkPaymentLimit() {
        $hourKey = 'pay_hour_' . date('YmdH');
        if (!isset($this->data[$hourKey])) {
            $this->data[$hourKey] = 0;
        }
        $this->data[$hourKey]++;
        $this->save();
        
        return $this->data[$hourKey] <= BOT_RATE_LIMIT_PAY;
    }
}
?>
