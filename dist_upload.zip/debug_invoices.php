<?php
header('Content-Type: text/plain; charset=UTF-8');

echo "=== CHECK VALIDATED REFS ===\n\n";

$file = __DIR__ . '/validated_references.json';
echo "Path: $file\n";
echo "Exists: " . (file_exists($file) ? 'YES' : 'NO') . "\n";

if (file_exists($file)) {
    echo "Size: " . filesize($file) . " bytes\n";
    echo "Writable: " . (is_writable($file) ? 'YES' : 'NO') . "\n\n";
    $data = json_decode(file_get_contents($file), true);
    echo "Entries: " . (is_array($data) ? count($data) : 'INVALID JSON') . "\n\n";
    if (is_array($data)) {
        foreach ($data as $ref => $info) {
            echo "  [$ref] => factura #{$info['factura_id']} | {$info['nombre_user']} | {$info['validated_at']} | source: " . ($info['source'] ?? 'portal') . "\n";
        }
    }
} else {
    echo "\nFile does not exist. Creating empty one...\n";
    file_put_contents($file, json_encode([], JSON_PRETTY_PRINT));
    echo "Created: " . (file_exists($file) ? 'YES' : 'FAILED') . "\n";
}

echo "\n--- Bot module path check ---\n";
$botPath = __DIR__ . '/bot_modules/../validated_references.json';
echo "Bot resolves to: " . realpath($botPath) . "\n";
echo "Same file: " . (realpath($botPath) === realpath($file) ? 'YES' : 'NO') . "\n";

echo "\nDONE.\n";
?>
