<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banesco - Validación de Pagos | Wifi Rapidito</title>
    <link rel="icon" type="image/png" href="./favicon.png" />
    <!-- Google Fonts: Orbitron & Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        :root {
            --primary: #00824b;
            --primary-glow: rgba(0, 130, 75, 0.3);
            --bg: #030712;
            --glass: rgba(15, 23, 42, 0.8);
            --neon-blue: #00f3ff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg);
            background-image: 
                radial-gradient(circle at 50% -20%, rgba(0, 130, 75, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 0% 100%, rgba(0, 243, 255, 0.05) 0%, transparent 40%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 540px;
            perspective: 1000px;
        }

        .glass-panel {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 24px;
            padding: 35px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); max-height: 0; }
            to { opacity: 1; transform: translateY(0); max-height: 500px; }
        }

        .header {
            text-align: center;
            margin-bottom: 25px;
        }

        .logo-container {
            width: 60px;
            height: 60px;
            background: rgba(0, 130, 75, 0.1);
            border: 1px solid rgba(0, 130, 75, 0.3);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            box-shadow: 0 0 20px var(--primary-glow);
        }

        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 5px;
            background: linear-gradient(to right, #fff, #00f3ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            font-size: 0.7rem;
            color: rgba(0, 243, 255, 0.5);
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        /* ── Payment Type Cards ── */
        .payment-type-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }

        .payment-type-card {
            background: rgba(255, 255, 255, 0.02);
            border: 2px solid rgba(255, 255, 255, 0.08);
            border-radius: 14px;
            padding: 14px 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: left;
            position: relative;
            overflow: hidden;
        }

        .payment-type-card:hover {
            border-color: rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.04);
            transform: translateY(-1px);
        }

        .payment-type-card.selected {
            transform: translateY(-1px);
        }

        .payment-type-card .card-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
            transition: all 0.3s;
        }

        .payment-type-card .card-label {
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: rgba(255, 255, 255, 0.7);
            line-height: 1.3;
            transition: color 0.3s;
        }

        .payment-type-card .card-desc {
            font-size: 0.55rem;
            color: rgba(255, 255, 255, 0.3);
            margin-top: 4px;
            letter-spacing: 0.3px;
        }

        .payment-type-card .check-dot {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .payment-type-card .check-dot .dot-inner {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            transform: scale(0);
            transition: transform 0.2s ease;
        }

        .payment-type-card.selected .check-dot .dot-inner {
            transform: scale(1);
        }

        /* Card Color Variants */
        .card-pm-banesco.selected { border-color: rgba(34, 197, 94, 0.4); background: rgba(34, 197, 94, 0.08); }
        .card-pm-banesco .card-icon { background: rgba(34, 197, 94, 0.1); }
        .card-pm-banesco.selected .card-label { color: #4ade80; }
        .card-pm-banesco.selected .check-dot { border-color: rgba(34, 197, 94, 0.5); }
        .card-pm-banesco .check-dot .dot-inner { background: linear-gradient(135deg, #22c55e, #10b981); }

        .card-pm-otros.selected { border-color: rgba(59, 130, 246, 0.4); background: rgba(59, 130, 246, 0.08); }
        .card-pm-otros .card-icon { background: rgba(59, 130, 246, 0.1); }
        .card-pm-otros.selected .card-label { color: #60a5fa; }
        .card-pm-otros.selected .check-dot { border-color: rgba(59, 130, 246, 0.5); }
        .card-pm-otros .check-dot .dot-inner { background: linear-gradient(135deg, #3b82f6, #06b6d4); }

        .card-tf-banesco.selected { border-color: rgba(168, 85, 247, 0.4); background: rgba(168, 85, 247, 0.08); }
        .card-tf-banesco .card-icon { background: rgba(168, 85, 247, 0.1); }
        .card-tf-banesco.selected .card-label { color: #c084fc; }
        .card-tf-banesco.selected .check-dot { border-color: rgba(168, 85, 247, 0.5); }
        .card-tf-banesco .check-dot .dot-inner { background: linear-gradient(135deg, #a855f7, #7c3aed); }

        .card-tf-otros.selected { border-color: rgba(245, 158, 11, 0.4); background: rgba(245, 158, 11, 0.08); }
        .card-tf-otros .card-icon { background: rgba(245, 158, 11, 0.1); }
        .card-tf-otros.selected .card-label { color: #fbbf24; }
        .card-tf-otros.selected .check-dot { border-color: rgba(245, 158, 11, 0.5); }
        .card-tf-otros .check-dot .dot-inner { background: linear-gradient(135deg, #f59e0b, #ea580c); }

        /* ── Section Label ── */
        .section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--neon-blue);
            margin-bottom: 12px;
            opacity: 0.7;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* ── Form Fields ── */
        .form-group {
            margin-bottom: 16px;
        }

        label {
            display: block;
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: #00f3ff;
            margin-bottom: 6px;
            opacity: 0.8;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(0, 243, 255, 0.3);
            pointer-events: none;
        }

        input, select {
            width: 100%;
            background: rgba(15, 23, 42, 0.4);
            border: 1px solid rgba(0, 243, 255, 0.1);
            border-radius: 12px;
            padding: 13px 15px 13px 42px;
            color: #fff;
            font-size: 0.9rem;
            transition: all 0.3s;
            outline: none;
            -webkit-appearance: none;
            appearance: none;
        }

        select {
            cursor: pointer;
            padding-right: 40px;
        }

        .select-arrow {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(0, 243, 255, 0.4);
            pointer-events: none;
        }

        select option {
            background: #0f172a;
            color: #fff;
        }

        input:focus, select:focus {
            border-color: rgba(0, 243, 255, 0.4);
            background: rgba(0, 243, 255, 0.05);
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.1);
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.2);
        }

        input[readonly] {
            opacity: 0.6;
            cursor: not-allowed;
            background: rgba(0, 0, 0, 0.2);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        /* Conditional fields container */
        .conditional-fields {
            animation: slideDown 0.4s ease-out;
            overflow: hidden;
        }

        .label-amber { color: #fbbf24 !important; }
        .label-green { color: #4ade80 !important; }

        .required { color: #ef4444; }

        .ref-hint {
            font-size: 0.55rem;
            color: rgba(0, 243, 255, 0.35);
            margin-top: 4px;
            font-weight: normal;
            text-transform: none;
            letter-spacing: 0;
        }

        /* ── Form Section (hidden by default) ── */
        #form-section {
            display: none;
            animation: slideDown 0.4s ease-out;
        }

        #form-section.visible {
            display: block;
        }

        /* Selected type badge */
        .selected-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 8px;
            font-size: 0.58rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 16px;
        }

        /* ── Submit Button ── */
        .btn-submit {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--primary), #00663d);
            border: none;
            border-radius: 14px;
            color: #fff;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 16px;
            box-shadow: 0 10px 20px -5px rgba(0, 130, 75, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 0.85rem;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px -10px rgba(0, 130, 75, 0.5);
            filter: brightness(1.1);
        }

        .btn-submit:active { transform: translateY(0); }
        .btn-submit:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .info-box {
            background: rgba(0, 243, 255, 0.03);
            border: 1px solid rgba(0, 243, 255, 0.1);
            border-radius: 12px;
            padding: 14px;
            margin-top: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .info-box p {
            font-size: 0.65rem;
            color: rgba(255, 255, 255, 0.5);
            line-height: 1.5;
        }

        .rate-badge {
            display: inline-block;
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.2);
            color: #4ade80;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.62rem;
            font-weight: bold;
            margin-top: 6px;
        }

        #status-msg {
            margin-top: 15px;
            padding: 12px;
            border-radius: 10px;
            font-size: 0.8rem;
            text-align: center;
            display: none;
        }

        .msg-success { background: rgba(34, 197, 94, 0.2); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3); }
        .msg-error { background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .msg-duplicate { background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }

        .loading-spinner {
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top: 2px solid #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 5px; }

        /* Responsive */
        @media (max-width: 480px) {
            .payment-type-grid { grid-template-columns: 1fr; }
            .glass-panel { padding: 25px; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="glass-panel">
            <div class="header">
                <div class="logo-container">
                    <i data-lucide="zap" stroke-width="3" style="color: #4ade80;"></i>
                </div>
                <h1>Banesco Pay</h1>
                <p class="subtitle">Validación Instantánea</p>
            </div>

            <!-- ═══ PASO 1: Selección de Tipo de Pago ═══ -->
            <div class="section-label">
                <i data-lucide="credit-card" size="14"></i>
                ¿Cómo realizó su pago?
            </div>

            <div class="payment-type-grid" id="type-grid">
                <div class="payment-type-card card-pm-banesco" data-type="pm_banesco" onclick="selectPaymentType(this)">
                    <div class="check-dot"><div class="dot-inner"></div></div>
                    <div class="card-icon">
                        <i data-lucide="smartphone" size="18" style="color: #4ade80;"></i>
                    </div>
                    <div class="card-label">Pago Móvil de Banesco a Banesco</div>
                    <div class="card-desc">Entre cuentas Banesco</div>
                </div>

                <div class="payment-type-card card-pm-otros" data-type="pm_interbancario" onclick="selectPaymentType(this)">
                    <div class="check-dot"><div class="dot-inner"></div></div>
                    <div class="card-icon">
                        <i data-lucide="arrow-right-left" size="18" style="color: #60a5fa;"></i>
                    </div>
                    <div class="card-label">Pago Móvil de Otros Bancos a Banesco</div>
                    <div class="card-desc">Desde otro banco hacia Banesco</div>
                </div>

                <div class="payment-type-card card-tf-banesco" data-type="tf_banesco" onclick="selectPaymentType(this)">
                    <div class="check-dot"><div class="dot-inner"></div></div>
                    <div class="card-icon">
                        <i data-lucide="building-2" size="18" style="color: #c084fc;"></i>
                    </div>
                    <div class="card-label">Transferencia de Banesco a Banesco</div>
                    <div class="card-desc">Entre cuentas Banesco</div>
                </div>

                <div class="payment-type-card card-tf-otros" data-type="tf_interbancario" onclick="selectPaymentType(this)">
                    <div class="check-dot"><div class="dot-inner"></div></div>
                    <div class="card-icon">
                        <i data-lucide="landmark" size="18" style="color: #fbbf24;"></i>
                    </div>
                    <div class="card-label">Transferencia de Otros Bancos a Banesco</div>
                    <div class="card-desc">Desde otro banco hacia Banesco</div>
                </div>
            </div>

            <!-- ═══ PASO 2: Formulario (visible tras selección) ═══ -->
            <div id="form-section">
                <div id="selected-badge" class="selected-badge"></div>

                <form id="payment-form">
                    <!-- Campos condicionales: Banco Origen -->
                    <div class="form-group conditional-fields" id="field-banco" style="display: none;">
                        <label class="label-amber"><i data-lucide="building-2" size="10" style="display:inline; vertical-align: middle;"></i> Banco Origen <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i data-lucide="building-2" size="18"></i>
                            <select id="banco_origen">
                                <option value="">-- Seleccione su banco --</option>
                                <option value="0102">0102 - Banco de Venezuela</option>
                                <option value="0104">0104 - Venezolano de Crédito</option>
                                <option value="0105">0105 - Banco Mercantil</option>
                                <option value="0108">0108 - Banco Provincial (BBVA)</option>
                                <option value="0114">0114 - Bancaribe</option>
                                <option value="0115">0115 - Banco Exterior</option>
                                <option value="0116">0116 - Banco Occidental de Descuento (BOD)</option>
                                <option value="0128">0128 - Banco Caroní</option>
                                <option value="0134">0134 - Banesco</option>
                                <option value="0137">0137 - Banco Sofitasa</option>
                                <option value="0138">0138 - Banco Plaza</option>
                                <option value="0146">0146 - Bangente</option>
                                <option value="0151">0151 - BFC Banco Fondo Común</option>
                                <option value="0156">0156 - 100% Banco</option>
                                <option value="0157">0157 - Banco DelSur</option>
                                <option value="0163">0163 - Banco del Tesoro</option>
                                <option value="0166">0166 - Banco Agrícola de Venezuela</option>
                                <option value="0168">0168 - Bancrecer</option>
                                <option value="0169">0169 - Mi Banco</option>
                                <option value="0171">0171 - Banco Activo</option>
                                <option value="0172">0172 - Bancamiga</option>
                                <option value="0174">0174 - Banplus</option>
                                <option value="0175">0175 - Banco Bicentenario</option>
                                <option value="0176">0176 - Banco Espirito Santo</option>
                                <option value="0177">0177 - Banfanb</option>
                                <option value="0178">0178 - Banco Nacional de Crédito (BNC)</option>
                                <option value="0191">0191 - Banco Nacional de Crédito (BNC)</option>
                            </select>
                            <span class="select-arrow"><i data-lucide="chevron-down" size="16"></i></span>
                        </div>
                    </div>

                    <!-- Campos condicionales: Teléfono Emisor -->
                    <div class="form-group conditional-fields" id="field-phone" style="display: none;">
                        <label class="label-green"><i data-lucide="phone" size="10" style="display:inline; vertical-align: middle;"></i> Teléfono Emisor <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i data-lucide="phone" size="18"></i>
                            <input type="tel" id="phone_emisor" placeholder="Ej: 584121234567 o 04121234567" maxlength="12">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>ID de Factura <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i data-lucide="hash" size="18"></i>
                            <input type="text" id="invoice_id" placeholder="Ej: 5866" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Referencia Bancaria <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i data-lucide="activity" size="18"></i>
                            <input type="text" id="reference" placeholder="Dígitos numéricos" required>
                        </div>
                        <div id="ref-hint" class="ref-hint"></div>
                    </div>

                    <div class="form-group">
                        <label>Monto a Pagar (Bs)</label>
                        <div class="input-wrapper">
                            <i data-lucide="dollar-sign" size="18"></i>
                            <input type="number" id="amount" step="0.01" placeholder="0.00" required>
                        </div>
                        <div id="bcv-container">
                            <span class="rate-badge" id="bcv-rate" style="display: none;">Cargando tasa BCV...</span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Fecha de Pago</label>
                            <input type="date" id="payment_date" required style="padding-left: 15px;">
                        </div>
                        <div class="form-group">
                            <label>Nombre Titular</label>
                            <input type="text" id="user_name" placeholder="Opcional" style="padding-left: 15px;">
                        </div>
                    </div>

                    <button type="submit" class="btn-submit" id="submit-btn">
                        <span>Validar y Activar</span>
                        <i data-lucide="arrow-right" size="20"></i>
                    </button>

                    <div id="status-msg"></div>
                </form>
            </div>

            <div class="info-box">
                <i data-lucide="info" size="24" style="color: #00f3ff; flex-shrink: 0;"></i>
                <p>Esta herramienta valida su transferencia directamente con Banesco. La activación es automática tras confirmar el depósito.</p>
            </div>
        </div>
    </div>

    <script>
        // Init Lucide Icons
        lucide.createIcons();

        // ── Constants & Config ──
        const PRECIO_USD = 25;
        const submitBtn = document.getElementById('submit-btn');
        const statusMsg = document.getElementById('status-msg');
        const bcvBadge = document.getElementById('bcv-rate');
        const amountInput = document.getElementById('amount');
        const paymentDateInput = document.getElementById('payment_date');
        const formSection = document.getElementById('form-section');
        const referenceInput = document.getElementById('reference');
        const refHint = document.getElementById('ref-hint');
        const phoneInput = document.getElementById('phone_emisor');
        const bancoSelect = document.getElementById('banco_origen');

        // Payment Type Configuration
        const PAYMENT_CONFIG = {
            pm_banesco: {
                label: 'Pago Móvil de Banesco a Banesco',
                badgeClass: 'background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); color: #4ade80;',
                needsBank: false,
                needsPhone: true,
                refMin: 6, refMax: 6,
                refHintText: 'Ingrese SOLO los últimos 6 dígitos',
            },
            pm_interbancario: {
                label: 'Pago Móvil de Otros Bancos a Banesco',
                badgeClass: 'background: rgba(59,130,246,0.1); border: 1px solid rgba(59,130,246,0.3); color: #60a5fa;',
                needsBank: true,
                needsPhone: true,
                refMin: 6, refMax: 6,
                refHintText: 'Ingrese SOLO los últimos 6 dígitos',
            },
            tf_banesco: {
                label: 'Transferencia de Banesco a Banesco',
                badgeClass: 'background: rgba(168,85,247,0.1); border: 1px solid rgba(168,85,247,0.3); color: #c084fc;',
                needsBank: false,
                needsPhone: false,
                refMin: 12, refMax: 12,
                refHintText: 'Ingrese los 12 dígitos completos',
            },
            tf_interbancario: {
                label: 'Transferencia de Otros Bancos a Banesco',
                badgeClass: 'background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); color: #fbbf24;',
                needsBank: true,
                needsPhone: false,
                refMin: 6, refMax: 6,
                refHintText: 'Ingrese SOLO los últimos 6 dígitos',
            },
        };

        let selectedType = null;

        // Set default date
        paymentDateInput.value = new Date().toISOString().split('T')[0];

        // Only allow numbers in reference and phone
        referenceInput.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/\D/g, '');
        });
        phoneInput.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/\D/g, '');
        });

        // ── Fetch BCV Rate ──
        async function fetchBcv() {
            try {
                const res = await fetch('https://ve.dolarapi.com/v1/dolares/oficial');
                const data = await res.json();
                const rate = data.promedio || data.venta || data.compra;
                if (rate) {
                    bcvBadge.textContent = "Tasa BCV: " + rate.toFixed(2) + " Bs/$";
                    bcvBadge.style.display = "inline-block";
                    const calculated = (rate * PRECIO_USD).toFixed(2);
                    amountInput.value = calculated;
                }
            } catch (err) {
                console.error("BCV Error", err);
            }
        }
        fetchBcv();

        // ── Payment Type Selection ──
        function selectPaymentType(cardEl) {
            const type = cardEl.dataset.type;
            const config = PAYMENT_CONFIG[type];
            if (!config) return;

            selectedType = type;

            // Deselect all cards
            document.querySelectorAll('.payment-type-card').forEach(c => c.classList.remove('selected'));
            // Select this card
            cardEl.classList.add('selected');

            // Show form section
            formSection.classList.add('visible');
            formSection.style.display = 'block';

            // Update badge
            const badge = document.getElementById('selected-badge');
            badge.style.cssText = config.badgeClass;
            badge.textContent = config.label;

            // Show/hide conditional fields
            document.getElementById('field-banco').style.display = config.needsBank ? 'block' : 'none';
            document.getElementById('field-phone').style.display = config.needsPhone ? 'block' : 'none';

            // Update reference hint
            refHint.textContent = config.refHintText;
            referenceInput.maxLength = config.refMax;
            refHint.style.color = '#00f3ff'; // Reset color
            refHint.style.opacity = '0.8';

            // Reset conditional values when switching
            if (!config.needsBank) bancoSelect.value = '';
            if (!config.needsPhone) phoneInput.value = '';

            // Re-init lucide icons for new elements
            lucide.createIcons();
        }

        // ── Form Submit ──
        document.getElementById('payment-form').addEventListener('submit', async (e) => {
            e.preventDefault();

            if (!selectedType) {
                showError('Debe seleccionar cómo realizó su pago');
                return;
            }

            const config = PAYMENT_CONFIG[selectedType];

            // Validate reference length EXTREMELY Strictly (exact length required)
            const ref = referenceInput.value.trim();
            if (!ref || ref.length !== config.refMin) {
                showError(`${config.refHintText}`);
                refHint.style.color = '#ef4444'; // Red error hint
                return;
            }

            // Validate bank if needed
            if (config.needsBank && !bancoSelect.value) {
                showError('Debe seleccionar el banco desde donde realizó el pago');
                return;
            }

            // Validate phone if needed
            if (config.needsPhone) {
                const phone = phoneInput.value.trim();
                if (!phone || phone.length < 10 || phone.length > 12) {
                    showError('Ingrese un número de teléfono emisor válido (ej: 04121234567)');
                    return;
                }
            }

            // UI Loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<div class="loading-spinner"></div> Validando...';
            statusMsg.style.display = "none";

            const formData = new FormData();
            formData.append('invoice_id', document.getElementById('invoice_id').value);
            formData.append('reference', ref);
            formData.append('amount', document.getElementById('amount').value);
            formData.append('user_name', document.getElementById('user_name').value);
            formData.append('payment_date', document.getElementById('payment_date').value);
            formData.append('payment_type', selectedType);
            formData.append('payment_type_label', config.label);

            if (config.needsBank && bancoSelect.value) {
                formData.append('banco_origen', bancoSelect.value);
                formData.append('banco_origen_nombre', bancoSelect.options[bancoSelect.selectedIndex].text);
            }
            if (config.needsPhone && phoneInput.value) {
                formData.append('phone_emisor', phoneInput.value);
            }

            try {
                const response = await fetch('proxy_banesco.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (response.ok && result.status === 'success') {
                    statusMsg.className = "msg-success";
                    statusMsg.innerHTML = "<strong>¡PAGO EXITOSO!</strong><br>" + result.message;
                    statusMsg.style.display = "block";
                    submitBtn.style.display = "none";
                } else if (response.status === 409 && result.status === 'duplicate') {
                    statusMsg.className = "msg-duplicate";
                    statusMsg.innerHTML = `<strong><i data-lucide="alert-triangle" size="16" style="display:inline; vertical-align:text-bottom;"></i> REFERENCIA DUPLICADA</strong><br>${result.message}`;
                    statusMsg.style.display = "block";
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<span>Validar y Activar</span><i data-lucide="arrow-right" size="20"></i>';
                    lucide.createIcons();
                } else {
                    throw new Error(result.message || "Error al validar pago.");
                }
            } catch (err) {
                showError(err.message);
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<span>Validar y Activar</span><i data-lucide="arrow-right" size="20"></i>';
                lucide.createIcons();
            }
        });

        function showError(msg) {
            statusMsg.className = "msg-error";
            statusMsg.innerHTML = "<strong>ERROR</strong><br>" + msg;
            statusMsg.style.display = "block";
        }
    </script>
</body>
</html>
