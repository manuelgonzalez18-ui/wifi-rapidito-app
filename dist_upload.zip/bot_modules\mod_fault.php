<?php
/**
 * mod_fault.php - Módulo: Reportar Fallas
 * 4 tipos de falla:
 * - Sin Internet (🔴) → Pide: nombre, teléfono, comunidad, MAC, luz roja, descripción
 * - Internet Lento (🟡) → Igual
 * - Intermitente (🟦) → Igual
 * - Falla Masiva (⚠️) → Igual PERO SIN MAC
 * 
 * Flujo: Tipo → Nombre → Teléfono → Comunidad → [MAC] → Luz roja → Descripción → Ticket
 */

class ModFault {

    /**
     * Inicia el flujo genérico (sin tipo preseleccionado).
     */
    public static function start($session, $from) {
        $client = $session->getClient();

        $msg  = "🚨 *Reportar Falla — {$client['nombre']}*\n\n";
        $msg .= "¿Qué tipo de falla estás experimentando?\n\n";
        $msg .= "*1.* 🔴 Sin Internet\n";
        $msg .= "*2.* 🟡 Internet Lento\n";
        $msg .= "*3.* 🟦 Intermitente\n";
        $msg .= "*4.* ⚠️ Falla Masiva en mi Comunidad\n\n";
        $msg .= "Escribe el *número* 👇";

        BotSender::sendText($from, $msg);
        $session->setState('fault_type_select');
    }

    /**
     * Inicia el flujo con tipo preseleccionado (desde menú principal).
     */
    public static function startTyped($session, $from, $faultType, $emoji) {
        $client = $session->getClient();
        $session->setFlowData('fault_type', $faultType);
        $session->setFlowData('fault_emoji', $emoji);
        $session->setFlowData('is_masiva', (strpos($faultType, 'Falla Masiva') !== false));

        // Pre-llenar nombre del cliente
        $session->setFlowData('client_name', $client['nombre'] ?? '');

        $msg  = "$emoji *Reporte: $faultType*\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
        $msg .= "Para crear tu ticket de soporte necesitamos algunos datos.\n\n";
        $msg .= "📝 *Nombre y Apellido:*\n";
        $msg .= "_Si es correcto, escribe_ *ok*\n";
        $msg .= "Nombre actual: *{$client['nombre']}*";

        BotSender::sendText($from, $msg);
        $session->setState('fault_name');
    }

    /**
     * Maneja todos los pasos del flujo.
     */
    public static function handle($session, $text, $from) {
        $state = $session->getState();

        switch ($state) {
            case 'fault_type_select':
                self::handleTypeSelect($session, $text, $from);
                break;
            case 'fault_name':
                self::handleName($session, $text, $from);
                break;
            case 'fault_phone':
                self::handlePhone($session, $text, $from);
                break;
            case 'fault_community':
                self::handleCommunity($session, $text, $from);
                break;
            case 'fault_mac':
                self::handleMAC($session, $text, $from);
                break;
            case 'fault_red_light':
                self::handleRedLight($session, $text, $from);
                break;
            case 'fault_description':
                self::handleDescription($session, $text, $from);
                break;
        }
    }

    /**
     * Selección de tipo de falla (flujo genérico).
     */
    private static function handleTypeSelect($session, $text, $from) {
        $types = [
            '1' => ['name' => 'Sin Internet',    'emoji' => '🔴'],
            '2' => ['name' => 'Internet Lento',   'emoji' => '🟡'],
            '3' => ['name' => 'Intermitente',      'emoji' => '🟦'],
            '4' => ['name' => 'Falla Masiva en mi Comunidad', 'emoji' => '⚠️'],
        ];

        $key = trim($text);
        if (!isset($types[$key])) {
            BotSender::sendText($from, "❌ Selecciona un número del *1* al *4*.");
            return;
        }

        // Reusar startTyped para iniciar el formulario
        self::startTyped($session, $from, $types[$key]['name'], $types[$key]['emoji']);
    }

    // === PASO 1: Nombre ===
    private static function handleName($session, $text, $from) {
        $textLower = strtolower(trim($text));
        $client = $session->getClient();

        if (in_array($textLower, ['ok', 'si', 'sí', 'correcto'])) {
            $session->setFlowData('ticket_name', $client['nombre']);
        } else {
            $session->setFlowData('ticket_name', trim($text));
        }

        $name = $session->getFlowData()['ticket_name'];
        BotSender::sendText($from, "✅ Nombre: *$name*");

        // Paso 2: Teléfono
        $phone = $client['telefono'] ?? '';
        $msg  = "📱 *Teléfono de contacto:*\n";
        if (!empty($phone)) {
            $msg .= "_Si es correcto, escribe_ *ok*\n";
            $msg .= "Teléfono actual: *$phone*";
        } else {
            $msg .= "_Ejemplo: 04121234567_";
        }
        BotSender::sendText($from, $msg);
        $session->setState('fault_phone');
    }

    // === PASO 2: Teléfono ===
    private static function handlePhone($session, $text, $from) {
        $textLower = strtolower(trim($text));
        $client = $session->getClient();

        if (in_array($textLower, ['ok', 'si', 'sí', 'correcto']) && !empty($client['telefono'])) {
            $phone = $client['telefono'];
        } else {
            $phone = preg_replace('/\D/', '', $text);
            if (strlen($phone) < 10 || strlen($phone) > 12) {
                BotSender::sendText($from, "❌ Número inválido. Debe tener *11 dígitos*.\n_Ejemplo: 04121234567_");
                return;
            }
        }

        $session->setFlowData('ticket_phone', $phone);
        BotSender::sendText($from, "✅ Teléfono: *$phone*");

        // Paso 3: Comunidad
        $msg = "🏘️ *Nombre de tu comunidad / urbanización:*\n\n_Ejemplo: Urb. Los Olivos, Sector 3_";
        BotSender::sendText($from, $msg);
        $session->setState('fault_community');
    }

    // === PASO 3: Comunidad ===
    private static function handleCommunity($session, $text, $from) {
        $community = trim($text);
        if (strlen($community) < 3) {
            BotSender::sendText($from, "❌ Escribe el nombre de tu comunidad o sector.");
            return;
        }

        $session->setFlowData('ticket_community', $community);
        BotSender::sendText($from, "✅ Comunidad: *$community*");

        $fd = $session->getFlowData();

        // Si es Falla Masiva, NO pedir MAC → saltar a luz roja
        if (!empty($fd['is_masiva'])) {
            self::askRedLight($session, $from);
        } else {
            // Paso 4: MAC
            $msg  = "📦 *Código MAC de tu router:*\n\n";
            $msg .= "Son *12 caracteres* que aparecen en la caja o detrás del router.\n\n";
            $msg .= "_Ejemplo: A1B2C3D4E5F6_\n\n";
            $msg .= "Si no lo tienes, escribe *no*";
            BotSender::sendText($from, $msg);
            $session->setState('fault_mac');
        }
    }

    // === PASO 4: MAC (solo Sin Internet, Lento, Intermitente) ===
    private static function handleMAC($session, $text, $from) {
        $textLower = strtolower(trim($text));

        if (in_array($textLower, ['no', 'n', 'no tengo', 'no lo tengo'])) {
            $session->setFlowData('ticket_mac', 'No proporcionada');
            BotSender::sendText($from, "⏩ MAC omitida.");
        } else {
            // Limpiar MAC (quitar : - espacios)
            $mac = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', $text));
            if (strlen($mac) !== 12) {
                BotSender::sendText($from, "❌ La MAC debe tener *12 caracteres alfanuméricos*.\n\n_Ejemplo: A1B2C3D4E5F6_\n\nSi no la tienes, escribe *no*");
                return;
            }
            // Formatear con :
            $macFormatted = implode(':', str_split($mac, 2));
            $session->setFlowData('ticket_mac', $macFormatted);
            BotSender::sendText($from, "✅ MAC: *$macFormatted*");
        }

        self::askRedLight($session, $from);
    }

    // === Pregunta luz roja ===
    private static function askRedLight($session, $from) {
        $msg  = "🔴 *¿Tu router tiene alguna luz roja encendida?*\n\n";
        $msg .= "*1.* Sí, tiene luz roja\n";
        $msg .= "*2.* No, todas las luces están normales\n";
        $msg .= "*3.* No sé / No puedo verificar";
        BotSender::sendText($from, $msg);
        $session->setState('fault_red_light');
    }

    // === PASO 5: Luz roja ===
    private static function handleRedLight($session, $text, $from) {
        $key = trim($text);
        $options = [
            '1' => 'Sí, tiene luz roja',
            '2' => 'No, luces normales',
            '3' => 'No sabe / No verificó',
        ];

        // También aceptar texto directo
        $textLower = strtolower(trim($text));
        if (in_array($textLower, ['si', 'sí', 's'])) $key = '1';
        elseif (in_array($textLower, ['no', 'n'])) $key = '2';

        if (!isset($options[$key])) {
            BotSender::sendText($from, "❌ Selecciona *1*, *2* o *3*.");
            return;
        }

        $session->setFlowData('ticket_red_light', $options[$key]);
        BotSender::sendText($from, "✅ Luz roja: *{$options[$key]}*");

        // Paso 6: Descripción
        $msg  = "📝 *Describe tu caso:*\n\n";
        $msg .= "Cuéntanos con detalle qué está pasando.\n\n";
        $msg .= "_Ejemplo: No tengo internet desde ayer en la mañana, ya reinicié el router y sigue igual_";
        BotSender::sendText($from, $msg);
        $session->setState('fault_description');
    }

    // === PASO 6: Descripción → Crear ticket ===
    private static function handleDescription($session, $text, $from) {
        $description = trim($text);
        if (strlen($description) < 5) {
            BotSender::sendText($from, "❌ La descripción es muy corta. Cuéntanos con más detalle:");
            return;
        }

        $session->setFlowData('ticket_description', $description);

        // Crear el ticket directamente (sin foto)
        self::createFaultTicket($session, $from);
    }

    /**
     * Crea el ticket de soporte con todos los datos recolectados.
     */
    private static function createFaultTicket($session, $from) {
        BotSender::sendText($from, "⏳ Registrando tu reporte...");

        $client = $session->getClient();
        $fd = $session->getFlowData();
        
        $faultType = $fd['fault_type'] ?? 'Falla General';
        $faultEmoji = $fd['fault_emoji'] ?? '🚨';
        $ticketName = $fd['ticket_name'] ?? $client['nombre'];
        $ticketPhone = $fd['ticket_phone'] ?? $from;
        $ticketCommunity = $fd['ticket_community'] ?? 'N/A';
        $ticketMAC = $fd['ticket_mac'] ?? 'No aplica';
        $ticketRedLight = $fd['ticket_red_light'] ?? 'N/A';
        $ticketDescription = $fd['ticket_description'] ?? '';
        $isMasiva = !empty($fd['is_masiva']);

        // Construir descripción completa para WispHub (sin unicode especial)
        $descCompleta  = "[$faultType]\n";
        $descCompleta .= "---\n";
        $descCompleta .= "Nombre: $ticketName\n";
        $descCompleta .= "Telefono: $ticketPhone\n";
        $descCompleta .= "Comunidad: $ticketCommunity\n";
        if (!$isMasiva) {
            $descCompleta .= "MAC Router: $ticketMAC\n";
        }
        $descCompleta .= "Luz roja: $ticketRedLight\n";
        $descCompleta .= "---\n";
        $descCompleta .= "Descripcion: $ticketDescription\n\n";
        $descCompleta .= "Reportado desde: WhatsApp Bot\n";
        $descCompleta .= "WhatsApp: $from";

        // Mapear tipo de falla a asunto válido de WispHub
        $asuntoMap = [
            'Sin Internet'                    => 'No Tiene Internet',
            'Internet Lento'                  => 'Internet Lento',
            'Intermitente'                    => 'Internet Lento',
            'Falla Masiva en mi Comunidad'    => 'No Tiene Internet'
        ];
        $asuntoWH = $asuntoMap[$faultType] ?? 'No Tiene Internet';
        $prioridadNum = $isMasiva ? '3' : '2';

        $technicians = ['2223475', '2379997', '5853064'];
        date_default_timezone_set('America/Caracas');
        $now = date('d/m/Y H:i');

        $ticketData = [
            'servicio'             => (string)$client['id_servicio'],
            'asunto'               => $asuntoWH,
            'asuntos_default'      => $asuntoWH,
            'departamento'         => 'Soporte Técnico',
            'departamentos_default'=> 'Soporte Técnico',
            'descripcion'          => $descCompleta,
            'razon_falla'          => $asuntoWH,
            'prioridad'            => $prioridadNum,
            'estado'               => '1',
            'tecnico'              => $technicians[array_rand($technicians)],
            'origen_reporte'       => 'oficina',
            'fecha_inicio'         => $now,
            'fecha_final'          => $now
        ];

        $ch = curl_init('https://api.wisphub.app/api/tickets/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ticketData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Api-Key ' . WISPHUB_TOKEN,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $whResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $response = json_decode($whResponse, true);
        $ticketId = $response['id'] ?? $response['id_ticket'] ?? '---';

        botLog("Fault ticket ($faultType): HTTP $httpCode | ID: $ticketId | Client: {$client['nombre']} | Response: $whResponse");

        // Si falla con JSON, intentar multipart (como proxy_promises)
        if ($httpCode === 400) {
            botLog("Fault ticket JSON failed (400). Trying multipart...");
            $result2 = wisphubRelayMultipart('/api/tickets/', $ticketData);
            $httpCode = $result2['http_code'];
            $response2 = json_decode($result2['response'], true);
            $ticketId = $response2['id'] ?? $response2['id_ticket'] ?? $ticketId;
            botLog("Fault ticket multipart: HTTP $httpCode | ID: $ticketId | Response: {$result2['response']}");
        }

        // Enviar email de notificación
        self::sendEmailNotification($client, $faultType, $faultEmoji, $fd, $ticketId, $from);

        // Responder al cliente
        if ($httpCode >= 200 && $httpCode < 300) {
            $msg  = "✅ *Falla reportada exitosamente*\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n";
            $msg .= "$faultEmoji Tipo: *$faultType*\n";
            $msg .= "🔢 Ticket: *#$ticketId*\n";
            $msg .= "👤 $ticketName\n";
            $msg .= "📱 $ticketPhone\n";
            $msg .= "🏘️ $ticketCommunity\n";
            if (!$isMasiva) {
                $msg .= "📦 MAC: $ticketMAC\n";
            }
            $msg .= "🔴 Luz roja: $ticketRedLight\n";
            $msg .= "📅 Fecha: " . date('d/m/Y H:i') . "\n";
            $msg .= "⏰ Atención estimada: 24-48 horas\n";
            $msg .= "━━━━━━━━━━━━━━━━━━━\n\n";
            $msg .= "Un técnico se comunicará contigo pronto 🔧\n";
            $msg .= "Escribe *menu* para volver al menú.";
        } else {
            $msg  = "⚠️ Tu reporte fue registrado por correo.\n";
            $msg .= "Un técnico se comunicará contigo pronto 🔧\n\n";
            $msg .= "Si es urgente, contacta al admin:\n";
            $msg .= "📞 wa.me/" . BOT_ADMIN_WA;
        }

        BotSender::sendText($from, $msg);

        // Notificar al admin por WhatsApp
        $adminMsg  = "🔔 *Nuevo Ticket de Falla*\n";
        $adminMsg .= "━━━━━━━━━━━━━━━━━━━\n";
        $adminMsg .= "$faultEmoji *$faultType*\n";
        $adminMsg .= "🔢 Ticket: #$ticketId\n";
        $adminMsg .= "👤 $ticketName\n";
        $adminMsg .= "📱 $ticketPhone\n";
        $adminMsg .= "🏘️ $ticketCommunity\n";
        if (!$isMasiva) {
            $adminMsg .= "📦 MAC: $ticketMAC\n";
        }
        $adminMsg .= "🔴 Luz roja: $ticketRedLight\n";
        $adminMsg .= "📋 $ticketDescription";
        BotSender::sendText(BOT_ADMIN_WA, $adminMsg);

        $session->clearFlowData();
        $session->setState('main_menu');
    }

    /**
     * Email de notificación con todos los datos del ticket.
     */
    private static function sendEmailNotification($client, $faultType, $emoji, $fd, $ticketId, $from) {
        $to = "soporte@wifirapidito.com";
        $subject = "$emoji FALLA $faultType: " . ($fd['ticket_name'] ?? $client['nombre']) . " - #$ticketId";
        
        $isMasiva = !empty($fd['is_masiva']);
        
        $headers  = "From: noreply@wifirapidito.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $body = "<html><body style='font-family: sans-serif;'>";
        $body .= "<h2 style='color: #dc2626;'>$emoji Reporte de Falla: $faultType</h2>";
        $body .= "<hr>";
        $body .= "<p><strong>Ticket:</strong> #$ticketId</p>";
        $body .= "<p><strong>Nombre:</strong> " . ($fd['ticket_name'] ?? $client['nombre']) . "</p>";
        $body .= "<p><strong>Teléfono:</strong> " . ($fd['ticket_phone'] ?? $from) . "</p>";
        $body .= "<p><strong>Comunidad:</strong> " . ($fd['ticket_community'] ?? 'N/A') . "</p>";
        if (!$isMasiva) {
            $body .= "<p><strong>MAC Router:</strong> " . ($fd['ticket_mac'] ?? 'N/A') . "</p>";
        }
        $body .= "<p><strong>Luz roja:</strong> " . ($fd['ticket_red_light'] ?? 'N/A') . "</p>";
        $body .= "<p><strong>ID Servicio:</strong> {$client['id_servicio']}</p>";
        $body .= "<p><strong>WhatsApp:</strong> $from</p>";
        $body .= "<p style='background: #fef2f2; padding: 15px; border-left: 4px solid #dc2626;'>";
        $body .= "<strong>Descripción:</strong><br>" . nl2br(htmlspecialchars($fd['ticket_description'] ?? '')) . "</p>";
        $body .= "<p><em>Origen: Bot WhatsApp Rapidito</em></p>";
        $body .= "</body></html>";

        @mail($to, $subject, $body, $headers);
    }
}
?>
