const https = require('https');

const options = {
  hostname: 'api.wisphub.app',
  port: 443,
  path: '/api/clientes/?usuario=anaveliz@wifi-rapidito&limit=10',
  method: 'GET',
  headers: {
    'Authorization': 'Api-Key OYIxEv1H.qmnKH5Ck8NvLWw4Tnyoa7PswdhrJlJ9s',
    'Content-Type': 'application/json'
  }
};

const req = https.request(options, res => {
  let body = '';
  res.on('data', d => body += d);
  res.on('end', () => console.log('HTTP: ' + res.statusCode + '\nBody: ' + body));
});

req.on('error', error => {
  console.error(error);
});

req.end();
